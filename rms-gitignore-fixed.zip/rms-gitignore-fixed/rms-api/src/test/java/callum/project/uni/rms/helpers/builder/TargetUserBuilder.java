package callum.project.uni.rms.helpers.builder;

import callum.project.uni.rms.candidates.model.UserType;
import callum.project.uni.rms.candidates.model.request.UserCreateReq;
import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.RoleType;

import callum.project.uni.rms.candidates.model.target.TargetUser;

import static callum.project.uni.rms.helpers.constants.RoleConstants.ROLE_ID;
import static callum.project.uni.rms.helpers.constants.UserConstants.*;

public class TargetUserBuilder {
    
    public static UserCreateReq buildCreateReq() {
        return UserCreateReq.builder()
                .ssoId(USER_SSO_ID)
                .userType(UserType.CANDIDATE)
                .name(USER_NAME)
                .currentRoleId(ROLE_ID)
                .businessUnitId(BUSINESS_UNIT_ID)
                .grade(GRADE)
                .baseLocation(BaseLocation.ASTON)
                .userSpecialism(RoleType.SOFTWARE_ENGINEER)
                .build();
    }
    
    public static TargetUser buildTargetUser() {
        return TargetUser.builder()
                .baseLocation(BaseLocation.ASTON)
                .userType(UserType.CANDIDATE)
                .id(USER_ID)
                .fullName(USER_NAME)
                .userSpecialism(RoleType.SOFTWARE_ENGINEER)
                .currentRoleId(ROLE_ID)
                .businessUnitId(BUSINESS_UNIT_ID)
                .grade(GRADE)
                .baseLocationY(BaseLocation.ASTON.getY())
                .baseLocationX(BaseLocation.ASTON.getX())
                .build();
    }

}
