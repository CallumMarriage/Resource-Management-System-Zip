package callum.project.uni.rms.account;

import callum.project.uni.rms.account.service.AccountFullInfoService;
import callum.project.uni.rms.account.service.AccountService;
import callum.project.uni.rms.model.req.AccountCreateReq;
import callum.project.uni.rms.model.res.TargetAccount;
import callum.project.uni.rms.model.res.accounts.AccountList;
import callum.project.uni.rms.model.res.accounts.FullAccountInfo;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.parent.exception.NotFoundException;
import callum.project.uni.rms.project.ProjectService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;

import static callum.project.uni.rms.helpers.asserts.AccountAsserts.assertAccountIsCorrect;
import static callum.project.uni.rms.helpers.asserts.ProjectAsserts.assertProjectsAreCorrect;
import static callum.project.uni.rms.helpers.builder.TargetAccountsBuilder.buildAccountCreateReq;
import static callum.project.uni.rms.helpers.builder.TargetAccountsBuilder.buildMockAccount;
import static callum.project.uni.rms.helpers.builder.TargetProjectsBuilder.buildProjectsForAccount;
import static callum.project.uni.rms.helpers.constants.AccountConstants.*;
import static java.util.Collections.singletonList;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AccountController.class)
class AccountControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private AccountService service;

    @MockBean
    private ProjectService projectService;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AccountFullInfoService accountsWithProjectsService;

    @Test
    void retrieveTargetAccountById_happyPath() throws Exception {
        when(service.retrieveTargetAccountById(eq(ACCOUNT_CODE)))
                .thenReturn(buildMockAccount());
        when(projectService.retrieveProjectsByAccountNumber(eq(ACCOUNT_CODE)))
                .thenReturn(buildProjectsForAccount());

        ResultActions resultActions = this.mvc.perform(get("/account/id/" + ACCOUNT_CODE))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        FullAccountInfo accountInfo = objectMapper.readValue(contentAsString, FullAccountInfo.class);

        assertProjectsAreCorrect(accountInfo.getProjectList());
        assertAccountIsCorrect(accountInfo.getAccount());
    }

    @Test
    void retrieveTargetAccountById_notFound() throws Exception {
        when(service.retrieveTargetAccountById(eq("999999999")))
                .thenThrow(new NotFoundException("Not found"));

        this.mvc.perform(get("/account/id/999999999"))
                .andDo(print())
                .andExpect(status().isNotFound());
    }

    @Test
    void isAccountAvailable_happyPath() throws Exception {
        when(service.isAccountAvailable(eq(ACCOUNT_CODE)))
                .thenReturn(true);

        ResultActions resultActions = this.mvc.perform(get("/account/" + ACCOUNT_CODE + "/available"))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        AccountAvailable accountInfo = objectMapper.readValue(contentAsString, AccountAvailable.class);
        assertTrue(accountInfo.isAccountAvailable());
    }

    @Test
    void isAccountAvailable_notAvailable() throws Exception {
        when(service.isAccountAvailable(eq(ACCOUNT_CODE)))
                .thenReturn(false);

        ResultActions resultActions = this.mvc.perform(get("/account/" + ACCOUNT_CODE + "/available"))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        AccountAvailable accountInfo = objectMapper.readValue(contentAsString, AccountAvailable.class);
        assertFalse(accountInfo.isAccountAvailable());
    }

    @Test
    void isAccountAvailable_serverError() throws Exception {
        when(service.isAccountAvailable(eq(ACCOUNT_CODE)))
                .thenThrow(InternalServiceException.class);

        this.mvc.perform(get("/account/" + ACCOUNT_CODE + "/available"))
                .andDo(print())
                .andExpect(status().isInternalServerError());
    }

    @Test
    void retrieveAccounts_happyPath_amId() throws Exception {

        when(service.retrieveAccountList(eq(1L)))
                .thenReturn(AccountList.builder()
                        .accountList(singletonList(buildMockAccount()))
                        .build());

        ResultActions resultActions = this.mvc.perform(get("/accounts")
                .queryParam("accountManagerId", "1"))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        AccountList accountInfo = objectMapper.readValue(contentAsString, AccountList.class);

        verify(service, times(1)).retrieveAccountList(eq(1L));
        verify(service, never()).retrieveAccountList(eq(null));
        assertEquals(1, accountInfo.getAccountList().size());
        assertAccountIsCorrect(accountInfo.getAccountList().get(0));
    }

    @Test
    void retrieveAccounts_happyPath() throws Exception {
        when(service.retrieveAccountList(null))
                .thenReturn(AccountList.builder()
                        .accountList(singletonList(buildMockAccount()))
                        .build());

        ResultActions resultActions = this.mvc.perform(get("/accounts"))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        AccountList accountInfo = objectMapper.readValue(contentAsString, AccountList.class);

        verify(service, times(1)).retrieveAccountList(eq(null));
        verify(service, never()).retrieveAccountList(eq(1L));
        assertEquals(1, accountInfo.getAccountList().size());
        assertAccountIsCorrect(accountInfo.getAccountList().get(0));
    }

    @Test
    void addNewAccount_happyPath() throws Exception {
        AccountCreateReq createReq = buildAccountCreateReq();
        when(service.addNewAccount(eq(createReq)))
                .thenReturn(buildMockAccount());

        JSONObject createReqObj = new JSONObject();
        createReqObj.put("accountName", ACCOUNT_NAME);
        createReqObj.put("accountNumber", ACCOUNT_CODE);
        createReqObj.put("description", ACCOUNT_DESCRIPTION);
        createReqObj.put("accountManagerId", "1");
        createReqObj.put("startDate", ACCOUNT_START_DATE.toString());
        createReqObj.put("endDate", ACCOUNT_END_DATE.toString());

        String reqJson = createReqObj.toString();

        ResultActions resultActions = this.mvc.perform(
                post("/account")
                        .content(reqJson)
                        .contentType("Application/json"))
                .andDo(print())
                .andExpect(status().isCreated());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        TargetAccount accountInfo = objectMapper.readValue(contentAsString, TargetAccount.class);
        assertEquals(ACCOUNT_CODE, accountInfo.getAccountCode());
    }
}