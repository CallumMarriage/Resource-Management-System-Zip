package callum.project.uni.rms.helpers.builder;

import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.RoleType;
import callum.project.uni.rms.roles.service.model.Role;

import java.sql.Date;

import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_CODE;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_NAME;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.PROJECT_CODE;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.PROJECT_NAME;
import static callum.project.uni.rms.helpers.constants.RoleConstants.*;
import static callum.project.uni.rms.helpers.constants.UserConstants.BUSINESS_UNIT_ID;
import static callum.project.uni.rms.helpers.constants.UserConstants.GRADE;

public class SourceRoleBuilder {


    public static Role buildSourceRole(){
        return Role.builder()
                .grade(GRADE)
                .certainty(CERTAINTY)
                .endDate(Date.valueOf(ROLE_END_DATE))
                .startDate(Date.valueOf(ROLE_START_DATE))
                .businessUnitId(BUSINESS_UNIT_ID)
                .accountName(ACCOUNT_NAME)
                .baseLocation(BaseLocation.ASTON)
                .accountNumber(ACCOUNT_CODE)
                .description(ROLE_DESCRIPTION)
                .id(ROLE_ID)
                .isRoleOpen(true)
                .projectCode(PROJECT_CODE)
                .projectName(PROJECT_NAME)
                .roleName(ROLE_NAME)
                .roleType(RoleType.SOFTWARE_ENGINEER)
                .build();

    }
}

