package callum.project.uni.rms.helpers;

import callum.project.uni.rms.project.Project;

import java.sql.Date;

import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_CODE;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.*;
import static callum.project.uni.rms.helpers.constants.UserConstants.USER_ID;

public class ProjectBuilder {

    public static Project buildSourceProject() {
        return Project.builder()
                .accountNumber(ACCOUNT_CODE)
                .description(PROJECT_DESC)
                .endDate(Date.valueOf(PROJECT_END_DATE))
                .startDate(Date.valueOf(PROJECT_START_DATE))
                .projectCode(PROJECT_CODE)
                .projectName(PROJECT_NAME)
                .projectManagerId(USER_ID)
                .build();
    }
}
