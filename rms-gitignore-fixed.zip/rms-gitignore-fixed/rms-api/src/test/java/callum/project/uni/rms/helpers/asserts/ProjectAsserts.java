package callum.project.uni.rms.helpers.asserts;

import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.res.TargetProject;

import java.util.List;

import static callum.project.uni.rms.helpers.builder.TargetProjectsBuilder.*;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_CODE;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProjectAsserts {


    public static void assertProjectsAreCorrect(List<TargetProject> projects) {
        assertEquals(1, projects.size());
        assertProjectCorrect(projects.get(0));
    }

    public static void assertProjectCorrect(TargetProject project) {
        assertEquals(ACCOUNT_CODE, project.getAccountNumber());
        assertEquals(PROJECT_CODE, project.getProjectCode());
        assertEquals(PROJECT_START_DATE, project.getStartDate());
        assertEquals(PROJECT_END_DATE, project.getEndDate());
        assertEquals(PROJECT_NAME, project.getProjectName());
        assertEquals(PROJECT_DESC, project.getDescription());
    }
}
