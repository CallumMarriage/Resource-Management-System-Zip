package callum.project.uni.rms.roles;

import callum.project.uni.rms.model.RoleType;
import callum.project.uni.rms.model.res.AbstractServiceResponse;
import callum.project.uni.rms.model.res.role.RoleList;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.roles.service.RoleFilterService;
import callum.project.uni.rms.roles.RoleListController;
import callum.project.uni.rms.roles.service.RoleListService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.lang.NonNull;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.Collections;

import static callum.project.uni.rms.helpers.asserts.RoleAsserts.assertRole;
import static callum.project.uni.rms.helpers.builder.TargetRoleBuilder.buildTargetRole;
import static callum.project.uni.rms.helpers.builder.TargetRoleBuilder.createRoleList;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_NAME;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.PROJECT_CODE;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.PROJECT_NAME;
import static callum.project.uni.rms.helpers.constants.UserConstants.BUSINESS_UNIT_ID;
import static callum.project.uni.rms.helpers.constants.UserConstants.USER_ID;
import static java.util.Collections.singletonList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(RoleListController.class)
class RoleListControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private RoleListService roleListService;

    @MockBean
    private RoleFilterService roleFilterService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void filterRoles_happyPath() throws Exception {
        when(roleFilterService.runFilters(eq(ACCOUNT_NAME),
                eq(PROJECT_NAME),
                eq(RoleType.SOFTWARE_ENGINEER), eq(null), eq(null)))
                .thenReturn(createRoleList());

        ResultActions resultActions = this.mvc.perform(get("/roles")
                .queryParam("accountName", ACCOUNT_NAME)
                .queryParam("projectName", PROJECT_NAME)
                .queryParam("roleType", "SOFTWARE_ENGINEER"))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        RoleList roleList = objectMapper.readValue(contentAsString, RoleList.class);

        assertEquals(1, roleList.getRoleList().size());
        assertRole(roleList.getRoleList().get(0));
    }

    @Test
    void getRolesForUser_happyPath() throws Exception {
        when(roleListService.retrieveRoleHistory(eq(USER_ID))).thenReturn(
                RoleList.builder()
                        .roleList(singletonList(buildTargetRole()))
                        .build());

        ResultActions resultActions = this.mvc.perform(get("/roles")
                .queryParam("userId", USER_ID.toString()))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        RoleList roleList = objectMapper.readValue(contentAsString, RoleList.class);

        assertEquals(1, roleList.getRoleList().size());
        assertRole(roleList.getRoleList().get(0));
    }

    @Test
    void getOpenRolesForBuId_happyPath() throws Exception {
        when(roleListService.retrieveRolesForBusinessUnit(eq(BUSINESS_UNIT_ID)))
                .thenReturn(RoleList.builder()
                        .roleList(singletonList(buildTargetRole()))
                        .build());

        ResultActions resultActions = this.mvc.perform(get("/roles/open")
                .queryParam("buId", BUSINESS_UNIT_ID.toString()))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        RoleList roleList = objectMapper.readValue(contentAsString, RoleList.class);

        assertEquals(1, roleList.getRoleList().size());
        assertRole(roleList.getRoleList().get(0));
    }

    @Test
    void getOpenRolesForProject_happyPath() throws Exception {
        when(roleListService.retrieveOpenRolesForProject(eq(PROJECT_CODE)))
                .thenReturn(RoleList.builder()
                        .roleList(singletonList(buildTargetRole()))
                        .build());

        ResultActions resultActions = this.mvc.perform(get("/roles/open")
                .queryParam("projectCode", PROJECT_CODE))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        RoleList roleList = objectMapper.readValue(contentAsString, RoleList.class);

        assertEquals(1, roleList.getRoleList().size());
        assertRole(roleList.getRoleList().get(0));
    }

    @Test
    void getOpenRoles_happyPath() throws Exception {
        when(roleListService.retrieveAllOpenRoles())
                .thenReturn(RoleList.builder()
                        .roleList(singletonList(buildTargetRole()))
                        .build());
        ResultActions resultActions = this.mvc.perform(get("/roles/open"))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        RoleList roleList = objectMapper.readValue(contentAsString, RoleList.class);

        assertEquals(1, roleList.getRoleList().size());
        assertRole(roleList.getRoleList().get(0));
    }

    @Test
    void getOpenRoles_serverError() throws Exception {
        when(roleListService.retrieveAllOpenRoles())
                .thenThrow(InternalServiceException.class);

        this.mvc.perform(get("/roles/open"))
                .andDo(print())
                .andExpect(status().isInternalServerError());
    }
}