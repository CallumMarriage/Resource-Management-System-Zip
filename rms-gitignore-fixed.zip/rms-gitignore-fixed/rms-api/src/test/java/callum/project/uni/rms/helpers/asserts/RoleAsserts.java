package callum.project.uni.rms.helpers.asserts;

import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.res.TargetRole;

import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_CODE;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_NAME;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.PROJECT_CODE;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.PROJECT_NAME;
import static callum.project.uni.rms.helpers.constants.RoleConstants.*;
import static callum.project.uni.rms.helpers.constants.UserConstants.GRADE;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class RoleAsserts {

    public static void assertRole(TargetRole targetRole){
        assertEquals(GRADE, targetRole.getGrade());
        assertEquals(CERTAINTY, targetRole.getCertainty());
        assertEquals(ROLE_ID, targetRole.getId());
        assertEquals(ROLE_NAME, targetRole.getRoleName());
        assertEquals(PROJECT_NAME, targetRole.getProjectName());
        assertEquals(PROJECT_CODE, targetRole.getProjectCode());
        assertEquals(ACCOUNT_NAME, targetRole.getAccountName());
        assertEquals(ACCOUNT_CODE, targetRole.getAccountNumber());
        assertEquals(BaseLocation.ASTON, targetRole.getBaseLocation());
        assertEquals(ROLE_DESCRIPTION, targetRole.getDescription());
    }
}
