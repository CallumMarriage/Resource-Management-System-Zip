package callum.project.uni.rms.helpers.constants;

import java.time.LocalDate;

public class ProjectConstants {


    public static final String PROJECT_CODE = "1234567890";
    public static final LocalDate PROJECT_START_DATE = LocalDate.now();
    public static final LocalDate PROJECT_END_DATE = LocalDate.now();
    public static final String PROJECT_NAME = "PROJECT_NAME";
    public static final String PROJECT_DESC = "PROJECT_DESCRIPTION";
}
