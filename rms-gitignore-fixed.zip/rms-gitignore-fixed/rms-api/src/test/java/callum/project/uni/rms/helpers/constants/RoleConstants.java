package callum.project.uni.rms.helpers.constants;

import java.sql.Date;
import java.time.LocalDate;

public class RoleConstants {

    public static final Long ROLE_ID = 1L;
    public static final String ROLE_NAME = "ROLE_NAME";
    public static final LocalDate ROLE_START_DATE = LocalDate.now();
    public static final LocalDate ROLE_END_DATE = LocalDate.now();
    
    public static final Date DB_ROLE_START_DATE = java.sql.Date.valueOf(LocalDate.now());
    public static final Date DB_ROLE_END_DATE = java.sql.Date.valueOf(LocalDate.now());
    public static final Double CERTAINTY = 100.00;
    
    public static final String ROLE_DESCRIPTION = "DESC";

}
