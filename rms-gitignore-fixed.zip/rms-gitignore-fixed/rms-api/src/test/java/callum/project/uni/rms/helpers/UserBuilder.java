package callum.project.uni.rms.helpers;

import callum.project.uni.rms.candidates.model.UserType;
import callum.project.uni.rms.candidates.model.source.User;
import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.RoleType;


import static callum.project.uni.rms.helpers.constants.RoleConstants.ROLE_ID;
import static callum.project.uni.rms.helpers.constants.UserConstants.*;

public class UserBuilder {
    
    public static User buildAuthUser(){
        return User.builder()
                .baseLocation(BaseLocation.ASTON)
                .userType(UserType.PROJECT_MANAGER)
                .id(AUTH_ID)
                .fullName(AUTH_NAME)
                .ssoId(AUTH_SSO_ID)
                .userSpecialism(RoleType.PROJECT_MANAGER)
                .grade(GRADE)
                .businessUnitId(BUSINESS_UNIT_ID)
                .build();
    }

    public static User buildUser(){
        return User.builder()
                .baseLocation(BaseLocation.ASTON)
                .userType(UserType.CANDIDATE)
                .id(USER_ID)
                .fullName(USER_NAME)
                .ssoId(USER_SSO_ID)
                .userSpecialism(RoleType.SOFTWARE_ENGINEER)
                .currentRoleId(ROLE_ID)
                .grade(GRADE)
                .businessUnitId(BUSINESS_UNIT_ID)
                .build();
    }
}
