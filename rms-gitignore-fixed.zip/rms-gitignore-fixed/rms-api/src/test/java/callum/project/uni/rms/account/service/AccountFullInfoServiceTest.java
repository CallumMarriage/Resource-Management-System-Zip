package callum.project.uni.rms.account.service;

import callum.project.uni.rms.model.res.TargetAccount;
import callum.project.uni.rms.model.res.TargetProject;
import callum.project.uni.rms.model.res.accounts.AccountAndProjects;
import callum.project.uni.rms.model.res.accounts.AccountList;
import callum.project.uni.rms.model.res.accounts.AccountsWithProjects;
import callum.project.uni.rms.model.res.projects.ProjectList;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.project.ProjectService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static callum.project.uni.rms.helpers.builder.TargetAccountsBuilder.buildMockAccount;
import static callum.project.uni.rms.helpers.builder.TargetProjectsBuilder.buildTargetProject;
import static callum.project.uni.rms.helpers.constants.UserConstants.USER_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AccountFullInfoServiceTest {

    private AccountFullInfoService accountFullInfoService;

    private ProjectService projectService;

    private AccountService accountService;


    @BeforeEach
    void setUp() {
        projectService = mock(ProjectService.class);
        accountService = mock(AccountService.class);

        accountFullInfoService = new AccountFullInfoService(projectService, accountService);
    }

    @Test
    void retrieveAccountsWithProjects() {

        // User is the account manager for three accounts
        List<TargetAccount> mockAccountList = new ArrayList<>();
        mockAccountList.add(buildAccount("1"));
        mockAccountList.add(buildAccount("2"));
        mockAccountList.add(buildAccount("3"));

        when(accountService.retrieveAccountList(USER_ID))
                .thenReturn(AccountList.builder()
                        .accountList(mockAccountList)
                        .build());

        // User is the project manager for all of the projects mocked in the accounts section
        // User is also the project manager for 4 projects on another account
        setUpMocksForProjects();

        AccountsWithProjects res = accountFullInfoService.retrieveAccountsWithProjects(USER_ID);

        // Should return all 4 accounts that the project manager is involved in.
        assertEquals(4, res.getAccountAndProjectsList().size());
        assertEquals(3, res.getAccountAndProjectsList().get(0).getProjects().size());
        assertEquals(3, res.getAccountAndProjectsList().get(1).getProjects().size());
        assertEquals(3, res.getAccountAndProjectsList().get(2).getProjects().size());
        assertEquals(4, res.getAccountAndProjectsList().get(3).getProjects().size());
    }

    @Test
    void retrieveAccountsWithProjects_serverError() {

        when(accountService.retrieveAccountList(USER_ID)).thenThrow(RuntimeException.class);
        assertThrows(InternalServiceException.class,
                () -> accountFullInfoService.retrieveAccountsWithProjects(USER_ID));
    }


    private void setUpMocksForProjects(){
        List<TargetProject> mocks = new ArrayList<>();
        mocks.add(mockProject("1", "1"));
        mocks.add(mockProject("1", "2"));
        mocks.add(mockProject("1", "3"));
        mocks.add(mockProject("2", "1"));
        mocks.add(mockProject("2", "2"));
        mocks.add(mockProject("2", "3"));
        mocks.add(mockProject("3", "1"));
        mocks.add(mockProject("3", "2"));
        mocks.add(mockProject("3", "3"));
        mocks.add(mockProject("4", "1"));
        mocks.add(mockProject("4", "2"));
        mocks.add(mockProject("4", "3"));
        mocks.add(mockProject("4", "4"));
        ProjectList projectList = new ProjectList(mocks);

        when(projectService.retrieveProjectsByProjectManager(eq(USER_ID)))
                .thenReturn(projectList);
    }

    private TargetAccount buildAccount(String accountCode){
        TargetAccount accountOne = buildMockAccount();
        accountOne.setAccountCode(accountCode);
        when(projectService.retrieveProjectsByAccountNumber(eq(accountCode)))
                .thenReturn(buildProjectList(accountCode));
        return accountOne;
    }

    private ProjectList buildProjectList(String accountCode) {
        TargetProject projectOne = mockProject(accountCode, "1");
        TargetProject projectTwo = mockProject(accountCode, "2");
        List<TargetProject> projects = new ArrayList<>();
        projects.add(projectOne);
        projects.add(projectTwo);
        return new ProjectList(projects);
    }

    private TargetProject mockProject(String accountCode, String projectCode){
        TargetProject project = buildTargetProject();
        project.setAccountNumber(accountCode);
        project.setProjectCode(accountCode+ projectCode);
        return project;
    }

}