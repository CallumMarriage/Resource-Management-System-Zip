package callum.project.uni.rms.helpers.builder;

import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.RoleType;
import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.model.res.role.RoleList;
import callum.project.uni.rms.roles.model.RequestRole;
import callum.project.uni.rms.roles.model.RoleCreateReq;

import java.util.List;

import static callum.project.uni.rms.helpers.constants.AccountConstants.*;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.PROJECT_CODE;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.PROJECT_NAME;
import static callum.project.uni.rms.helpers.constants.RoleConstants.*;
import static callum.project.uni.rms.helpers.constants.UserConstants.*;

public class TargetRoleBuilder {

    public static RoleList createRoleList() {
        return RoleList.builder()
                .roleList(List.of(buildTargetRole()))
                .build();
    }

    public static RoleCreateReq buildRoleCreateReq(){
        return RoleCreateReq.builder()
                .role(buildRequestRole())
                .userId(USER_ID)
                .build();

    }

    public static RequestRole buildRequestRole(){
        return RequestRole.builder()
                .baseLocation(BaseLocation.ASTON)
                .accountName(ACCOUNT_NAME)
                .accountNumber(ACCOUNT_CODE)
                .description(ROLE_DESCRIPTION)
                .projectCode(PROJECT_CODE)
                .projectName(PROJECT_NAME)
                .roleName(ROLE_NAME)
                .roleType(RoleType.SOFTWARE_ENGINEER)
                .startDate(ROLE_START_DATE)
                .endDate(ROLE_END_DATE)
                .businessUnit(BUSINESS_UNIT_ID)
                .grade(GRADE)
                .certainty(CERTAINTY)
                .build();
    }

    public static TargetRole buildTargetRole() {
        return TargetRole.builder()
                .baseLocation(BaseLocation.ASTON)
                .baseLocationX(BaseLocation.ASTON.getX())
                .baseLocationY(BaseLocation.ASTON.getX())
                .accountName(ACCOUNT_NAME)
                .accountNumber(ACCOUNT_CODE)
                .description(ROLE_DESCRIPTION)
                .projectCode(PROJECT_CODE)
                .projectName(PROJECT_NAME)
                .id(ROLE_ID)
                .roleName(ROLE_NAME)
                .isRoleOpen(true)
                .roleType(RoleType.SOFTWARE_ENGINEER)
                .startDate(ROLE_START_DATE)
                .grade(GRADE)
                .businessUnit(BUSINESS_UNIT_ID)
                .endDate(ROLE_END_DATE)
                .certainty(CERTAINTY)
                .build();
    }

}
