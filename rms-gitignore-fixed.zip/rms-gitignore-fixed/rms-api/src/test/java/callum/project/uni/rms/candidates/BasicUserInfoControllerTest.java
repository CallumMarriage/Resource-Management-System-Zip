package callum.project.uni.rms.candidates;

import callum.project.uni.rms.candidates.model.request.UserCreateReq;
import callum.project.uni.rms.model.res.TargetAccount;
import callum.project.uni.rms.model.res.TargetProject;
import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.parent.exception.NotFoundException;
import callum.project.uni.rms.candidates.model.target.FullUserInfo;
import callum.project.uni.rms.candidates.model.target.TargetUser;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;

import static callum.project.uni.rms.helpers.asserts.UserAsserts.validateFullInfoResponseBody;
import static callum.project.uni.rms.helpers.builder.TargetAccountsBuilder.buildMockAccount;
import static callum.project.uni.rms.helpers.builder.TargetProjectsBuilder.buildTargetProject;
import static callum.project.uni.rms.helpers.builder.TargetRoleBuilder.buildTargetRole;
import static callum.project.uni.rms.helpers.builder.TargetUserBuilder.buildCreateReq;
import static callum.project.uni.rms.helpers.builder.TargetUserBuilder.buildTargetUser;
import static callum.project.uni.rms.helpers.constants.RoleConstants.ROLE_ID;
import static callum.project.uni.rms.helpers.constants.UserConstants.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(BasicUserInfoController.class)
public class BasicUserInfoControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private UserService userService;

    @MockBean
    private BasicUserInfoService basicUserInfoService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @DisplayName("Test get user info happy path")
    void getUserInfo_happyPath() throws Exception {
        TargetUser mockedUser = buildTargetUser();

        initMock(mockedUser);

        when(userService.retrieveUserDetailsBySsoId(eq(USER_SSO_ID)))
                .thenReturn(mockedUser);

        ResultActions resultActions = this.mvc.perform(get("/user/info")
                .queryParam("ssoId", USER_SSO_ID))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();
        FullUserInfo res = objectMapper.readValue(contentAsString, FullUserInfo.class);
        validateFullInfoResponseBody(res);
    }

    @Test
    @DisplayName("Test get user info bad request")
    void getUserInfo_badRequest() throws Exception {
        this.mvc.perform(get("/user/info"))
                .andDo(print())
                .andExpect(status().isBadRequest());
    }


    @Test
    @DisplayName("Test get user info server error")
    void getUserInfo_serverError() throws Exception {
        when(userService.retrieveUserDetailsBySsoId(eq(USER_SSO_ID)))
                .thenThrow(InternalServiceException.class);
        this.mvc.perform(get("/user/info").queryParam("ssoId", USER_SSO_ID))
                .andDo(print())
                .andExpect(status().isInternalServerError());
    }

    @Test
    @DisplayName("Test get user info not found")
    void getUserInfo_notFound() throws Exception {
        when(userService.retrieveUserDetailsBySsoId(eq(USER_SSO_ID)))
                .thenThrow(NotFoundException.class);
        this.mvc.perform(get("/user/info").queryParam("ssoId", USER_SSO_ID))
                .andDo(print())
                .andExpect(status().isNotFound());
    }


    @Test
    @DisplayName("Test add user happy path")
    void addUser_happyPath() throws Exception {
        TargetUser mockedUser = buildTargetUser();

        initMock(mockedUser);

        UserCreateReq mockUserCreatReq = buildCreateReq();


        when(userService.createUser(eq(mockUserCreatReq)))
                .thenReturn(mockedUser);

        this.mvc.perform(
                post("/user")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{" +
                                "\"userId\": \""+USER_ID+"\", " +
                                "\"currentRoleId\": \""+ROLE_ID+"\", " +
                                "\"name\": \"" + USER_NAME + "\"," +
                                "\"baseLocation\":\"ASTON\"," +
                                "\"ssoId\": \""+USER_SSO_ID+"\"," +
                                "\"userType\": \"CANDIDATE\"," +
                                "\"userSpecialism\": \"SOFTWARE_ENGINEER\"," +
                                "\"businessUnitId\": \""+BUSINESS_UNIT_ID+"\"," +
                                "\"grade\": \""+GRADE+"\"" +
                                "}"))
                .andDo(print())
                .andExpect(status().isCreated());
    }

    @Test
    @DisplayName("Test get user info not found")
    void addUser_serverError() throws Exception {
        UserCreateReq mockUserCreatReq = buildCreateReq();

        when(userService.createUser(any())).thenReturn(buildTargetUser());
        when(userService.createUser(eq(mockUserCreatReq)))
                .thenThrow(InternalServiceException.class);

        this.mvc.perform(
                post("/user")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{" +
                                "\"userId\": \""+USER_ID+"\", " +
                                "\"currentRoleId\": \""+ROLE_ID+"\", " +
                                "\"name\": \"" + USER_NAME + "\"," +
                                "\"baseLocation\":\"ASTON\"," +
                                "\"ssoId\": \""+USER_SSO_ID+"\"," +
                                "\"userType\": \"CANDIDATE\"," +
                                "\"userSpecialism\": \"SOFTWARE_ENGINEER\"," +
                                "\"businessUnitId\": \""+BUSINESS_UNIT_ID+"\"," +
                                "\"grade\": \""+GRADE+"\"" +
                                "}"))
                .andDo(print())
                .andExpect(status().isInternalServerError());
    }
    private void initMock(TargetUser user) {

        TargetRole mockedRole = buildTargetRole();

        TargetAccount mockedAccount = buildMockAccount();

        TargetProject mockedProject = buildTargetProject();

        when(basicUserInfoService.buildUserInfoResponse(eq(user)))
                .thenReturn(FullUserInfo.builder()
                        .currentAccount(mockedAccount)
                        .currentProject(mockedProject)
                        .currentRole(mockedRole)
                        .user(user)
                        .build());
    }

}
