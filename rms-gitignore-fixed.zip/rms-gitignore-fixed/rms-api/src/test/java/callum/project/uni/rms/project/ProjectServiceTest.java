package callum.project.uni.rms.project;

import callum.project.uni.rms.model.req.ProjectCreateReq;
import callum.project.uni.rms.model.res.TargetProject;
import callum.project.uni.rms.model.res.projects.ProjectList;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.parent.exception.NotFoundException;
import org.hibernate.HibernateException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.util.Collections;
import java.util.Optional;

import static callum.project.uni.rms.helpers.ProjectBuilder.buildSourceProject;
import static callum.project.uni.rms.helpers.asserts.ProjectAsserts.assertProjectCorrect;
import static callum.project.uni.rms.helpers.builder.TargetProjectsBuilder.*;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_CODE;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.*;
import static callum.project.uni.rms.helpers.constants.UserConstants.USER_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProjectServiceTest {

    private ProjectService projectService;

    private ProjectRepository projectRepository;

    @BeforeEach
    void setUp() {
        projectRepository = mock(ProjectRepository.class);
        projectService = new ProjectService(projectRepository);
    }


    @Test
    void retrieveProjectById() {
        when(projectRepository.findById(eq(PROJECT_CODE)))
                .thenReturn(Optional.of(buildSourceProject()));
        TargetProject res = projectService.retrieveProjectById(PROJECT_CODE);
        assertProjectCorrect(res);
    }

    @Test
    void retrieveProjectById_notFound() {
        when(projectRepository.findById(eq(PROJECT_CODE)))
                .thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> projectService.retrieveProjectById(PROJECT_CODE));
    }

    @Test
    void retrieveProjectById_serverError() {
        when(projectRepository.findById(eq(PROJECT_CODE)))
                .thenThrow(HibernateException.class);

        assertThrows(InternalServiceException.class,
                () -> projectService.retrieveProjectById(PROJECT_CODE));
    }

    @Test
    void addNewProject() {
        ProjectCreateReq projectCreateReq = buildProjectCreateReq();
        Project mock = buildSourceProject();
        when(projectRepository.save(mock)).thenReturn(mock);
        TargetProject res = projectService.addNewProject(projectCreateReq);
        assertProjectCorrect(res);
    }


    @Test
    void addNewProject_serverError() {
        ProjectCreateReq projectCreateReq = buildProjectCreateReq();
        Project mock = buildSourceProject();
        when(projectRepository.save(mock)).thenThrow(HibernateException.class);
        assertThrows(InternalServiceException.class,
                () -> projectService.addNewProject(projectCreateReq));
    }


    @Test
    void updateProject() {
        projectService.updateProject(buildProjectUpdateReq());
        verify(projectRepository, times(1))
                .updateProject(eq(PROJECT_CODE),
                        eq(PROJECT_NAME),
                        eq("NEW DESCRIPTION"),
                        eq(Date.valueOf(PROJECT_START_DATE)),
                        eq(Date.valueOf(PROJECT_END_DATE)));
    }

    @Test
    void retrieveProjectsByAccountNumber() {
        when(projectRepository.findAllByAccountNumber(eq(ACCOUNT_CODE)))
                .thenReturn(Collections.singletonList(buildSourceProject()));
        ProjectList res = projectService.retrieveProjectsByAccountNumber(ACCOUNT_CODE);
        assertEquals(1, res.getProjects().size());
        assertProjectCorrect(res.getProjects().get(0));
    }

    @Test
    void retrieveProjectsByAccountNumber_serverError() {
        when(projectRepository.findAllByAccountNumber(eq(ACCOUNT_CODE)))
                .thenThrow(HibernateException.class);
        assertThrows(InternalServiceException.class,
                () -> projectService.retrieveProjectsByAccountNumber(ACCOUNT_CODE));
    }

    @Test
    void retrieveProjectsByProjectManager() {
        when(projectRepository.findAllByProjectManagerId(eq(USER_ID)))
                .thenReturn(Collections.singletonList(buildSourceProject()));
        ProjectList res = projectService.retrieveProjectsByProjectManager(USER_ID);
        assertEquals(1, res.getProjects().size());
        assertProjectCorrect(res.getProjects().get(0));
    }

    @Test
    void retrieveProjectsByProjectManager_serverError() {
        when(projectRepository.findAllByProjectManagerId(eq(USER_ID)))
                .thenThrow(HibernateException.class);
        assertThrows(InternalServiceException.class,
                () -> projectService.retrieveProjectsByProjectManager(USER_ID));
    }
}