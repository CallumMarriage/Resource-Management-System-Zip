package callum.project.uni.rms.roles.service;

import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.RoleType;
import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.parent.exception.NotFoundException;
import callum.project.uni.rms.roles.service.model.Role;
import callum.project.uni.rms.roles.service.repository.RoleRepository;
import org.hibernate.HibernateException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;

import java.sql.Date;
import java.util.Optional;

import static callum.project.uni.rms.helpers.asserts.RoleAsserts.assertRole;
import static callum.project.uni.rms.helpers.builder.SourceRoleBuilder.buildSourceRole;
import static callum.project.uni.rms.helpers.builder.TargetRoleBuilder.buildRequestRole;
import static callum.project.uni.rms.helpers.builder.TargetRoleBuilder.buildTargetRole;
import static callum.project.uni.rms.helpers.constants.RoleConstants.*;
import static callum.project.uni.rms.helpers.constants.UserConstants.BUSINESS_UNIT_ID;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class RoleServiceTest {

    private RoleService roleService;
    private RoleRepository roleRepository;

    @BeforeEach
    void setUp() {
        roleRepository = mock(RoleRepository.class);
        roleService = new RoleService(roleRepository);
    }

    @Test
    void retrieveRoleById_happyPath() {
        when(roleRepository.findById(ArgumentMatchers.eq(ROLE_ID)))
                .thenReturn(Optional.of(buildSourceRole()));
        TargetRole result = roleService.retrieveRoleById(ROLE_ID);
        assertRole(result);
    }

    @Test
    void retrieveRoleById_notFound() {
        when(roleRepository.findById(ArgumentMatchers.eq(ROLE_ID)))
                .thenReturn(Optional.empty());
        assertThrows(NotFoundException.class,
                () -> roleService.retrieveRoleById(ROLE_ID));
    }

    @Test
    void retrieveRoleById_serverError() {
        when(roleRepository.findById(ArgumentMatchers.eq(ROLE_ID)))
                .thenThrow(HibernateException.class);
        assertThrows(InternalServiceException.class,
                () -> roleService.retrieveRoleById(ROLE_ID));
    }

    @Test
    void addNewRole_happyPath() {
        Role mockedRole = buildSourceRole();
        Role resMockedRole = buildSourceRole();

        mockedRole.setId(null);
        when(roleRepository.save(ArgumentMatchers.eq(mockedRole)))
                .thenReturn(resMockedRole);
        TargetRole res = roleService.addNewRole(buildRequestRole());
        assertRole(res);
    }

    @Test
    void addNewRole_serverError() {
        Role mockedRole = buildSourceRole();

        mockedRole.setId(null);
        when(roleRepository.save(ArgumentMatchers.eq(mockedRole)))
                .thenThrow(HibernateException.class);
        assertThrows(InternalServiceException.class,
                () -> roleService.addNewRole(buildRequestRole()));
    }


    @Test
    void updateRole_happyPath() {

        roleService.updateRole(buildTargetRole());

        verify(roleRepository, times(1)).updateRole(
                ArgumentMatchers.eq(ROLE_ID),
                ArgumentMatchers.eq(Date.valueOf(ROLE_START_DATE)),
                ArgumentMatchers.eq(ROLE_NAME),
                ArgumentMatchers.eq(BaseLocation.ASTON.ordinal()),
                ArgumentMatchers.eq(Date.valueOf(ROLE_END_DATE)),
                ArgumentMatchers.eq(ROLE_DESCRIPTION),
                ArgumentMatchers.eq(BUSINESS_UNIT_ID),
                ArgumentMatchers.eq(RoleType.SOFTWARE_ENGINEER.ordinal()),
                ArgumentMatchers.eq(CERTAINTY)
        );
    }

    @Test
    void updateRoleAsActive_happyPath(){

        roleService.updateRoleAsActive(ROLE_ID);
        verify(roleRepository).updateRoleOpen(eq(ROLE_ID), eq(false));
    }


    @Test
    void updateRoleAsActive_serverError(){

        doThrow(new HibernateException("error"))
                .when(roleRepository)
                .updateRoleOpen(eq(ROLE_ID), eq(false));

        assertThrows(InternalServiceException.class,
                () -> roleService.updateRoleAsActive(ROLE_ID));
    }


    @Test
    void updateRoleAsEnded_happyPath(){

        roleService.updateRoleAsEnded(ROLE_ID);
        verify(roleRepository).updateRoleOpen(eq(ROLE_ID), eq(true));
    }

    @Test
    void updateRoleAsEnded_serverError(){

        doThrow(new HibernateException("error"))
                .when(roleRepository)
                .updateRoleOpen(eq(ROLE_ID), eq(true));

        assertThrows(InternalServiceException.class,
                () -> roleService.updateRoleAsEnded(ROLE_ID));
    }

    @AfterEach
    void tearDown() {
    }
}