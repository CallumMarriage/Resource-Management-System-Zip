package callum.project.uni.rms.helpers.constants;

import callum.project.uni.rms.model.BaseLocation;

public class UserConstants {

    public static final Long AUTH_ID = 2L;
    public static final String AUTH_NAME = "Auth me";
    public static final String AUTH_SSO_ID = "3912941394139421921392";

    public static final Long BUSINESS_UNIT_ID = 4L;
    public static final String GRADE = "A1";
    public static final String USER_SSO_ID = "2801830283028310810281";
    public static final Long USER_ID = 1L;
    public static final String USER_NAME = "My Name";
    public static final BaseLocation USER_BASE_LOCATION = BaseLocation.ASTON;
}
