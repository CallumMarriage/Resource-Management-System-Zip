package callum.project.uni.rms.helpers.asserts;

import callum.project.uni.rms.candidates.model.UserType;
import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.RoleType;
import callum.project.uni.rms.candidates.model.target.TargetUser;
import callum.project.uni.rms.candidates.model.target.FullUserInfo;

import static callum.project.uni.rms.helpers.constants.RoleConstants.ROLE_ID;
import static callum.project.uni.rms.helpers.constants.UserConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class UserAsserts {

    public static void validateFullInfoResponseBody(FullUserInfo responseBody){
        TargetUser user = responseBody.getUser();
        assertUser(user, UserType.CANDIDATE);
    }

    public static void assertUser(TargetUser user, UserType userType){
        assertEquals(BaseLocation.ASTON, user.getBaseLocation());
        assertEquals(USER_ID, user.getId());
        assertEquals(USER_NAME, user.getFullName());
        assertEquals(userType, user.getUserType());
        assertEquals(RoleType.SOFTWARE_ENGINEER, user.getUserSpecialism());
        assertEquals(ROLE_ID, user.getCurrentRoleId());
        assertEquals(52.49616146003411, user.getBaseLocationX());
        assertEquals(-1.8848329963332042, user.getBaseLocationY());
        assertEquals(BUSINESS_UNIT_ID, user.getBusinessUnitId());
        assertEquals(GRADE, user.getGrade());
    }
}
