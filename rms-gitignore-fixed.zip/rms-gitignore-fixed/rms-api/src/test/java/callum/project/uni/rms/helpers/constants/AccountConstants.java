package callum.project.uni.rms.helpers.constants;

import java.time.LocalDate;

public class AccountConstants {

    public static final String ACCOUNT_CODE = "1234567890";
    public static final String ACCOUNT_NAME = "ACCOUNT_NAME";
    public static final String ACCOUNT_DESCRIPTION = "ACCOUNT_DESCRIPTION";
    public static final LocalDate ACCOUNT_START_DATE = LocalDate.now();
    public static final LocalDate ACCOUNT_END_DATE = LocalDate.now();
}
