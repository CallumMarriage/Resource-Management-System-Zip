package callum.project.uni.rms.project;

import callum.project.uni.rms.model.req.ProjectCreateReq;
import callum.project.uni.rms.model.req.ProjectUpdateReq;
import callum.project.uni.rms.model.res.TargetProject;
import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.model.res.projects.FullProjectInfo;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.roles.service.RoleListService;
import callum.project.uni.rms.roles.service.RoleService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;

import static callum.project.uni.rms.helpers.asserts.ProjectAsserts.assertProjectCorrect;
import static callum.project.uni.rms.helpers.asserts.RoleAsserts.assertRole;
import static callum.project.uni.rms.helpers.builder.TargetProjectsBuilder.*;
import static callum.project.uni.rms.helpers.builder.TargetRoleBuilder.buildTargetRole;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_CODE;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_NAME;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.*;
import static callum.project.uni.rms.helpers.constants.RoleConstants.*;
import static callum.project.uni.rms.helpers.constants.UserConstants.*;
import static java.util.Collections.singletonList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ProjectController.class)
class ProjectControllerTest {

    @Autowired
    private MockMvc mvc;


    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ProjectService projectService;

    @MockBean
    private RoleListService roleListService;

    @MockBean
    private RoleService roleService;

    @Test
    void retrieveTargetProject_happyPath() throws Exception {

        when(projectService.retrieveProjectById(eq(PROJECT_CODE)))
                .thenReturn(buildTargetProject());

        when(roleListService.retrieveAllRolesForProjectCode(eq(PROJECT_CODE)))
                .thenReturn(singletonList(buildTargetRole()));

        ResultActions resultActions = this.mvc.perform(get("/projects/id/" + PROJECT_CODE))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        FullProjectInfo accountInfo = objectMapper.readValue(contentAsString, FullProjectInfo.class);

        assertRole(accountInfo.getRoleList().get(0));
        assertProjectCorrect(accountInfo.getTargetProject());
    }

    @Test
    void retrieveTargetProject_serverError() throws Exception {

        when(projectService.retrieveProjectById(eq(PROJECT_CODE)))
                .thenThrow(InternalServiceException.class);

        this.mvc.perform(get("/projects/id/" + PROJECT_CODE))
                .andDo(print())
                .andExpect(status().isInternalServerError());
    }

    @Test
    void addNewProject_happyPath() throws Exception {

        ProjectCreateReq createReq = buildProjectCreateReq();
        when(projectService.addNewProject(eq(createReq)))
                .thenReturn(buildTargetProject());

        JSONObject createReqObj = new JSONObject();
        createReqObj.put("projectCode", PROJECT_CODE);
        createReqObj.put("accountNumber", ACCOUNT_CODE);
        createReqObj.put("description", PROJECT_DESC);
        createReqObj.put("projectManagerId", USER_ID);
        createReqObj.put("startDate", PROJECT_START_DATE.toString());
        createReqObj.put("endDate", PROJECT_END_DATE.toString());
        createReqObj.put("projectName", PROJECT_NAME);

        String reqJson = createReqObj.toString();

        ResultActions resultActions = this.mvc.perform(
                post("/project")
                        .content(reqJson)
                        .contentType("Application/json"))
                .andDo(print())
                .andExpect(status().isCreated());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        TargetProject project = objectMapper.readValue(contentAsString, TargetProject.class);
        assertProjectCorrect(project);
    }

    @Test
    void addNewProject_serverError() throws Exception {
        ProjectCreateReq createReq = buildProjectCreateReq();
        when(projectService.addNewProject(eq(createReq)))
                .thenThrow(InternalServiceException.class);

        JSONObject createReqObj = new JSONObject();
        createReqObj.put("projectCode", PROJECT_CODE);
        createReqObj.put("accountNumber", ACCOUNT_CODE);
        createReqObj.put("description", PROJECT_DESC);
        createReqObj.put("projectManagerId", USER_ID);
        createReqObj.put("startDate", PROJECT_START_DATE.toString());
        createReqObj.put("endDate", PROJECT_END_DATE.toString());
        createReqObj.put("projectName", PROJECT_NAME);

        String reqJson = createReqObj.toString();

        this.mvc.perform(
                post("/project")
                        .content(reqJson)
                        .contentType("Application/json"))
                .andExpect(status().isInternalServerError());
    }

    @Test
    void updateProject_happyPath() throws Exception {

        JSONObject createReqObj = new JSONObject();
        createReqObj.put("projectCode", PROJECT_CODE);
        createReqObj.put("accountNumber", ACCOUNT_CODE);
        createReqObj.put("description", PROJECT_DESC);
        createReqObj.put("projectManagerId", USER_ID);
        createReqObj.put("startDate", PROJECT_START_DATE.toString());
        createReqObj.put("endDate", PROJECT_END_DATE.toString());
        createReqObj.put("projectName", PROJECT_NAME);

        JSONArray updateRoles = new JSONArray();

        updateRoles.put(buildRole(1L));
        updateRoles.put(buildRole(2L));
        updateRoles.put(buildRole(3L));

        createReqObj.put("updatedRoles", updateRoles);

        JSONArray newRoles = new JSONArray();
        newRoles.put(buildRole(null));
        newRoles.put(buildRole(null));
        newRoles.put(buildRole(null));
        createReqObj.put("newRoles", updateRoles);

        this.mvc.perform(put("/project/update")
                .content(createReqObj.toString())
                .contentType("Application/json"))
                .andExpect(status().isNoContent());

        verify(projectService, times(1)).updateProject(any(ProjectUpdateReq.class));
        verify(roleService, times(3)).updateRole(any(TargetRole.class));
        verify(roleListService, times(1)).addNewRoles(any(ArrayList.class));
    }

    @Test
    void updateProject_serverError(){

    }

    private JSONObject buildRole(Long id){
        JSONObject targetRole = new JSONObject();

        targetRole.put("accountName", ACCOUNT_NAME);
        targetRole.put("accountNumber", ACCOUNT_CODE);
        targetRole.put("description", ROLE_DESCRIPTION);
        targetRole.put("roleName", ROLE_NAME);
        targetRole.put("projectCode", PROJECT_CODE);
        targetRole.put("projectName", PROJECT_NAME);
        targetRole.put("businessUnit", BUSINESS_UNIT_ID);
        targetRole.put("grade", GRADE.toString());
        targetRole.put("certainty", CERTAINTY.toString());
        targetRole.put("startDate", ROLE_START_DATE.toString());
        targetRole.put("endDate", ROLE_END_DATE.toString());
        if(id != null){
            targetRole.put("id", id);
        }
        return targetRole;
    }
//
//
//    @PutMapping(value = "/project/update")
//    @ResponseStatus(HttpStatus.NO_CONTENT)
//    public void updateProject(@RequestBody ProjectUpdateReq projectUpdateReq) {
//        projectService.updateProject(projectUpdateReq);
//        roleListService.addNewRoles(projectUpdateReq.getNewRoles());
//        for (TargetRole upRole : projectUpdateReq.getUpdatedRoles()) {
//            roleService.updateRole(upRole);
//        }
//    }
}