package callum.project.uni.rms.candidates;

import callum.project.uni.rms.candidates.UserRepository;
import callum.project.uni.rms.candidates.UserService;
import callum.project.uni.rms.candidates.model.request.UserCreateReq;
import callum.project.uni.rms.candidates.model.source.User;
import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.helpers.builder.TargetUserBuilder;
import callum.project.uni.rms.candidates.model.target.TargetUser;
import callum.project.uni.rms.candidates.model.target.UserExist;

import callum.project.uni.rms.parent.exception.InternalServiceException;
import org.hibernate.HibernateException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static callum.project.uni.rms.helpers.constants.RoleConstants.ROLE_ID;
import static callum.project.uni.rms.helpers.constants.UserConstants.USER_ID;
import static callum.project.uni.rms.helpers.constants.UserConstants.USER_SSO_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    private UserService userService;

    @Mock
    private UserRepository userRepository;


    @BeforeEach
    void setUp() {
        userService = new UserService(userRepository);
    }

    @Test
    @DisplayName("When user repository returns a valid user, then user exists should return true")
    void userExists_returnsTrue() throws InternalServiceException {

        User user = new User();
        user.setSsoId(USER_SSO_ID);
        user.setId(USER_ID);
        user.setCurrentRoleId(ROLE_ID);
        user.setBaseLocation(BaseLocation.ASTON);

        when(userRepository.findBySsoId(any(String.class)))
                .thenReturn(Optional.of(user));
        UserExist userExist = userService.userExists(USER_SSO_ID);
        assertTrue(userExist.isUserExist());
    }

    @Test
    void userExists_returnsFalse() throws InternalServiceException {
        when(userRepository.findBySsoId(any(String.class)))
                .thenReturn(Optional.empty());

        assertFalse(userService.userExists(USER_SSO_ID).isUserExist());
    }

    @Test
    void createUser_happyPath() throws InternalServiceException {
        User user = new User();
        user.setSsoId(USER_SSO_ID);
        user.setId(USER_ID);
        user.setCurrentRoleId(ROLE_ID);
        user.setBaseLocation(BaseLocation.ASTON);

        when(userRepository.save(any(User.class)))
                .thenReturn(user);

        UserCreateReq createReq = TargetUserBuilder.buildCreateReq();

        TargetUser targetUser = userService.createUser(createReq);
        assertAll("Assert all user params are correct",
                () -> assertEquals(1, targetUser.getId()),
                () -> assertEquals(ROLE_ID, targetUser.getCurrentRoleId()));
    }

    @Test
    void createUser_sqlException() {
        when(userRepository.save(any(User.class)))
                .thenThrow(HibernateException.class);

        assertThrows(InternalServiceException.class,() -> userService.createUser(new UserCreateReq()));
    }

    @AfterEach
    void tearDown() {
    }
}