package callum.project.uni.rms.roles.service;

import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.model.res.role.RoleList;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.roles.service.model.Role;
import callum.project.uni.rms.roles.service.repository.RoleRepository;
import org.assertj.core.util.Lists;
import org.hibernate.HibernateException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.TemporalUnit;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static callum.project.uni.rms.helpers.builder.SourceRoleBuilder.buildSourceRole;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.PROJECT_CODE;
import static callum.project.uni.rms.helpers.constants.UserConstants.BUSINESS_UNIT_ID;
import static callum.project.uni.rms.helpers.constants.UserConstants.USER_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RoleListServiceTest {

    private RoleListService roleListService;
    private RoleRepository roleRepository;

    @BeforeEach
    void setUp() {
        roleRepository = mock(RoleRepository.class);
        roleListService = new RoleListService(roleRepository);
    }

    @Test
    void retrieveAllRolesForProjectCode_happyPath() {
        Role roleEarly = buildSourceRole();
        roleEarly.setStartDate(Date.valueOf(LocalDate.of(1999,1, 1)));
        Role roleMiddle = buildSourceRole();
        roleMiddle.setStartDate(Date.valueOf(LocalDate.of(2000,1, 1)));
        Role roleLatest = buildSourceRole();
        roleLatest.setStartDate(Date.valueOf(LocalDate.of(2020,1, 1)));

        List<Role> mockedRes = List.of(roleMiddle, roleLatest, roleEarly);

        when(roleRepository.findAllByProjectCode(eq(PROJECT_CODE)))
                .thenReturn(mockedRes);

        List<TargetRole> res = roleListService.retrieveAllRolesForProjectCode(PROJECT_CODE);
        assertEquals(LocalDate.of(1999,1, 1), res.get(0).getStartDate());
        assertEquals(LocalDate.of(2000,1, 1), res.get(1).getStartDate());
        assertEquals(LocalDate.of(2020,1, 1), res.get(2).getStartDate());
    }

    @Test
    void retrieveAllRolesForProjectCode_empty() {


        when(roleRepository.findAllByProjectCode(eq(PROJECT_CODE)))
                .thenReturn(Lists.emptyList());

        List<TargetRole> res = roleListService.retrieveAllRolesForProjectCode(PROJECT_CODE);
        assertTrue(res.isEmpty());
    }


    @Test
    void retrieveAllRolesForProjectCode_servError() {

        when(roleRepository.findAllByProjectCode(eq(PROJECT_CODE)))
                .thenThrow(HibernateException.class);

        assertThrows(InternalServiceException.class, () -> roleListService.retrieveAllRolesForProjectCode(PROJECT_CODE));
    }

    @Test
    void retrieveAllOpenRoles() {
        LocalDate oldDate = LocalDate.now().minusDays(1);
        LocalDate currentDate = LocalDate.now();
        LocalDate futureDate = LocalDate.now().plusYears(1);

        // Should be returned
        Role outDatedRole = buildSourceRole();
        outDatedRole.setIsRoleOpen(true);
        outDatedRole.setEndDate(Date.valueOf(oldDate));
        Role currentRole = buildSourceRole();
        currentRole.setIsRoleOpen(true);
        currentRole.setEndDate(Date.valueOf(currentDate));
        Role noEndDateRole = buildSourceRole();
        noEndDateRole.setIsRoleOpen(true);
        noEndDateRole.setEndDate(null);

        // Should be returned
        Role futureRole = buildSourceRole();
        futureRole.setIsRoleOpen(true);
        futureRole.setEndDate(Date.valueOf(futureDate));


        when(roleRepository.findAllByIsRoleOpenIsTrue())
                .thenReturn( List.of(outDatedRole, currentRole, futureRole));

        RoleList res = roleListService.retrieveAllOpenRoles();
        assertEquals(1, res.getRoleList().size());
        assertEquals(futureDate, res.getRoleList().get(0).getEndDate());
    }

    @Test
    void retrieveRolesForBusinessUnit() {

        Role correct = buildSourceRole();
        correct.setIsRoleOpen(true);
        correct.setBusinessUnitId(BUSINESS_UNIT_ID);

        when(roleRepository.findAllByBusinessUnitIdAndIsRoleOpenIsTrue(eq(BUSINESS_UNIT_ID)))
                .thenReturn(List.of(correct));

        RoleList res = roleListService.retrieveRolesForBusinessUnit(BUSINESS_UNIT_ID);
        assertEquals(1, res.getRoleList().size());
        assertEquals(BUSINESS_UNIT_ID, res.getRoleList().get(0).getBusinessUnit());
        assertTrue(res.getRoleList().get(0).getIsRoleOpen());
    }

    @Test
    void retrieveRoleHistory() {

        Role correct = buildSourceRole();

        when(roleRepository.findRolesForUser(eq(USER_ID)))
                .thenReturn(List.of(correct));

        RoleList res = roleListService.retrieveRoleHistory(USER_ID);
        assertEquals(1, res.getRoleList().size());
    }

    @Test
    void retrieveForProjectId() {
        Role correct = buildSourceRole();

        when(roleRepository.findAllByProjectCode(eq(PROJECT_CODE)))
                .thenReturn(List.of(correct));

        List<TargetRole> res = roleListService.retrieveAllRolesForProjectCode(PROJECT_CODE);
        assertEquals(1, res.size());
        assertEquals(PROJECT_CODE, res.get(0).getProjectCode());
    }
    
    @Test
    void retrieveOpenRolesForProject() {
        Role correct = buildSourceRole();

        when(roleRepository.findAllByProjectCodeAndIsRoleOpenTrue(eq(PROJECT_CODE)))
                .thenReturn(List.of(correct));

        RoleList res = roleListService.retrieveOpenRolesForProject(PROJECT_CODE);
        assertEquals(1, res.getRoleList().size());
        assertEquals(PROJECT_CODE, res.getRoleList().get(0).getProjectCode());
        assertTrue(res.getRoleList().get(0).getIsRoleOpen());
    }
}