package callum.project.uni.rms.roles;

import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.roles.service.RoleService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.lang.NonNull;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import static callum.project.uni.rms.helpers.asserts.RoleAsserts.assertRole;
import static callum.project.uni.rms.helpers.builder.TargetRoleBuilder.buildTargetRole;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_CODE;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_NAME;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.PROJECT_CODE;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.PROJECT_NAME;
import static callum.project.uni.rms.helpers.constants.RoleConstants.*;
import static callum.project.uni.rms.helpers.constants.UserConstants.BUSINESS_UNIT_ID;
import static callum.project.uni.rms.helpers.constants.UserConstants.GRADE;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(RoleController.class)
class RoleControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private RoleService roleService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void postRole() throws Exception {
        when(roleService.addNewRole(any()))
                .thenReturn(buildTargetRole());

        JSONObject createReqObj = new JSONObject();
        createReqObj.put("accountName", ACCOUNT_NAME);
        createReqObj.put("accountNumber", ACCOUNT_CODE);
        createReqObj.put("description", ROLE_DESCRIPTION);
        createReqObj.put("roleName", ROLE_NAME);
        createReqObj.put("projectCode", PROJECT_CODE);
        createReqObj.put("projectName", PROJECT_NAME);
        createReqObj.put("baseLocation", "ASTON");
        createReqObj.put("businessUnit", BUSINESS_UNIT_ID);
        createReqObj.put("grade", GRADE.toString());
        createReqObj.put("certainty", CERTAINTY.toString());
        createReqObj.put("startDate", ROLE_START_DATE.toString());
        createReqObj.put("endDate", ROLE_END_DATE.toString());

        String reqJson = createReqObj.toString();

        ResultActions resultActions = this.mvc.perform(
                post("/role")
                        .content(reqJson)
                        .contentType("Application/json"))
                .andDo(print())
                .andExpect(status().isCreated());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        TargetRole role = objectMapper.readValue(contentAsString, TargetRole.class);

        assertRole(role);
    }

    @Test
    void getTargetRole() throws Exception{
        when(roleService.retrieveRoleById(eq(ROLE_ID)))
                .thenReturn(buildTargetRole());

        ResultActions resultActions = this.mvc.perform(
                get("/role/"+ ROLE_ID))
                .andDo(print())
                .andExpect(status().isOk());

        MvcResult result = resultActions.andReturn();
        String contentAsString = result.getResponse().getContentAsString();

        TargetRole role = objectMapper.readValue(contentAsString, TargetRole.class);

        assertRole(role);
    }

    @PutMapping(value = "/role/{roleId}/complete")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void putLeaveRole(@PathVariable("roleId") @NonNull Long roleId) {
        roleService.updateRoleAsEnded(roleId);
    }


    @Test
    void putLeaveRole() throws Exception {
        this.mvc.perform(
                put("/role/"+ ROLE_ID +"/complete"))
                .andDo(print())
                .andExpect(status().isNoContent());

        verify(roleService, times(1)).updateRoleAsEnded(eq(ROLE_ID));
    }

    @Test
    void putRoleActive() throws Exception {
        this.mvc.perform(
                put("/role/"+ ROLE_ID +"/active"))
                .andDo(print())
                .andExpect(status().isNoContent());
        verify(roleService, times(1)).updateRoleAsActive(eq(ROLE_ID));

    }
}