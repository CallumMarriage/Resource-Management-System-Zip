package callum.project.uni.rms.helpers.builder;

import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.req.ProjectCreateReq;
import callum.project.uni.rms.model.req.ProjectUpdateReq;
import callum.project.uni.rms.model.res.TargetProject;
import callum.project.uni.rms.model.res.projects.ProjectList;

import java.util.List;

import static callum.project.uni.rms.helpers.builder.TargetRoleBuilder.buildRequestRole;
import static callum.project.uni.rms.helpers.builder.TargetRoleBuilder.buildTargetRole;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_CODE;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.*;
import static callum.project.uni.rms.helpers.constants.UserConstants.USER_ID;
import static java.util.Collections.singletonList;

public class TargetProjectsBuilder {

    public static ProjectList buildProjectsForAccount() {
        return ProjectList.builder()
                .projects(singletonList(
                        buildTargetProject()))
                .build();
    }

    public static TargetProject buildTargetProject(){
        return  TargetProject.builder()
                .accountNumber(ACCOUNT_CODE)
                .projectCode(PROJECT_CODE)
                .startDate(PROJECT_START_DATE)
                .endDate(PROJECT_END_DATE)
                .description(PROJECT_DESC)
                .projectName(PROJECT_NAME)
                .build();
    }

    public static ProjectCreateReq buildProjectCreateReq(){
        return ProjectCreateReq.builder()
                .accountNumber(ACCOUNT_CODE)
                .description(PROJECT_DESC)
                .startDate(PROJECT_START_DATE)
                .endDate(PROJECT_END_DATE)
                .projectCode(PROJECT_CODE)
                .projectName(PROJECT_NAME)
                .projectManagerId(USER_ID)
                .build();
    }

    public static ProjectUpdateReq buildProjectUpdateReq(){
        return ProjectUpdateReq.builder()
                .projectCode(PROJECT_CODE)
                .accountNumber(ACCOUNT_CODE)
                .description("NEW DESCRIPTION")
                .projectName(PROJECT_NAME)
                .endDate(PROJECT_END_DATE)
                .startDate(PROJECT_START_DATE)
                .projectManagerId(USER_ID)
                .newRoles(List.of(buildRequestRole(), buildRequestRole(), buildRequestRole()))
                .updatedRoles(List.of(buildTargetRole(), buildTargetRole()))
                .build();
    }
}
