package callum.project.uni.rms.helpers.asserts;

import callum.project.uni.rms.model.res.TargetAccount;

import static callum.project.uni.rms.helpers.constants.AccountConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AccountAsserts {

    public static void assertAccountIsCorrect(TargetAccount account) {
        assertEquals(ACCOUNT_CODE, account.getAccountCode());
        assertEquals(1L, account.getAccountManagerId());
        assertEquals(ACCOUNT_NAME, account.getAccountName());
        assertEquals(ACCOUNT_DESCRIPTION, account.getDescription());
        assertEquals(ACCOUNT_START_DATE, account.getStartDate());
        assertEquals(ACCOUNT_END_DATE, account.getEndDate());
    }

}
