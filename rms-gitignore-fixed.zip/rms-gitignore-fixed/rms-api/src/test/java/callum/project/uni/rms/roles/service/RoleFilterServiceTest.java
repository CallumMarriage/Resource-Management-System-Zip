package callum.project.uni.rms.roles.service;

import callum.project.uni.rms.model.res.role.RoleList;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.roles.service.RoleFilterService;
import callum.project.uni.rms.roles.service.repository.RoleRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static callum.project.uni.rms.helpers.RoleBuilder.createDbRoles;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class RoleFilterServiceTest {

    private RoleFilterService roleFilterService;

    @BeforeEach
    public void setup(){
        RoleRepository roleRepository = mock(RoleRepository.class);
        roleFilterService = new RoleFilterService(roleRepository);
        when(roleRepository.findAllByIsRoleOpenIsTrue())
                .thenReturn(createDbRoles());
    }

    @Test
    void testAccountsMatch() throws InternalServiceException {
        RoleList res = roleFilterService.runFilters("AccountNam",
                null, null, null, null);
        assertEquals(1, res.getRoleList().size());
        assertEquals("AccountNam", res.getRoleList()
                .get(0)
                .getAccountName());
    }

    @Test
    void testAccountNotSufficient() throws InternalServiceException {
        RoleList res = roleFilterService.runFilters("Acco",
                null, null, null, null);
        assertEquals(0, res.getRoleList().size());
    }

    @Test
    void testAccountJustSufficient() throws InternalServiceException {
        RoleList res = roleFilterService.runFilters("Accou",
                null, null, null, null);
        assertEquals(1, res.getRoleList().size());
        assertEquals("AccountNam", res.getRoleList()
                .get(0)
                .getAccountName());
    }

    @Test
    void testProjectNotSufficient() throws InternalServiceException {

        RoleList res = roleFilterService.runFilters(null,
                "Pro", null, null, null);
        assertEquals(0, res.getRoleList().size());
    }

    @Test
    void testProjectJustSufficient() throws InternalServiceException {
        RoleList res = roleFilterService.runFilters(null, "Proje",
                null, null, null);
        assertEquals(1, res.getRoleList().size());
        assertEquals("ProjectTes", res.getRoleList()
                .get(0)
                .getProjectName());
    }

    @Test
    void testEndDate_after() throws InternalServiceException {
        RoleList res = roleFilterService.runFilters(
                null, null,
                null, null, LocalDate.now().plusYears(2));
        assertEquals(3, res.getRoleList().size());
    }


    @Test
    void testEndDate_before() throws InternalServiceException {
        RoleList res = roleFilterService.runFilters(
                null, null,
                null, null, LocalDate.now());
        assertEquals(0, res.getRoleList().size());
    }

    @Test
    void testStartDate_before() throws InternalServiceException {
        RoleList res = roleFilterService.runFilters(
                null, null,
                null, LocalDate.now().minusDays(1), null);
        assertEquals(3, res.getRoleList().size());
    }

    @Test
    void testStartDate_after() throws InternalServiceException {
        RoleList res = roleFilterService.runFilters(
                null, null,
                null, LocalDate.now().minusDays(1), null);
        assertEquals(3, res.getRoleList().size());
    }

    @Test
    void testStartDate_and_endDate() throws InternalServiceException {
        RoleList res = roleFilterService.runFilters(
                null, null,
                null, LocalDate.now().minusDays(1), LocalDate.now().plusYears(2));
        assertEquals(3, res.getRoleList().size());
    }
}
