package callum.project.uni.rms.helpers;

import callum.project.uni.rms.account.Account;

import java.sql.Date;

import static callum.project.uni.rms.helpers.constants.AccountConstants.*;
import static callum.project.uni.rms.helpers.constants.UserConstants.USER_ID;

public class AccountBuilder {

    public static Account buildSourceAccount(){
        return Account.builder()
                .accountManagerId(USER_ID)
                .accountName(ACCOUNT_NAME)
                .accountNumber(ACCOUNT_CODE)
                .description(ACCOUNT_DESCRIPTION)
                .endDate(Date.valueOf(ACCOUNT_END_DATE))
                .startDate(Date.valueOf(ACCOUNT_START_DATE))
                .build();
    }
}
