package callum.project.uni.rms.helpers.builder;

import callum.project.uni.rms.model.req.AccountCreateReq;
import callum.project.uni.rms.model.res.TargetAccount;

import static callum.project.uni.rms.helpers.constants.AccountConstants.*;

public class TargetAccountsBuilder {

    public static TargetAccount buildMockAccount() {
        return TargetAccount.builder()
                .accountCode(ACCOUNT_CODE)
                .accountManagerId(1L)
                .accountName(ACCOUNT_NAME)
                .description(ACCOUNT_DESCRIPTION)
                .endDate(ACCOUNT_START_DATE)
                .startDate(ACCOUNT_END_DATE)
                .build();
    }
    
    public static AccountCreateReq buildAccountCreateReq(){
        return AccountCreateReq.builder()
                .accountName(ACCOUNT_NAME)
                .accountNumber(ACCOUNT_CODE)
                .accountManagerId(1L)
                .description(ACCOUNT_DESCRIPTION)
                .startDate(ACCOUNT_START_DATE)
                .endDate(ACCOUNT_END_DATE)
                .build();
    }
    
}
