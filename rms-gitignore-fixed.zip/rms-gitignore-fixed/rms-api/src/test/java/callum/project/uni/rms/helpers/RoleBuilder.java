package callum.project.uni.rms.helpers;

import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.RoleType;
import callum.project.uni.rms.roles.service.model.Role;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_NAME;
import static callum.project.uni.rms.helpers.constants.ProjectConstants.*;
import static callum.project.uni.rms.helpers.constants.RoleConstants.*;

public class RoleBuilder {
    
    
    public static List<Role> createDbRoles(){
        return List.of(
                createDbRole(1, "AccountNam", "Can", RoleType.BUSINESS_ANALYST),
                createDbRole(2, "My Loeipe", "ProjectTes", RoleType.SOFTWARE_ENGINEER),
                createDbRole(3, "iS THE NM", "TO BE CONT", RoleType.PROJECT_MANAGER)

        );
    }

    public static Role createDbRole(long id, String accountName, String projectName, RoleType roleType){
        return Role.builder()
                .accountName(accountName)
                .projectName(projectName)
                .roleType(roleType)
                .isRoleOpen(true)
                .baseLocation(BaseLocation.ASTON)
                .id(id)
                .startDate(Date.valueOf(LocalDate.now()))
                .endDate(Date.valueOf(LocalDate.now().plusYears(1)))
                .build();
    }

    public static Role createDbRole(){
        return Role.builder()
                .accountName(ACCOUNT_NAME)
                .projectName(PROJECT_NAME)
                .roleType(RoleType.SOFTWARE_ENGINEER)
                .isRoleOpen(true)
                .baseLocation(BaseLocation.ASTON)
                .id(ROLE_ID)
                .startDate(DB_ROLE_START_DATE)
                .endDate(DB_ROLE_END_DATE)
                .build();
    }
}
