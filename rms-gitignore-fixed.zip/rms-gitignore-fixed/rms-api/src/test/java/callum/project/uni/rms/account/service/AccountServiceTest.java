package callum.project.uni.rms.account.service;

import callum.project.uni.rms.account.Account;
import callum.project.uni.rms.model.res.AbstractServiceResponse;
import callum.project.uni.rms.model.res.TargetAccount;
import callum.project.uni.rms.model.res.accounts.AccountList;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.parent.exception.NotFoundException;
import org.hibernate.HibernateException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.List;
import java.util.Optional;

import static callum.project.uni.rms.helpers.AccountBuilder.buildSourceAccount;
import static callum.project.uni.rms.helpers.asserts.AccountAsserts.assertAccountIsCorrect;
import static callum.project.uni.rms.helpers.builder.TargetAccountsBuilder.buildAccountCreateReq;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_CODE;
import static callum.project.uni.rms.helpers.constants.AccountConstants.ACCOUNT_NAME;
import static callum.project.uni.rms.helpers.constants.UserConstants.USER_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class AccountServiceTest {

    private AccountService accountService;

    private AccountRepository accountRepository;


    @BeforeEach
    void setUp() {
        accountRepository = mock(AccountRepository.class);
        accountService = new AccountService(accountRepository);
    }

    @Test
    @DisplayName("Test account service get accounts happy path")
    void getAccountsList_happyPath() throws InternalServiceException {
        Account account = buildSourceAccount();

        List<Account> accountsIterable = List.of(account);

        when(accountRepository.findAll()).thenReturn(accountsIterable);

        AccountList accountList = accountService.retrieveAccountList(null);
        assertEquals(1, accountList.getAccountList().size());
        TargetAccount targetAccount = accountList.getAccountList().get(0);
        assertAccountIsCorrect(targetAccount);
    }


    @Test
    @DisplayName("Test account service get accounts happy path")
    void getAccountsList_managerId_happyPath() throws InternalServiceException {
        Account account = buildSourceAccount();

        List<Account> accountsIterable = List.of(account);

        when(accountRepository.findAllByAccountManagerId(eq(USER_ID)))
                .thenReturn(accountsIterable);

        AccountList accountList = accountService.retrieveAccountList(USER_ID);

        assertEquals(1, accountList.getAccountList().size());
        TargetAccount targetAccount = accountList.getAccountList().get(0);
        assertAccountIsCorrect(targetAccount);
    }
    
    @GetMapping(value = "/account", params = "accountName")
    @ResponseStatus(HttpStatus.OK)
    public AbstractServiceResponse retrieveAccountList(@RequestParam @NonNull String accountName) {
        return accountService.retrieveAccountByName(accountName);
    }

    @Test
    @DisplayName("Test account service get accounts happy path")
    void getAccountsList_managerId_serverError() throws InternalServiceException {

        when(accountRepository.findAllByAccountManagerId(eq(USER_ID)))
                .thenThrow(HibernateException.class);

        assertThrows(InternalServiceException.class,
                () -> accountService.retrieveAccountList(USER_ID));;
    }

    @Test
    void retrieveAccountByName_happyPath(){
        when(accountRepository.findFirstByAccountName(eq(ACCOUNT_NAME)))
                .thenReturn(Optional.of(buildSourceAccount()));

        TargetAccount res = accountService.retrieveAccountByName(ACCOUNT_NAME);
        assertAccountIsCorrect(res);
    }

    @Test
    void retrieveAccountByName_notfound(){
        when(accountRepository.findFirstByAccountName(eq(ACCOUNT_NAME)))
                .thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> accountService.retrieveAccountByName(ACCOUNT_NAME));
    }

    @Test
    void retrieveAccountByName_serverError(){
        when(accountRepository.findFirstByAccountName(eq(ACCOUNT_NAME)))
                .thenThrow(HibernateException.class);

        assertThrows(InternalServiceException.class,
                () -> accountService.retrieveAccountByName(ACCOUNT_NAME));
    }

    @Test
    void retrieveAccountByAccountCode_happyPath(){
        when(accountRepository.findById(eq(ACCOUNT_NAME)))
                .thenReturn(Optional.of(buildSourceAccount()));

        TargetAccount res = accountService.retrieveTargetAccountById(ACCOUNT_NAME);
        assertAccountIsCorrect(res);
    }

    @Test
    void retrieveAccountByAccountCode_notfound(){
        when(accountRepository.findById(eq(ACCOUNT_CODE)))
                .thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> accountService.retrieveTargetAccountById(ACCOUNT_NAME));
    }

    @Test
    void retrieveAccountByAccountCode_serverError(){
        when(accountRepository.findById(eq(ACCOUNT_NAME)))
                .thenThrow(HibernateException.class);

        assertThrows(InternalServiceException.class,
                () -> accountService.retrieveTargetAccountById(ACCOUNT_NAME));
    }

    @Test
    void addNewAccount_happyPath(){
        when(accountRepository.save(buildSourceAccount()))
                .thenReturn(buildSourceAccount());

        TargetAccount res = accountService.addNewAccount(buildAccountCreateReq());
        assertAccountIsCorrect(res);
    }

    @Test
    void addNewAccount_serverError(){
        when(accountRepository.save(buildSourceAccount()))
                .thenThrow(HibernateException.class);

        assertThrows(InternalServiceException.class,
                () -> accountService.addNewAccount(buildAccountCreateReq()));
    }

    @Test
    void isAccountAvailable_happyPath(){
        when(accountRepository.findById(eq(ACCOUNT_CODE)))
                .thenReturn(Optional.of(buildSourceAccount()));
        assertTrue(accountService.isAccountAvailable(ACCOUNT_CODE));
    }

    @Test
    void isAccountAvailable_notFound(){
        when(accountRepository.findById(eq(ACCOUNT_CODE)))
                .thenReturn(Optional.empty());
        assertFalse(accountService.isAccountAvailable(ACCOUNT_CODE));
    }


    @Test
    void isAccountAvailable_serverError(){
        when(accountRepository.findById(eq(ACCOUNT_CODE)))
                .thenThrow(HibernateException.class);
        assertThrows(InternalServiceException.class,
                () -> accountService.isAccountAvailable(ACCOUNT_CODE));
    }

}