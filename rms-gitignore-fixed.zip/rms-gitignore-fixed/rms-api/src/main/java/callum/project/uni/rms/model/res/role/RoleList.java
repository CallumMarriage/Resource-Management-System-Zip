package callum.project.uni.rms.model.res.role;

import callum.project.uni.rms.model.res.AbstractServiceResponse;
import callum.project.uni.rms.model.res.TargetRole;
import lombok.*;

import java.util.List;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RoleList extends AbstractServiceResponse {

    private List<TargetRole> roleList;

}
