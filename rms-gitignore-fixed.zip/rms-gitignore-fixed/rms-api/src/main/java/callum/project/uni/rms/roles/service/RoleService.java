package callum.project.uni.rms.roles.service;

import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.parent.exception.NotFoundException;
import callum.project.uni.rms.roles.model.RequestRole;
import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.roles.service.mapper.RoleMapper;
import callum.project.uni.rms.roles.service.model.Role;
import callum.project.uni.rms.roles.service.repository.RoleRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.HibernateException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional
@Slf4j
@AllArgsConstructor
public class RoleService {

    private final RoleRepository roleRepository;
    
    public TargetRole retrieveRoleById(Long roleId) {
        Optional<Role> roleOptional;

        try {
            roleOptional = roleRepository.findById(roleId);

            return RoleMapper.mapDBToTargetModel(roleOptional.orElseThrow(() ->
                    new NotFoundException("Role not found")));

        } catch (HibernateException e) {
            throw new InternalServiceException("Error building response object", e);
        }
    }

    public TargetRole addNewRole(RequestRole requestRole) {

        try {
            Role role = RoleMapper.mapRequestToDbModel(requestRole);
            return RoleMapper.mapDBToTargetModel(roleRepository.save(role));
        } catch (HibernateException e) {
            throw new InternalServiceException("Issue adding new role", e);
        }
    }

    public void updateRole(TargetRole updatedRole){
        try {
            Role role = RoleMapper.mapTargetToDbModel(updatedRole);
            roleRepository.updateRole(updatedRole.getId(),
                    role.getStartDate(),
                    role.getRoleName(),
                    role.getBaseLocation().ordinal(),
                    role.getEndDate(),
                    role.getDescription(),
                    role.getBusinessUnitId(),
                    role.getRoleType().ordinal(),
                    role.getCertainty());
        } catch (HibernateException e) {
            log.error(e.getMessage());
            throw new InternalServiceException("Issue adding new role", e);
        }
    }

    public void updateRoleAsActive(Long roleId) {
        try {
            roleRepository.updateRoleOpen(roleId, false);

        } catch (HibernateException e) {
            log.error(e.getMessage());
            throw new InternalServiceException(e.getMessage(), e);
        }
    }

    public void updateRoleAsEnded(Long roleId) {
        try {
            roleRepository.updateRoleOpen(roleId, true);

        } catch (HibernateException e) {
            throw new InternalServiceException(e.getMessage(), e);
        }
    }
}
