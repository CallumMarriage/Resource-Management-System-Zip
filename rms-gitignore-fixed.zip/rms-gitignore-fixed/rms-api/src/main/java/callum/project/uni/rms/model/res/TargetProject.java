package callum.project.uni.rms.model.res;

import callum.project.uni.rms.model.BaseLocation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@AllArgsConstructor
@Data
@Builder
public class TargetProject extends AbstractServiceResponse {

    private String projectName;

    private String projectCode;

    private String accountNumber;

    private String description;

    private LocalDate startDate;

    private LocalDate endDate;
}
