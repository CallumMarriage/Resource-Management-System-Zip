package callum.project.uni.rms.project;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;

@Repository
public interface ProjectRepository extends CrudRepository<Project, String> {

    List<Project> findAllByAccountNumber(String accountNumber);

    List<Project> findAllByProjectManagerId(Long projectManagerId);

    @Modifying(clearAutomatically = true)
    @Query(value = "update project p set p.project_name =:projectName, p.description =:description, p.start_date =:startDate, p.end_date =:endDate where p.project_code =:projectCode", nativeQuery = true)
    void updateProject(@Param("projectCode") String projectCode,
                       @Param("projectName") String projectName,
                       @Param("description") String description,
                       @Param("startDate") Date startDate,
                       @Param("endDate") Date endDate);
}
