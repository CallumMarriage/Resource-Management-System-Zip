package callum.project.uni.rms.account;

import callum.project.uni.rms.account.service.AccountService;
import callum.project.uni.rms.account.service.AccountFullInfoService;
import callum.project.uni.rms.model.req.AccountCreateReq;
import callum.project.uni.rms.model.res.AbstractServiceResponse;
import callum.project.uni.rms.model.res.TargetAccount;
import callum.project.uni.rms.model.res.accounts.FullAccountInfo;
import callum.project.uni.rms.model.res.projects.ProjectList;
import callum.project.uni.rms.project.ProjectService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Slf4j
@AllArgsConstructor
public class AccountController {

    private final AccountService accountService;

    // REMOVE PROJECT SERVICE FOR SQL
    private final ProjectService projectService;

    private final AccountFullInfoService projectAndAccountService;

    @GetMapping(value = "/account/id/{accountNumber}")
    @ResponseStatus(HttpStatus.OK)
    public AbstractServiceResponse retrieveTargetAccount(@PathVariable @NonNull String accountNumber) {

        //Call Service to get response object
        TargetAccount serviceResponse = accountService.retrieveTargetAccountById(accountNumber);

        ProjectList projectsForAccount = projectService.retrieveProjectsByAccountNumber(serviceResponse.getAccountCode());

        //Return ok response
        return FullAccountInfo.builder()
                .account(serviceResponse)
                .projectList(projectsForAccount.getProjects())
                .build();
    }

    @GetMapping(value = "/accounts")
    @ResponseStatus(HttpStatus.OK)
    public AbstractServiceResponse retrieveAccounts(@RequestParam(required = false)
                                                            Long accountManagerId) {
        return accountService.retrieveAccountList(accountManagerId);
    }

    @GetMapping(value = "/account/{accountNumber}/available")
    @ResponseStatus(HttpStatus.OK)
    public AbstractServiceResponse checkIfAccountNumberAvailable(@PathVariable String accountNumber){
        boolean available = accountService.isAccountAvailable(accountNumber);
        return new AccountAvailable(available);
    }

    @PostMapping(value = "/account")
    @ResponseStatus(HttpStatus.CREATED)
    public AbstractServiceResponse addNewAccount(@RequestBody @NonNull AccountCreateReq accountCreateReq) {
        return accountService.addNewAccount(accountCreateReq);
    }

    @GetMapping(value = "/accounts/projects")
    @ResponseStatus(HttpStatus.OK)
    public AbstractServiceResponse retrieveAccountsAndProjects(@RequestParam @NonNull Long projectManagerId) {
        return projectAndAccountService.retrieveAccountsWithProjects(projectManagerId);
    }
}
