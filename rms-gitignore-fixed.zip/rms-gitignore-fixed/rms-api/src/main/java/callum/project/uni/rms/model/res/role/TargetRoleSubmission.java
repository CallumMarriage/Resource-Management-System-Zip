package callum.project.uni.rms.model.res.role;

import callum.project.uni.rms.model.res.AbstractServiceResponse;
import callum.project.uni.rms.model.res.TargetRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Builder
@NoArgsConstructor
@Data
public class TargetRoleSubmission extends AbstractServiceResponse {


    private Long candidateId;

    private Long submissionId;

    private TargetRole submittedRole;
}
