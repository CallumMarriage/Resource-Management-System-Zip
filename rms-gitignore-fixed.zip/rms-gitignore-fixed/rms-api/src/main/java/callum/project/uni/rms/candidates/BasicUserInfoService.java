package callum.project.uni.rms.candidates;

import callum.project.uni.rms.account.service.AccountService;
import callum.project.uni.rms.candidates.model.target.FullUserInfo;
import callum.project.uni.rms.candidates.model.target.TargetUser;
import callum.project.uni.rms.candidates.resourcing.ResourceManagerService;
import callum.project.uni.rms.model.res.TargetAccount;
import callum.project.uni.rms.model.res.TargetProject;
import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.parent.exception.NotFoundException;
import callum.project.uni.rms.project.ProjectService;
import callum.project.uni.rms.roles.service.RoleService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
@Transactional
@RequiredArgsConstructor
public class BasicUserInfoService {

    private final UserService userService;

    private final RoleService roleService;

    private final AccountService accountService;

    private final ProjectService projectService;

    private final ResourceManagerService resourceManagerService;

    public FullUserInfo buildUserInfoResponse(TargetUser user) {
        Long currentRoleId = user.getCurrentRoleId();

        TargetRole currentRole = null;
        TargetAccount currentAccount = null;
        TargetProject currentProject = null;

        String rmName = null;

        try {
            Long rmId = resourceManagerService.retrieveResourceManagerIdByBu(user.getBusinessUnitId());
            rmName = userService.retrieveUserByInternalId(rmId).getFullName();
        } catch (NotFoundException e) {
            log.error(e.getMessage());
        }

        user.setResourceManagerName(rmName);

        if (currentRoleId != null) {
            log.debug("Making request to role service for role history");
            currentRole = roleService.retrieveRoleById(currentRoleId);

            log.debug("Making request to account service");
            currentAccount = accountService.retrieveTargetAccountById(
                    currentRole.getAccountNumber());

            log.debug("Making request to project api");
            currentProject = projectService.retrieveProjectById(
                    currentRole.getProjectCode());
        }

        log.debug("Build full user info object");
        return FullUserInfo.builder()
                .user(user)
                .currentRole(currentRole)
                .currentAccount(currentAccount)
                .currentProject(currentProject)
                .build();
    }
}
