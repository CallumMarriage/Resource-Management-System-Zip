package callum.project.uni.rms.project;

import callum.project.uni.rms.model.req.ProjectCreateReq;
import callum.project.uni.rms.model.req.ProjectUpdateReq;
import callum.project.uni.rms.model.res.AbstractServiceResponse;
import callum.project.uni.rms.model.res.TargetProject;
import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.model.res.projects.FullProjectInfo;
import callum.project.uni.rms.roles.service.RoleListService;
import callum.project.uni.rms.roles.service.RoleService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Slf4j
@AllArgsConstructor
public class ProjectController {

    private final ProjectService projectService;
    private final RoleListService roleListService;
    private final RoleService roleService;

    @GetMapping(value = "/projects/id/{projectCode}")
    @ResponseStatus(HttpStatus.OK)
    public AbstractServiceResponse retrieveTargetProject(@PathVariable @NonNull String projectCode) {
        //Call Service to get response object
        TargetProject serviceResponse = projectService.retrieveProjectById(projectCode);
        List<TargetRole> rolesForProject = roleListService.retrieveAllRolesForProjectCode(projectCode);

        return FullProjectInfo.builder()
                .roleList(rolesForProject)
                .targetProject(serviceResponse)
                .build();
    }

    @PostMapping(value = "/project")
    @ResponseStatus(HttpStatus.CREATED)
    public AbstractServiceResponse addNewProject(@RequestBody @NonNull ProjectCreateReq projectCreateReq) {
        return projectService.addNewProject(projectCreateReq);
    }

    @PutMapping(value = "/project/update")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void updateProject(@RequestBody ProjectUpdateReq projectUpdateReq) {
        projectService.updateProject(projectUpdateReq);
        roleListService.addNewRoles(projectUpdateReq.getNewRoles());
        for (TargetRole upRole : projectUpdateReq.getUpdatedRoles()) {
            roleService.updateRole(upRole);
        }
    }
}
