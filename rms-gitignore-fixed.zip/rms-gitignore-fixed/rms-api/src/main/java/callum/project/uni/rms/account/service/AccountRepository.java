package callum.project.uni.rms.account.service;

import callum.project.uni.rms.account.Account;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends CrudRepository<Account, String> {

    Optional<Account> findFirstByAccountName(String accountName);
    
    List<Account> findAll();

    List<Account> findAllByAccountManagerId(Long accountManagerId);
    
    
}
