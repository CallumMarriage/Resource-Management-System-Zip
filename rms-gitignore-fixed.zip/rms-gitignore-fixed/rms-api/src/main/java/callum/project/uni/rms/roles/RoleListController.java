package callum.project.uni.rms.roles;

import callum.project.uni.rms.model.RoleType;
import callum.project.uni.rms.model.res.AbstractServiceResponse;
import callum.project.uni.rms.roles.service.RoleFilterService;
import callum.project.uni.rms.roles.service.RoleListService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.time.Instant;
import java.time.LocalDate;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Slf4j
@AllArgsConstructor
public class RoleListController {

    private final RoleListService roleListService;
    private final RoleFilterService roleFilterService;

    @GetMapping(value = "/roles")
    @ResponseStatus(HttpStatus.OK)
    public AbstractServiceResponse getFilteredRoles(
            @RequestParam(required = false) String accountName,
            @RequestParam(required = false) String projectName,
            @RequestParam(required = false) RoleType roleType,
            @RequestParam(required = false) LocalDate startDate,
            @RequestParam(required = false) LocalDate endDate) {

        return roleFilterService.runFilters(accountName,
                projectName, roleType, startDate, endDate);
    }

    @GetMapping(value = "/roles", params = {"userId"})
    @ResponseStatus(HttpStatus.OK)
    public AbstractServiceResponse getRolesForUser(@RequestParam("userId")
                                                       @NonNull Long userId) {
        return roleListService.retrieveRoleHistory(userId);
    }

    @GetMapping(value = "/roles/open", params = {"buId"})
    public AbstractServiceResponse getOpenRolesForBuId(@RequestParam("buId")
                                                           @NonNull Long buId){
        return roleListService.retrieveRolesForBusinessUnit(buId);
    }

    @GetMapping(value = "/roles/open")
    public AbstractServiceResponse getOpenRoles(){
        return roleListService.retrieveAllOpenRoles();
    }

    @GetMapping(value = "/roles/open", params = {"projectCode"})
    public AbstractServiceResponse getOpenRolesForProject(@RequestParam("projectCode")@NonNull String projectCode){

        return roleListService.retrieveOpenRolesForProject(projectCode);
    }
}
