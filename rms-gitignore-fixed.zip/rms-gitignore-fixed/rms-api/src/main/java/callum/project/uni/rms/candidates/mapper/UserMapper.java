package callum.project.uni.rms.candidates.mapper;

import callum.project.uni.rms.candidates.model.request.UserCreateReq;
import callum.project.uni.rms.candidates.model.target.TargetUser;
import callum.project.uni.rms.candidates.model.source.User;

public class UserMapper {

    public static TargetUser mapDbModelToTarget(User user){

        return TargetUser.builder()
                .id(user.getId())
                .fullName(user.getFullName())
                .currentRoleId(user.getCurrentRoleId())
                .userType(user.getUserType())
                .baseLocation(user.getBaseLocation())
                .baseLocationX(user.getBaseLocation().getX())
                .businessUnitId(user.getBusinessUnitId())
                .baseLocationY(user.getBaseLocation().getY())
                .userSpecialism(user.getUserSpecialism())
                .grade(user.getGrade())
                .build();
    }

    public static User mapCreateReqToDbModel(UserCreateReq createReq){
        return User.builder()
                .ssoId(createReq.getSsoId())
                .fullName(createReq.getName())
                .currentRoleId(createReq.getCurrentRoleId())
                .baseLocation(createReq.getBaseLocation())
                .userType(createReq.getUserType())
                .userSpecialism(createReq.getUserSpecialism())
                .businessUnitId(createReq.getBusinessUnitId())
                .grade(createReq.getGrade())
                .build();
    }
}
