package callum.project.uni.rms.model.res.projects;

import callum.project.uni.rms.model.res.AbstractServiceResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@Builder
public class ProjectUpdated extends AbstractServiceResponse {

    private boolean updated;
}
