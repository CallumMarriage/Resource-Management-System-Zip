package callum.project.uni.rms.roles.service;

import callum.project.uni.rms.model.RoleType;
import callum.project.uni.rms.model.res.role.RoleList;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.roles.service.model.Role;
import callum.project.uni.rms.roles.service.repository.RoleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.text.similarity.JaccardSimilarity;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import static callum.project.uni.rms.parent.mapper.MapperUtils.convertSqlDateToLocalDate;
import static callum.project.uni.rms.roles.service.mapper.RoleMapper.mapDbRolesToRoleList;

@RequiredArgsConstructor
@Slf4j
@Service
public class RoleFilterService {

    private final RoleRepository roleRepository;

    private final JaccardSimilarity similarity = new JaccardSimilarity();

    public RoleList runFilters(String queryAccountName,
                               String queryProjectName,
                               RoleType queryRoleType,
                               LocalDate startDate,
                               LocalDate endDate) {

        try {
            List<Role> potentialRoles = roleRepository
                    .findAllByIsRoleOpenIsTrue();
            potentialRoles = potentialRoles.parallelStream()
                    .filter(role ->
                            (queryAccountName == null || doStringsMatch(queryAccountName, role.getAccountName())) &&
                                    (queryRoleType == null || queryRoleType == role.getRoleType()) &&
                                    (isStartDateValid(startDate, role.getStartDate())) &&
                                    (isEndDateValid(endDate, role.getEndDate())) &&
                                    (queryProjectName == null || doStringsMatch(queryProjectName, role.getProjectName())))
                    .collect(Collectors.toList());

            return mapDbRolesToRoleList(potentialRoles);
        } catch (RuntimeException e) {
            log.error(e.getLocalizedMessage());
            throw new InternalServiceException("Error running the filter", e);
        }
    }

    public boolean isStartDateValid(LocalDate queryDate, Date dbDate ){
        return queryDate == null || queryDate.isBefore(convertSqlDateToLocalDate(dbDate));
    }

    public boolean isEndDateValid(LocalDate queryDate, Date dbDate ){
        return queryDate == null || queryDate.isAfter(convertSqlDateToLocalDate(dbDate));
    }

    private boolean doStringsMatch(String searchItem, String dbItem) {
        return similarity.apply(searchItem, dbItem) > 0.4;
    }
}
