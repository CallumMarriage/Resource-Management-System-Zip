package callum.project.uni.rms.model.res.accounts;

import callum.project.uni.rms.model.res.AbstractServiceResponse;
import callum.project.uni.rms.model.res.TargetAccount;
import lombok.*;

import java.util.List;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AccountList extends AbstractServiceResponse {

    private List<TargetAccount> accountList;
}
