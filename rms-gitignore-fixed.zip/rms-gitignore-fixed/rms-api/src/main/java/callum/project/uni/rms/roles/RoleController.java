package callum.project.uni.rms.roles;

import callum.project.uni.rms.model.res.AbstractServiceResponse;
import callum.project.uni.rms.roles.model.RoleCreateReq;

import callum.project.uni.rms.roles.model.UpdateRoleActiveReq;
import callum.project.uni.rms.roles.service.RoleService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Slf4j
@AllArgsConstructor
class RoleController {

    private final RoleService roleService;

    @PostMapping(value = "/role")
    @ResponseStatus(HttpStatus.CREATED)
    public AbstractServiceResponse postRole(@RequestBody @NonNull RoleCreateReq req) {
        return roleService.addNewRole(req.getRole());
    }

    @GetMapping(value = "/role/{roleId}")
    @ResponseStatus(HttpStatus.OK)
    public AbstractServiceResponse getTargetRole(@PathVariable("roleId")
                                                     @NonNull Long roleId) {
        return roleService.retrieveRoleById(roleId);
    }

    @PutMapping(value = "/role/{roleId}/complete")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void putLeaveRole(@PathVariable("roleId") @NonNull Long roleId) {
        roleService.updateRoleAsEnded(roleId);
    }

    @PutMapping(value = "/role/{roleId}/active")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void putRoleActive(@PathVariable("roleId") @NonNull Long roleId) {
        roleService.updateRoleAsActive(roleId);
    }
}
