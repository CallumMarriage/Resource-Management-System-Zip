package callum.project.uni.rms.model.req;

import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.roles.model.RequestRole;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@AllArgsConstructor
@Builder
@Data
@NoArgsConstructor
public class ProjectUpdateReq {

    @NonNull
    @JsonProperty("projectCode")
    private String projectCode;

    @NonNull
    @JsonProperty("startDate")
    private LocalDate startDate;

    @JsonProperty("endDate")
    private LocalDate endDate;

    @NonNull
    @JsonProperty("accountNumber")
    private String accountNumber;

    @NonNull
    @JsonProperty("projectName")
    private String projectName;
    
    @JsonProperty("description")
    private String description;

    @NonNull
    @JsonProperty("projectManagerId")
    private Long projectManagerId;

    @JsonProperty("newRoles")
    private List<RequestRole> newRoles;

    @JsonProperty("updatedRoles")
    private List<TargetRole> updatedRoles;

}
