package callum.project.uni.rms.candidates.resourcing;

import callum.project.uni.rms.parent.exception.NotFoundException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@AllArgsConstructor
@Slf4j
public class ResourceManagerService {

    private final ResourceManagerRepository resourceManagerRepository;

    public long retrieveResourceManagerIdByBu(Long bu){
        Optional<ResourceManager> rm = resourceManagerRepository.findByBusinessUnitId(bu);
        return rm.orElseThrow(() -> new NotFoundException("Rm not found")).getUserId();
    }
}
