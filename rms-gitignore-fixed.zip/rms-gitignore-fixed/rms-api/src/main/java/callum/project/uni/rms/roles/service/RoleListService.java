package callum.project.uni.rms.roles.service;

import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.model.res.role.RoleList;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.roles.model.RequestRole;
import callum.project.uni.rms.roles.service.mapper.RoleMapper;
import callum.project.uni.rms.roles.service.model.Role;
import callum.project.uni.rms.roles.service.repository.RoleRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.HibernateException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
@Slf4j
@AllArgsConstructor
@Transactional
public class RoleListService {

    private final RoleRepository roleRepository;

    public List<TargetRole> retrieveAllRolesForProjectCode(String projectCode) {
        try {
            List<Role> roles = roleRepository.findAllByProjectCode(projectCode);
            return buildOrderedListOfRoles(roles);

        } catch (HibernateException e) {
            throw new InternalServiceException("Error retrieving role", e);
        }
    }

    public RoleList retrieveAllOpenRoles() {
        List<Role> roles = roleRepository.findAllByIsRoleOpenIsTrue();
        List<Role> filteredRoles = roles.stream()
                .filter(role -> role.getEndDate() == null
                        || role.getEndDate().toLocalDate().isAfter(LocalDate.now()))
                .collect(Collectors.toList());

        return RoleList.builder()
                .roleList(buildOrderedListOfRoles(filteredRoles))
                .build();
    }

    public RoleList retrieveRolesForBusinessUnit(Long buId) {
        try {
            List<Role> roles = roleRepository.findAllByBusinessUnitIdAndIsRoleOpenIsTrue(buId);

            return RoleList.builder()
                    .roleList(buildOrderedListOfRoles(roles))
                    .build();
        } catch (HibernateException e) {
            throw new InternalServiceException("Error retrieving roles for rm", e);
        }
    }

    public RoleList retrieveRoleHistory(Long userId) {
        try {
            Iterable<Role> roleIds = roleRepository.findRolesForUser(userId);
            return RoleList.builder()
                    .roleList(buildOrderedListOfRoles(roleIds))
                    .build();
        } catch (RuntimeException e) {
            log.error(e.getMessage());
            throw new InternalServiceException(e.getMessage(), e);
        }
    }

    public List<TargetRole> retrieveForProjectId(String projectCode) {
        try {
            List<Role> roles = roleRepository.findPotentialRolesByProjectCode(projectCode);
            return buildOrderedListOfRoles(roles);

        } catch (HibernateException e) {
            log.error(e.getLocalizedMessage());
            throw new InternalServiceException("Error retrieving role", e);
        }
    }

    public void addNewRoles(List<RequestRole> newRoles) {
        try {
            roleRepository.saveAll(buildRolesToCreate(newRoles));

        } catch (RuntimeException e) {
            log.error(e.getMessage());
            throw new InternalServiceException(e.getMessage(), e);
        }
    }

    public RoleList retrieveOpenRolesForProject(String projectCode) {
        try {
            List<Role> roles = roleRepository.findAllByProjectCodeAndIsRoleOpenTrue(projectCode);
            return RoleList.builder()
                    .roleList(buildOrderedListOfRoles(roles))
                    .build();

        } catch (HibernateException e) {
            log.error(e.getLocalizedMessage());
            throw new InternalServiceException("Error retrieving role", e);
        }
    }

    private List<Role> buildRolesToCreate(List<RequestRole> newRoles) {
        return newRoles.stream()
                .map(RoleMapper::mapRequestToDbModel)
                .collect(Collectors.toList());
    }

    private List<TargetRole> buildOrderedListOfRoles(Iterable<Role> roleIterable) {
        return StreamSupport.stream(roleIterable.spliterator(), true)
                .map(RoleMapper::mapDBToTargetModel)
                .sorted(Comparator.comparing(TargetRole::getStartDate,
                        Comparator.nullsLast(Comparator.naturalOrder())))
                .collect(Collectors.toList());
    }

}
