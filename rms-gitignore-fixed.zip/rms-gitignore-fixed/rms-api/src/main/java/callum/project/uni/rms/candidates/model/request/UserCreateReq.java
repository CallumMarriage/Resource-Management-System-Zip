package callum.project.uni.rms.candidates.model.request;

import callum.project.uni.rms.candidates.model.UserType;
import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.RoleType;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@Builder
@Data
@NoArgsConstructor
public class UserCreateReq {

    @JsonProperty("ssoId")
    private String ssoId;

    @JsonProperty("currentRoleId")
    private Long currentRoleId;

    @JsonProperty("name")
    private String name;

    @JsonProperty("userType")
    private UserType userType;

    @JsonProperty("userSpecialism")
    private RoleType userSpecialism;

    @JsonProperty("baseLocation")
    private BaseLocation baseLocation;

    @JsonProperty("businessUnitId")
    private Long businessUnitId;

    @JsonProperty("grade")
    private String grade;
    
}
