package callum.project.uni.rms.candidates;

import callum.project.uni.rms.candidates.model.request.UserCreateReq;
import callum.project.uni.rms.model.res.AbstractServiceResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@Slf4j
@AllArgsConstructor
public class BasicUserInfoController {

    private final UserService userService;
    private final BasicUserInfoService basicUserInfoService;

    @GetMapping(value = "/user/exists")
    @ResponseStatus(HttpStatus.OK)
    public AbstractServiceResponse doesUserExists(@RequestParam("ssoId") @NonNull
                                                          String ssoId) {
        return userService.userExists(ssoId);
    }

    @PostMapping(value = "/user")
    @ResponseStatus(HttpStatus.CREATED)
    public AbstractServiceResponse addNewUser(@RequestBody @NonNull
                                                      UserCreateReq userCreateRequest) {
        return basicUserInfoService.buildUserInfoResponse(
                userService.createUser(userCreateRequest));
    }

    @GetMapping(value = "/user/info")
    @ResponseStatus(HttpStatus.OK)
    public AbstractServiceResponse getUserInfo(@RequestParam @NonNull
                                                       String ssoId) {
        return basicUserInfoService.buildUserInfoResponse(
                userService.retrieveUserDetailsBySsoId(ssoId));
    }

}
