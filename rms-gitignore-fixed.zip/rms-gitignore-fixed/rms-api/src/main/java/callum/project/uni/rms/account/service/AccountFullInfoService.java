package callum.project.uni.rms.account.service;

import callum.project.uni.rms.model.res.TargetAccount;
import callum.project.uni.rms.model.res.accounts.AccountList;
import callum.project.uni.rms.model.res.TargetProject;
import callum.project.uni.rms.model.res.accounts.AccountAndProjects;
import callum.project.uni.rms.model.res.accounts.AccountsWithProjects;
import callum.project.uni.rms.model.res.projects.ProjectList;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.project.ProjectService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
@AllArgsConstructor
public class AccountFullInfoService {

    // TODO Replace project service use here with sql query
    private final ProjectService projectService;

    private final AccountService accountService;

    public AccountsWithProjects retrieveAccountsWithProjects(Long userId) {

        try {

            Map<String, AccountAndProjects> accountsAndProjects = new HashMap<>();

            AccountList accounts = accountService.retrieveAccountList(userId);
            log.info("Finished retrieving accounts");
            for (TargetAccount account : accounts.getAccountList()) {
                accountsAndProjects.put(account.getAccountCode(),
                        addProjectToAccount(account));
                log.info("Adding account {} with projects", account.getAccountCode());
            }

            ProjectList projects = projectService.retrieveProjectsByProjectManager(userId);
            log.info("Finished retrieving projects");
            for (TargetProject project : projects.getProjects()) {

                if (accountsAndProjects.containsKey(project.getAccountNumber())) {
                    AccountAndProjects accountAndProjects = accountsAndProjects.get(
                            project.getAccountNumber());
                    log.info("Updating account {} project list", project.getAccountNumber());

                    if (!accountAndProjects.getProjects().contains(project)) {
                        log.info("Adding project {} to project list", project.getProjectCode());

                        accountAndProjects.addProjectToProjects(project);
                        accountsAndProjects.replace(project.getAccountNumber(),
                                accountAndProjects);
                    }

                } else {
                    log.info("Adding new account {}", project.getAccountNumber());

                    List<TargetProject> newProjectList = new ArrayList<>();
                    newProjectList.add(project);
                    accountsAndProjects.put(project.getAccountNumber(),
                            buildAccountAndProjects(newProjectList,
                                    accountService.retrieveTargetAccountById(project.getAccountNumber())));
                }
            }

            return AccountsWithProjects.builder()
                    .accountAndProjectsList(new ArrayList<>(accountsAndProjects.values()))
                    .build();
        } catch (RuntimeException e) {
            log.error(e.getMessage());
            throw new InternalServiceException("Issue retrieving Account info for account with project search", e);
        }
    }

    private AccountAndProjects buildAccountAndProjects(List<TargetProject> project2, TargetAccount account) {
        return AccountAndProjects.builder()
                .projects(project2)
                .targetAccount(account)
                .build();
    }

    private AccountAndProjects addProjectToAccount(TargetAccount account) {
        ProjectList projects = projectService.retrieveProjectsByAccountNumber(
                account.getAccountCode());
        return buildAccountAndProjects(projects.getProjects(), account);
    }
}
