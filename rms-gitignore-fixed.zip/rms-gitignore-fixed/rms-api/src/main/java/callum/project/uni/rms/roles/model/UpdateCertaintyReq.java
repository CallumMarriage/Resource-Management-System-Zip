package callum.project.uni.rms.roles.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class UpdateCertaintyReq {

    @JsonProperty("certainty")
    public Double certainty;
}
