package callum.project.uni.rms.candidates;

import callum.project.uni.rms.candidates.model.request.UserCreateReq;
import callum.project.uni.rms.candidates.model.source.User;
import callum.project.uni.rms.candidates.model.target.TargetUser;
import callum.project.uni.rms.candidates.model.target.UserExist;
import callum.project.uni.rms.candidates.mapper.UserMapper;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.parent.exception.NotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

import static callum.project.uni.rms.candidates.mapper.UserMapper.mapCreateReqToDbModel;

@Service
@Slf4j
@Transactional
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public TargetUser createUser(UserCreateReq createReq) {

        User user = mapCreateReqToDbModel(createReq);
        try {
            User response = userRepository.save(user);
            return UserMapper.mapDbModelToTarget(response);
        } catch (RuntimeException e) {
            throw new InternalServiceException("Error adding user", e);
        }
    }

    public UserExist userExists(String ssoId) {
        try {
            Optional<User> user = userRepository.findBySsoId(ssoId);

            return UserExist.builder()
                    .userExist(user.isPresent())
                    .build();
        } catch (Exception e) {
            throw new InternalServiceException("Error finding user exists", e);
        }
    }

    public TargetUser retrieveUserByInternalId(Long userId) {
        try {
            Optional<User> user = userRepository.findById(userId);

            return UserMapper.mapDbModelToTarget(user.orElseThrow(() ->
                    new NotFoundException("Expected user not found")));
        } catch (RuntimeException e) {
            throw new InternalServiceException("Error finding user", e);
        }
    }

    public TargetUser retrieveUserDetailsBySsoId(String ssoId) {
        try {
            Optional<User> user = userRepository.findBySsoId(ssoId);

            return UserMapper.mapDbModelToTarget(user.orElseThrow(() ->
                    new NotFoundException("User not found")));
        } catch (RuntimeException e) {
            throw new InternalServiceException("Error finding user", e);
        }
    }
}
