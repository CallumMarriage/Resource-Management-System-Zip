package callum.project.uni.rms.model.res;

public abstract class AbstractServiceResponse {

}
