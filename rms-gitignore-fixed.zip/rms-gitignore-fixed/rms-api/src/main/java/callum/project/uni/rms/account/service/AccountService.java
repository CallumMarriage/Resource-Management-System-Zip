package callum.project.uni.rms.account.service;

import callum.project.uni.rms.account.Account;
import callum.project.uni.rms.account.AccountMapper;
import callum.project.uni.rms.model.req.AccountCreateReq;
import callum.project.uni.rms.model.res.TargetAccount;
import callum.project.uni.rms.model.res.accounts.AccountList;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.parent.exception.NotFoundException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.HibernateException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static callum.project.uni.rms.account.AccountMapper.mapAccountCreateReqToAccount;
import static callum.project.uni.rms.account.AccountMapper.mapAccountToTargetAccount;

@Service
@Slf4j
@AllArgsConstructor
public class AccountService {


    private final AccountRepository accountRepository;

    public TargetAccount addNewAccount(AccountCreateReq accountCreateReq) {
        try {
            Account newAccount = mapAccountCreateReqToAccount(accountCreateReq);

            return mapAccountToTargetAccount(accountRepository.save(newAccount));
        } catch (HibernateException e) {
            throw new InternalServiceException("Issue creating account", e);
        }
    }

    public TargetAccount retrieveTargetAccountById(String accountNumber) {
        try {
            Optional<Account> accountOptional = accountRepository.findById(accountNumber);
            
            return mapAccountToTargetAccount(accountOptional.orElseThrow(() -> 
                    new NotFoundException("Account not found")));
        } catch (HibernateException e) {
            throw new InternalServiceException("Issue retrieving account", e);
        }
    }

    public boolean isAccountAvailable(String accountNumber){
        try {
            Optional<Account> accountOptional = accountRepository.findById(accountNumber);

            return accountOptional.isPresent();
        } catch (HibernateException e) {
            throw new InternalServiceException("Issue retrieving account", e);
        }
    }

    public AccountList retrieveAccountList(Long userId) {
        try {
            List<Account> accounts;

            if (userId == null) {
                accounts = accountRepository.findAll();
            } else {
                accounts = accountRepository.findAllByAccountManagerId(userId);
            }

            return createList(accounts);
        } catch (HibernateException e) {
            throw new InternalServiceException("Issue retrieving account", e);
        }
    }

    public TargetAccount retrieveAccountByName(String accountName) {
        try {
            Optional<Account> accountOpt = accountRepository.findFirstByAccountName(accountName);
            
            return AccountMapper.mapAccountToTargetAccount(accountOpt.orElseThrow(() ->
                    new NotFoundException("Account not found")));
        } catch (HibernateException e) {
            throw new InternalServiceException("Issue retrieving account", e);
        }
    }


    private AccountList createList(List<Account> accounts) {
        return AccountList.builder()
                .accountList(accounts.stream()
                        .map(AccountMapper::mapAccountToTargetAccount)
                        .collect(Collectors.toList()))
                .build();
    }
}
