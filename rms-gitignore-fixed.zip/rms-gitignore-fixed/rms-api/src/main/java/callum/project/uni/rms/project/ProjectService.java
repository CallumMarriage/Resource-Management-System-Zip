package callum.project.uni.rms.project;

import callum.project.uni.rms.model.req.ProjectCreateReq;
import callum.project.uni.rms.model.req.ProjectUpdateReq;
import callum.project.uni.rms.model.res.TargetProject;
import callum.project.uni.rms.model.res.projects.ProjectList;
import callum.project.uni.rms.parent.exception.InternalServiceException;
import callum.project.uni.rms.parent.exception.NotFoundException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.HibernateException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static callum.project.uni.rms.mapper.MapperUtils.convertLocalDateToSqlDate;
import static callum.project.uni.rms.project.ProjectMapper.mapProjectToTargetProject;
import static callum.project.uni.rms.project.ProjectMapper.mapReqProjectToProject;

@Service
@Slf4j
@Transactional
@AllArgsConstructor
public class ProjectService {

    private final ProjectRepository projectRepository;
    
    public TargetProject retrieveProjectById(String id) {
        try {
            Optional<Project> projectOpt = projectRepository.findById(id);

            return mapProjectToTargetProject(projectOpt.orElseThrow(() ->
                    new NotFoundException("Project with that id not found")));
        } catch (HibernateException e) {
            throw new InternalServiceException("Issue retrieving project", e);
        }
    }

    public TargetProject addNewProject(ProjectCreateReq projectCreateReq) {

        try {
            Project newProject = mapReqProjectToProject(projectCreateReq);
            return mapProjectToTargetProject(projectRepository.save(newProject));

        } catch (HibernateException e) {
            throw new InternalServiceException("Issue adding project", e);
        }
    }

    public void updateProject(ProjectUpdateReq projectUpdateReq) {
        try {
            projectRepository.updateProject(
                    projectUpdateReq.getProjectCode(),
                    projectUpdateReq.getProjectName(),
                    projectUpdateReq.getDescription(),
                    convertLocalDateToSqlDate(projectUpdateReq.getStartDate()),
                    convertLocalDateToSqlDate(projectUpdateReq.getEndDate()));

        } catch (HibernateException e) {
            throw new InternalServiceException("Issue updating project", e);
        }
    }

    public ProjectList retrieveProjectsByAccountNumber(String accountNumber) {
        try {
            List<Project> projectsDb = projectRepository.findAllByAccountNumber(accountNumber);

            return ProjectList.builder()
                    .projects(createList(projectsDb))
                    .build();

        } catch (HibernateException e) {
            throw new InternalServiceException("Issue retrieving projects by account", e);
        }
    }

    public ProjectList retrieveProjectsByProjectManager(Long projectManagerId) {

        try {
            List<Project> projectsDb = projectRepository.findAllByProjectManagerId(projectManagerId);

            return ProjectList.builder()
                    .projects(createList(projectsDb))
                    .build();

        } catch (HibernateException e) {
            throw new InternalServiceException("Issue retrieving projects by pm", e);
        }
    }

    private List<TargetProject> createList(Iterable<Project> projectsIterable) {
        return StreamSupport.stream(projectsIterable.spliterator(), true)
                .map(ProjectMapper::mapProjectToTargetProject)
                .collect(Collectors.toList());
    }
}
