package callum.project.uni.rms.roles.service.repository;

import callum.project.uni.rms.model.BaseLocation;
import callum.project.uni.rms.model.RoleType;
import callum.project.uni.rms.roles.service.model.Role;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;

@Repository
public interface RoleRepository extends CrudRepository<Role, Long> {

    @Query(value = "SELECT r.* from role r join (SELECT ass.role_id FROM assignment ass WHERE ass.user_id = :id) ms ON r.id = ms.role_id", nativeQuery = true)
    List<Role> findRolesForUser(@Param("id") Long id);

    @Query(value = "SELECT r.* from role r where r.id not in (SELECT ass.role_id FROM assignment ass)", nativeQuery = true)
    List<Role> findPotentialRoles();

    List<Role> findAllByIsRoleOpenIsTrue();
    
    List<Role> findAllByRoleType(RoleType roleType);

    @Modifying(clearAutomatically = true)
    @Query(value = "update role r set r.start_date =:startDate, " +
            "r.base_location = :baseLocation," +
            "r.certainty = :certainty," +
            "r.end_date = :endDate, " +
            "r.role_name = :roleName, " +
            "r.description = :description, " +
            "r.business_unit_id = :businessUnitId, " +
            "r.role_type = :roleType " +
            "where r.id = :roleId", nativeQuery = true)
    void updateRole(@Param("roleId") Long roleId,
                    @Param("startDate") Date startDate,
                    @Param("roleName") String roleName,
                    @Param("baseLocation") Integer baseLocation,
                    @Param("endDate") Date endDate,
                    @Param("description") String description,
                    @Param("businessUnitId") Long businessUnitId,
                    @Param("roleType") Integer roleType,
                    @Param("certainty") Double certainty
    );
    
    @Query(value = "SELECT ro.* from role ro WHERE  ro.project_code = :projectCode AND ro.id IN (SELECT r.id FROM role r INNER JOIN assignment a on r.id = a.role_id)", nativeQuery = true)
    List<Role> findPotentialRolesByProjectCode(@Param("projectCode") String projectCode);

    List<Role> findAllByProjectCodeAndIsRoleOpenTrue(@Param("projectCode") String projectCode);

    List<Role> findAllByProjectCode(String projectCode);

    @Modifying(clearAutomatically = true)
    @Query(value = "update role r set r.is_role_open =:isRoleOpen where r.id = :roleId", nativeQuery = true)
    void updateRoleOpen(@Param("roleId") Long roleId, @Param("isRoleOpen") boolean isRoleOpen);

    List<Role> findAllByBusinessUnitIdAndIsRoleOpenIsTrue(@Param("buId") Long buId);

    @Query(value = "update role r set r.certainty =:certainty where r.id =:roleId", nativeQuery = true)
    void updateRoleCertainty(@Param("roleId") Long roleId, @Param("certainty") Double certainty);
}
