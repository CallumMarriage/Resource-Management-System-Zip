package callum.project.uni.rms.account;

import callum.project.uni.rms.model.res.AbstractServiceResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class AccountAvailable extends AbstractServiceResponse {

    private boolean isAccountAvailable;
}
