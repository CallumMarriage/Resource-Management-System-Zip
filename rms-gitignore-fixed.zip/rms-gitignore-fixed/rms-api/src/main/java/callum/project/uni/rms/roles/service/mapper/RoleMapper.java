package callum.project.uni.rms.roles.service.mapper;

import callum.project.uni.rms.roles.model.RequestRole;
import callum.project.uni.rms.model.res.TargetRole;
import callum.project.uni.rms.model.res.role.RoleList;
import callum.project.uni.rms.roles.service.model.Role;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

import static callum.project.uni.rms.mapper.MapperUtils.convertLocalDateToSqlDate;
import static callum.project.uni.rms.mapper.MapperUtils.convertSqlDateToLocalDate;

@Component
@Slf4j
public class RoleMapper {

    public static RoleList mapDbRolesToRoleList(List<Role> dbRoles) {
        return RoleList.builder()
                .roleList(dbRoles.stream()
                        .map(RoleMapper::mapDBToTargetModel)
                        .collect(Collectors.toList()))
                .build();
    }

    public static TargetRole mapDBToTargetModel(Role dbRole) {
        return TargetRole.builder()
                .accountName(dbRole.getAccountName())
                .accountNumber(dbRole.getAccountNumber())
                .id(dbRole.getId())
                .projectName(dbRole.getProjectName())
                .projectCode(dbRole.getProjectCode())
                .endDate(convertSqlDateToLocalDate(dbRole.getEndDate()))
                .startDate(convertSqlDateToLocalDate(dbRole.getStartDate()))
                .roleName(dbRole.getRoleName())
                .businessUnit(dbRole.getBusinessUnitId())
                .description(dbRole.getDescription())
                .baseLocation(dbRole.getBaseLocation())
                .baseLocationX(dbRole.getBaseLocation().getX())
                .baseLocationY(dbRole.getBaseLocation().getY())
                .roleType(dbRole.getRoleType())
                .isRoleOpen(dbRole.getIsRoleOpen())
                .certainty(dbRole.getCertainty())
                .grade(dbRole.getGrade())
                .build();
    }
    
    public static Role mapTargetToDbModel(TargetRole targetRole) {
        return Role.builder()
                .roleName(targetRole.getRoleName())
                .roleType(targetRole.getRoleType())
                .projectCode(targetRole.getProjectCode())
                .projectName(targetRole.getProjectName())
                .accountNumber(targetRole.getAccountNumber())
                .accountName(targetRole.getAccountName())
                .description(targetRole.getDescription())
                .isRoleOpen(targetRole.getIsRoleOpen())
                .certainty(targetRole.getCertainty())
                .grade(targetRole.getGrade())
                .baseLocation(targetRole.getBaseLocation())
                .businessUnitId(targetRole.getBusinessUnit())
                .startDate(convertLocalDateToSqlDate(targetRole.getStartDate()))
                .endDate(convertLocalDateToSqlDate(targetRole.getEndDate()))
                .build();
    }

    public static Role mapRequestToDbModel(RequestRole req) {
        return Role.builder()
                .roleName(req.getRoleName())
                .roleType(req.getRoleType())
                .projectCode(req.getProjectCode())
                .projectName(req.getProjectName())
                .accountNumber(req.getAccountNumber())
                .accountName(req.getAccountName())
                .businessUnitId(req.getBusinessUnit())
                .grade(req.getGrade())
                .description(req.getDescription())
                .baseLocation(req.getBaseLocation())
                .certainty(req.getCertainty())
                .isRoleOpen(true)
                .startDate(convertLocalDateToSqlDate(req.getStartDate()))
                .endDate(convertLocalDateToSqlDate(req.getEndDate()))
                .build();
    }
}
