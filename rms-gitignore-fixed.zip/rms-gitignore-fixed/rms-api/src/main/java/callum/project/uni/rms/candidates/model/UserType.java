package callum.project.uni.rms.candidates.model;

public enum UserType {

    CANDIDATE,

    PROJECT_MANAGER,

    RESOURCE_MANAGER
}
