DROP SCHEMA IF EXISTS rms_db;

CREATE DATABASE rms_db;

USE rms_db;

GRANT ALL PRIVILEGES ON rms_db.* TO 'rms-api'@'localhost';

DROP TABLE IF EXISTS rms_db.role;
DROP TABLE IF EXISTS rms_db.account;
DROP TABLE IF EXISTS rms_db.project;
DROP TABLE IF EXISTS rms_db.assignment;
DROP TABLE IF EXISTS rms_db.user;

CREATE TABLE rms_db.role
(
    id             int NOT NULL AUTO_INCREMENT,
    role_name      VARCHAR(50),
    description    VARCHAR(300),
    project_code   VARCHAR(20),
    account_number VARCHAR(20),
    start_date     DATE NOT NULL,
    end_date       DATE,
    PRIMARY KEY (id)
);

CREATE TABLE rms_db.project
(
    project_name   VARCHAR(40),
    project_code   VARCHAR(20),
    account_number VARCHAR(20),
    description    VARCHAR(300),
    start_date     DATE NOT NULL,
    end_date       DATE,
    PRIMARY KEY (project_code)
);

CREATE TABLE rms_db.account
(
    account_name   VARCHAR(50),
    account_number VARCHAR(20) NOT NULL,
    description    VARCHAR(300),
    start_date     DATE NOT NULL,
    end_date       DATE,
    PRIMARY KEY (account_number)
);

CREATE TABLE rms_db.user
(
    id                int NOT NULL AUTO_INCREMENT,
    google_id         VARCHAR(40),
    current_role_code int,
    PRIMARY KEY (id)
);

CREATE TABLE rms_db.assignment
(
    user_id    int NOT NULL,
    role_id    VARCHAR(20)  NOT NULL,
    start_date DATE NOT NULL,
    end_date   DATE,
    PRIMARY KEY (user_id, role_id)
);

insert into rms_db.project(project_code, description, project_name, account_number, start_date, end_date)
VALUES ('2222222222', 'Project to deliver success', 'Customer Portel', 1234567890, DATE("2013-01-01"),
        DATE("2019-12-08"));

insert into rms_db.account (account_number, account_name, description, start_date, end_date)
VALUES ('1234567890', 'Jaguar land Rover', 'The Jaguar Land Rover Account', DATE("2013-01-01"), null);

insert into rms_db.role(id, role_name, description, project_code, account_number, start_date, end_date)
VALUES (1, 'Software Engineer', 'Frontend developer', '2222222222', '1234567890', DATE("2013-01-01"),
        DATE("2019-12-08"));

insert into rms_db.user (id, google_id, current_role_code)
VALUES (1, '111410204910515678218', 1);

insert into rms_db.assignment (role_id, user_id, start_date, end_date)
VALUES (1, 1, DATE("2013-01-01"), null);

SELECT r.*
FROM role r
         join (
    SELECT ass.role_id
    FROM assignment ass
    WHERE ass.user_id = 1
) as_r ON r.id = as_r.role_id;