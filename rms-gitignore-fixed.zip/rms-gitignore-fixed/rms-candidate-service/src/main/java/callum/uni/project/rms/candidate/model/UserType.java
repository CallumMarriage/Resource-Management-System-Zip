package callum.uni.project.rms.candidate.model;

public enum UserType {

    CANDIDATE,

    PROJECT_MANAGER,

    RESOURCE_MANAGER
}
