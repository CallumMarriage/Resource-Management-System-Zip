package callum.uni.project.rms.candidate.service.repository;

import callum.uni.project.rms.candidate.model.source.BusinessUnit;
import org.springframework.data.repository.CrudRepository;

public interface BusinessUnitRepository extends CrudRepository<BusinessUnit, Long> {
}
