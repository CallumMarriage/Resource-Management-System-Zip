package callum.uni.project.rms.candidate.model;

public enum RoleType {
    SOFTWARE_ENGINEER,
    PROJECT_MANAGER,
    TESTER,
    BUSINESS_ANALYST,
    DESIGNER,
    RESEARCHER,
    OTHER
}
