package callum.project.uni.rms.submission.model;

public enum RoleType {
    SOFTWARE_ENGINEER,
    PROJECT_MANAGER,
    TESTER,
    BUSINESS_ANALYST,
    DESIGNER,
    RESEARCHER,
    OTHER
}
