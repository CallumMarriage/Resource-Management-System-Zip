package callum.project.uni.rms.submission.model.request;

import callum.project.uni.rms.submission.model.target.TargetRole;

public class ReqRoleSubmission {

    private TargetRole role;

    private Long userId;
}
