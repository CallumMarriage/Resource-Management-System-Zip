Resource Management System - UI
