export default {
    retrieveShortlistForUser: jest.fn(() => Promise.resolve({
        data: [
            {
                userId: userId,
                roleId: '2'
            }
            ]
    }))
}