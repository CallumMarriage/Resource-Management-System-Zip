import {error} from "../model/error";
import {accessCandidateGet, accessCandidatePut} from "./candidateRepo";

export async function retrieveCandidatesForResourceManager(resourceManagerId) {
    try {
        console.log('Making request to Candidate API')
        let res = await accessCandidateGet(`/candidate/list?rmId=${resourceManagerId}`);

        if (res.candidates === undefined) {
            return {
                candidates: []
            }
        }

        return res;

    } catch (e) {
        return error;
    }
}

export async function retrieveFullNameForAssignment(roleId) {
    try {
        console.log('Making request to Candidate API')
        return await accessCandidateGet(`/candidate/list?roleId=${roleId}`);

    } catch (e) {
        return error;
    }
}

export async function retrieveUserById(userId) {
    try {
        console.log('Making request to user API')

        return await accessCandidateGet(`/candidate/${userId}`);
    } catch (e) {
        return error;
    }
}

export async function updateUserCurrentProject(userId, roleId){
    try {

        const body = {
            userId: userId,
            roleId: roleId,
        }

        await accessCandidatePut(`/candidate/currentRole`, body);
        return true;
    } catch (e) {
        return error;
    }
}

export async function retrieveResourceManagerBuById(rmId) {

    try {
        console.log('Making request to User API')

        return await accessCandidateGet(`/resourceManager/bu?rmId=${rmId}`);
    } catch (e) {
        return error;
    }
}

export async function retrieveCandidatesByFullName(fullName) {
    try {
        console.log('Making request to Candidate API')
        let res = await accessCandidateGet(`/candidate/list?fullName=${fullName}`);

        if (res.candidates === undefined) {
            return {
                candidates: []
            }
        }

        return res;

    } catch (e) {
        return error;
    }
}