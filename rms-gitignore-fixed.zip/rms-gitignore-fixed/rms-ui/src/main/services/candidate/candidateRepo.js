
import {get, put, post, del} from "../dao/dao"

export async function accessCandidateGet(endpoint) {
    return await get(endpoint, process.env.REACT_APP_CANDIDATE_HOST)
}

export async function accessCandidatePost(endpoint, body) {
    return await post(endpoint, body, process.env.REACT_APP_CANDIDATE_HOST)
}

export async function accessCandidatePut(endpoint, body) {
    await put(endpoint, body, process.env.REACT_APP_CANDIDATE_HOST)
}

export async function accessCandidateDelete(endpoint, body) {
    await del(endpoint, body, process.env.REACT_APP_CANDIDATE_HOST)
}