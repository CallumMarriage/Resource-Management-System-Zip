import {error} from "../model/error";
import {accessCandidateGet} from "./candidateRepo";

export async function retrieveBusinessUnits(){
    try {
        console.log('Making request to Applications api')

        const res = await accessCandidateGet(`/businessUnits`);
        if (res.businessUnitList === undefined) {
            return {
                businessUnitList: []
            }
        }

        return res;
    } catch (e) {
        return error
    }
}