import {get, put, post} from "../dao/dao"

export async function accessAssignmentGet(endpoint) {
    return await get(endpoint, process.env.REACT_APP_ASSIGNMENT_HOST)
}

export async function accessAssignmentPost(endpoint, body) {
    return await post(endpoint, body, process.env.REACT_APP_ASSIGNMENT_HOST)
}

export async function accessAssignmentPut(endpoint, body) {
    await put(endpoint, body, process.env.REACT_APP_ASSIGNMENT_HOST)
}

