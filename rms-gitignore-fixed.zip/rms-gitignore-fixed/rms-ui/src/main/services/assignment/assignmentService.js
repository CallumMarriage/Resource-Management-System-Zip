import {error} from "../model/error";
import {accessAssignmentGet, accessAssignmentPost, accessAssignmentPut} from "./assignmentRepo";

export async function addNewAssignment(userId, roleId, startDate, endDate) {
    const body = {
        userId: userId,
        roleId: roleId,
        startDate: startDate,
        endDate: endDate,
    }
    try {
        await accessAssignmentPost('/role/assignment', body);
        return true;
    } catch (e) {
        console.log(e);
        return error;
    }
}

export async function updateAssignmentEndDate(userId, roleId, endDate) {
    const body = {
        userId: userId,
        roleId: roleId,
        endDate: endDate,
    }
    try {
        await accessAssignmentPut('/role/assignment', body);
        return true;
    } catch (e) {
        return error;
    }
}

export async function getUserIdFromAssignment(roleId){
    try {
        return await accessAssignmentGet(`/role/assignment/${roleId}`);
    } catch (e) {
        return error;
    }
}
