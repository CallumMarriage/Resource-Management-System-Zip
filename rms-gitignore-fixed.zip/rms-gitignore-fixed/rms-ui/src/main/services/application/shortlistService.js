import {error} from "../model/error";
import {
    accessApplicationDel,
    accessApplicationGet,
    accessApplicationPost,
    accessApplicationPut
} from "./applicationRepo";
import {retrieveApplication} from "./applicationService";
import {rejectCandidateApplication} from "./applicationUpdateService";

export async function retrieveShortlist(roleId) {

    try {
        console.log('Making request to Shortlist API for shortlisted candidates')

        const res = await accessApplicationGet(`/shortlist?roleId=${roleId}`);

        if (res.shortlist === undefined) {
            return {
                shortlist: []
            }
        }

        return res.shortlist;
    } catch (e) {
        console.log(e);
        return error;
    }
}

export async function retrieveShortlistForUser(userId) {

    try {
        console.log('Making request to Shortlist API for shortlisted candidates')

        const res = await accessApplicationGet(`/shortlist?userId=${userId}`);

        if (res.shortlist === undefined) {
            return {
                shortlist: []
            }
        }

        return res.shortlist;
    } catch (e) {
        console.log(e);
        return error;
    }
}

export async function approveShortlistedCandidate(userId, roleId) {
    try {
        console.log('Making request to approve application for role')

        const body = {
            candidateId: userId,
            roleId: roleId
        }

        await accessApplicationPut(`/shortlist/confirm`, body);
        return true;
    } catch (e) {
        return {
            hasError: true
        }
    }
}

export async function rejectShortlistedCandidate(userId, roleId) {
    try {
        console.log('Making request to reject application for role')
        await accessApplicationDel(`/shortlist/reject/user/${userId}/role/${roleId}`,
            {});
        const res = await retrieveApplication(userId, roleId);
        await rejectCandidateApplication(res.applicationId, '1')
    } catch (e) {
        return {
            hasError: true
        }
    }
}

export async function addCandidateToShortlist(userId, roleId) {
    try {
        console.log('Making request to reject application for role')

        const body = {
            candidateId: userId,
            roleId: roleId
        }

        await accessApplicationPost('/shortlist/candidate', body);
        return true;
    } catch (e) {
        console.log(e);
        return {
            hasError: true
        }
    }
}