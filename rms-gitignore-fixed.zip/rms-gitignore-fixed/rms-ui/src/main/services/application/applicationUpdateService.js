import {accessApplicationPut} from "./applicationRepo";

export async function confirmCandidateApplication(applicationId) {
    try {
        console.log('Making request to approve application for role')
        const body = {
            applicationId: applicationId
        }

        await accessApplicationPut('/application/confirm', body);
        return true;
    } catch (e) {
        return {
            hasError: true
        }
    }
}

export async function shortlistCandidateApplication(applicationId) {
    try {
        console.log('Making request to approve application for role')
        const body = {
            applicationId: applicationId
        }

        await accessApplicationPut('/application/shortlist', body);
        return true;
    } catch (e) {
        return {
            hasError: true
        }
    }
}

export async function rejectCandidateApplication(applicationId) {
    try {
        console.log('Making request to reject application for role')
        const body = {
            applicationId: applicationId
        }

        await accessApplicationPut('/application/reject', body);
        return true
    } catch (e) {
        return {
            hasError: true
        }
    }
}

export async function markAsInReviewCandidateApplication(applicationId, authorizerId) {
    try {
        console.log('Making request to reject application for role')
        const body = {
            applicationId: applicationId,
            authorizerId: authorizerId
        }

        await accessApplicationPut('/application/inReview', body);
        return true
    } catch (e) {
        console.log(e);
        return {
            hasError: true
        }
    }
}
