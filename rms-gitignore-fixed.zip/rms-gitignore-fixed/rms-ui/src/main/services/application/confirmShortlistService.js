import {approveShortlistedCandidate} from "./shortlistService";
import {retrieveApplication} from "./applicationService";
import {confirmCandidateApplication} from "./applicationUpdateService";
import {updateUserCurrentProject} from "../candidate/candidateService";
import {retrieveRole, updateRoleAsActive} from "../api/roleService";
import {addNewAssignment} from "../assignment/assignmentService";

export default async function  confirmApp(userId, roleId){
    const res = await approveShortlistedCandidate(userId, roleId);

    if(res.hasError){
        return true;
    }

    const app = await retrieveApplication(userId, roleId);
    if(app.hasError){
        return true
    }

    const cfmAp = await confirmCandidateApplication(app.applicationId)
    if(cfmAp.hasError){
        return true;
    }

    const upUsr = await updateUserCurrentProject(userId, roleId);
    if(upUsr.hasError){
        return true;
    }
    const role = await retrieveRole(roleId);

    if(role.hasError){
        return true;
    }
    const assignment = await addNewAssignment(userId, roleId, role.startDate, role.endDate);

    if(assignment.hasError){
        return true;
    }
    const upRole = await updateRoleAsActive(roleId);

    return upRole.hasError;
}