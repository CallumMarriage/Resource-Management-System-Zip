import {get, put, post, del} from "../dao/dao"

export async function accessApplicationGet(endpoint) {
    return await get(endpoint, process.env.REACT_APP_APPLICATION_HOST)
}

export async function accessApplicationPost(endpoint, body) {
    return await post(endpoint, body, process.env.REACT_APP_APPLICATION_HOST)
}

export async function accessApplicationPut(endpoint, body) {
    await put(endpoint, body, process.env.REACT_APP_APPLICATION_HOST)
}
export async function accessApplicationDel(endpoint, body) {
    await del(endpoint, body, process.env.REACT_APP_APPLICATION_HOST)
}

