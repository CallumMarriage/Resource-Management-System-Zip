import {error} from "../model/error";
import {accessApplicationGet, accessApplicationPost, accessApplicationPut} from "./applicationRepo";

export async function retrieveApplicationsForRm(rmId) {
    try {
        console.log('Making request to Applications api')

        const res = await accessApplicationGet(`/applications?rmId=${rmId}`);

        if (res.applicationInfoList === undefined) {
            return {
                applicationInfoList: []
            }
        }

        return res;
    } catch (e) {
        return error
    }
}

export async function retrieveApplication(userId, roleId){
    try {
        console.log('Making request to Applications api')

        return await accessApplicationGet(`/application/role/${roleId}/user/${userId}`)
    } catch (e) {
        console.log(e);
        return {
            hasError: true
        }
    }
}

export async function retrieveApplications(userId) {
    try {
        console.log('Making request to Applications api')

        const res = await accessApplicationGet(`/applications?userId=${userId}`);

        if (res.applicationInfoList === undefined) {
            return {
                applicationInfoList: []
            }
        }

        return res;
    } catch (e) {
        return error
    }
}

export async function hasUserAlreadyApplied(userId, roleId) {
    try {
        console.log('Making request to Applications api')

        return await accessApplicationGet(`/applications/${roleId}/userAlreadyApplied?userId=${userId}`)
    } catch (e) {
        console.log(e);
        return {
            hasError: true
        }
    }
}

export async function retrieveNumOfApplications(userId) {
    try {
        console.log('Making request to Applications api')

        return await accessApplicationGet(`/applications/amount?userId=${userId}`)
    } catch (e) {
        console.log(e);
        return {
            hasError: true
        }
    }
}

export async function applyForRole(userId, role) {
    try {
        console.log('Making request to add application for role')
        const body = {
            applicantId: userId,
            roleId: role.id,
            projectCode: role.projectCode,
            accountNumber: role.accountNumber
        }

        await accessApplicationPost('/application/submit', body);
        return true;
    } catch (e) {
        console.log(e);
        return {
            hasError: true
        }
    }
}