export const error = {
    hasError: true,
    error: 'Internal Server Error'
};
