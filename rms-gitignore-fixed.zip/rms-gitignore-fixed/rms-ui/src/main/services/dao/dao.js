export async function get(endpoint, host) {
    let res = await fetch(`https://${host}${endpoint}`,
        {
            method: 'GET',
            headers: {'Content-Type': 'application/json'}
        }
    );

    if (res.status === 404) {
        return {}
    } else if (res.status !== 200) {
        throw new Error(res.statusText);
    }

    return await res.json()
}

export async function post(endpoint, body, host) {
    let res = await fetch(`https://${host}${endpoint}`,
        {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(body)
        }
    );

    if (!goodStatus.includes(res.status)) {
        throw new Error(res.statusText);
    }

    return res.json();
}

export async function put(endpoint, body, host) {
    let res = await fetch(`https://${host}${endpoint}`,
        {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(body)
        }
    );

    if (res.status !== 204) {
        throw new Error(res.statusText);
    }
}

export async function del(endpoint, body, host) {
    let res = await fetch(`https://${host}${endpoint}`,
        {
            method: 'DELETE',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(body)
        }
    );

    if (res.status !== 204) {
        throw new Error(res.statusText);
    }
}

const goodStatus = [
    200,
    201,
    202,
    204
]