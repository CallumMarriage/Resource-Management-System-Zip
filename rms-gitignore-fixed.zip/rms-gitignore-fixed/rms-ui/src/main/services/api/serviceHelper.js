import {error} from "../model/error";
import {accessApiGet} from "./apiRepo";

export async function handleGet(endpoint) {
    try {
        return await accessApiGet(endpoint);
    } catch (e) {
        console.log(e);
        return error
    }
}
