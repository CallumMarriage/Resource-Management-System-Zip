import {handleGet} from "./serviceHelper";
import {error} from "../model/error";
import {accessApiPost, accessApiPut} from "./apiRepo";

export async function updateProject(project, newRoles, updatedRoles, removedRoles, userId) {
    const body = {
        startDate: project.startDate,
        endDate: project.endDate,
        accountNumber: project.accountNumber,
        projectCode: project.projectCode,
        projectName: project.projectName,
        description: project.description,
        projectManagerId: userId,
        newRoles: newRoles,
        updatedRoles: updatedRoles,
        removedRoles: removedRoles
    }

    try {
        await accessApiPut(`/project/update`, body);
        return true;
    } catch (e) {
        console.log(e);
        return error;
    }
}

export async function retrieveProjectInfo(projectCode) {

    return await handleGet(`/projects/id/${projectCode}`)

}

export async function retrieveAccountsAndProjectsForPm(projectManagerId) {

    try {
        const res = await handleGet(`/accounts/projects?projectManagerId=${projectManagerId}`)
        if (res.accountAndProjectsList === undefined) {
            return {
                accountAndProjectsList: []
            }
        }

        return res;

    } catch (e) {
        return error;
    }
}


export async function retrieveProjectsForProjectManager(projectManagerId) {
    return await handleGet(`/projects?projectManagerId=${projectManagerId}`)
}

export async function addNewProject(projectCode, accountNumber, projectName,
                                    description, baseLocation, userId,
                                    startDate, endDate) {
    const body = {
        startDate: startDate,
        endDate: endDate,
        accountNumber: accountNumber,
        projectCode: projectCode,
        projectName: projectName,
        description: description,
        baseLocation: baseLocation,
        projectManagerId: userId
    }

    try {
        await accessApiPost('/project', body);
        return true;
    } catch (e) {
        return error;
    }
}
