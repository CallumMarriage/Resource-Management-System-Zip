
import {get, put, post, del} from "../dao/dao"

export async function accessApiGet(endpoint) {
    return await get(endpoint, process.env.REACT_APP_API_HOST)
}

export async function accessApiPost(endpoint, body) {
    return await post(endpoint, body, process.env.REACT_APP_API_HOST)
}

export async function accessApiPut(endpoint, body) {
    await put(endpoint, body, process.env.REACT_APP_API_HOST)
}

export async function accessApiDelete(endpoint, body) {
    await del(endpoint, body, process.env.REACT_APP_API_HOST)
}