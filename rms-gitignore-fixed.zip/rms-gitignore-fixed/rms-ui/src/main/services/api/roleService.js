import {error} from "../model/error";
import {accessApiGet, accessApiPost, accessApiPut} from "./apiRepo";
import {retrieveResourceManagerBuById} from "../candidate/candidateService";

export async function findRolesWithFilters(filters) {
    try {
        let endpoint = '/roles?'
        let i = 0;
        filters.forEach(filter => {
            if (i >= 1) {
                endpoint = endpoint + '&' + filter;
            } else {
                endpoint = endpoint + filter;
            }
            i++;
        })

        const res = await accessApiGet(endpoint);

        if (res.roleList === undefined) {
            return {
                roleList: []
            }
        }

        return res.roleList;
    } catch (e) {
        return error;
    }
}

export async function updateRole(role) {
    try {
        console.log('Making request to Role API')
        const body = {
            id: role.id,
            baseLocation: role.baseLocation,
            certainty: role.certainty,
            description: role.description,
            startDate: role.startDate,
            grade: role.grade,
            endDate: role.endDate,
            roleName: role.roleName,
            roleType: role.roleType,
            businessUnitId: role.businessUnitId
        }

        await accessApiPut(`/role/${role.id}`, body);
        return true;
    } catch (e) {
        console.log(e);
        return error;
    }
}

export async function updateRoleAsActive(roleId) {
    try {
        console.log('Making request to Role API')
        const body = {
            roleActive: false
        }

        await accessApiPut(`/role/${roleId}/active`, body);
        return true;
    } catch (e) {
        console.log(e);
        return error;
    }
}

export async function retrieveCandidateForRole(roleId) {
    try {
        console.log('Making request to Role API')
        return await accessApiGet(`/role/${roleId}/candidate`);

    } catch (e) {
        return error;
    }
}

export async function addNewRole(userId, state) {
    console.log("Making request to add new Role");
    const body = {
        userId,
        role: {
            startDate: state.startDate,
            endDate: state.endDate,
            grade: state.grade,
            accountNumber: state.accountNumber,
            accountName: state.accountName,
            baseLocation: state.baseLocation,
            projectCode: state.projectCode,
            projectName: state.projectName,
            description: state.description,
            roleName: state.roleName,
            roleType: state.roleType,
            businessUnitId: state.businessUnitId
        }
    }
    try {
        return await accessApiPost('/role', body);
    } catch (e) {
        return error;
    }
}

export async function retrieveRole(roleId) {
    try {
        console.log('Making request to Role API')

        return await accessApiGet(`/role/${roleId}`);
    } catch (e) {
        return error;
    }
}

export async function retrieveRolesByAccountName(accountName) {
    try {
        console.log('Making request to Role API')

        const res = await accessApiGet(`roles?roleType=${accountName}`)

        if (res.roleList === undefined) {
            return {
                roleList: []
            }
        }

        return res;
    } catch (e) {
        return error;
    }
}

export async function retrieveRolesByRoleType(roleType) {
    try {
        console.log('Making request to Role API')

        const res = await accessApiGet(`/roles?roleType=${roleType}`);

        if (res.roleList === undefined) {
            return {
                roleList: []
            }
        }

        return res;

    } catch (e) {
        return error;
    }
}

export async function retrievePotentialRoles() {
    try {
        console.log('Making request to Role API for potential roles')

        const res = await accessApiGet(`/roles`);

        if (res.roleList === undefined) {
            return {
                roleList: []
            }
        }

        return res.roleList;
    } catch (e) {
        return error;
    }
}

export async function retrieveDemand(rmId) {
    try {
        console.log('Making request to Role API for potential roles')

        const res = await retrieveResourceManagerBuById(rmId);

        if(res.hasError){
            return res;
        }

        const roles = await accessApiGet(`/roles/open?buId=${res.buId}`)

        if (roles.roleList === undefined) {
            return {
                roleList: []
            }
        }

        return roles.roleList;
    } catch (e) {
        return error;
    }
}

export default async function retrieveOpenRolesForProject(projectCode) {
    try {
        console.log('Making request to Role API for potential roles')

        const roles = await accessApiGet(`/roles/open?projectCode=${projectCode}`)

        if (roles.roleList === undefined) {
            return {
                roleList: []
            }
        }

        return roles.roleList;
    } catch (e) {
        return error;
    }
}


