import {error} from "../model/error";
import {handleGet} from "./serviceHelper";
import {accessApiGet, accessApiPost} from "./apiRepo";
import {accessCandidatePost} from "../candidate/candidateRepo";

export async function retrieveUserInfo(ssoId) {
    try {
        console.log(ssoId)
        console.log('Making request to user API')

        return await accessApiGet(`/user/info?ssoId=${ssoId}`);
    } catch (e) {
        return error;
    }
}

export async function userExists(ssoId) {
    try {
        console.log(ssoId)

        console.log('Making request to USER API')

        return await handleGet(`/user/exists?ssoId=${ssoId}`);
    } catch (e) {
        return error;
    }
}

export async function handleAddNewUser(ssoId, name,
                                       grade, userType,
                                       userSpecialism, baseLocation,
                                       businessUnitId) {

    try {
        const data = {
            ssoId: ssoId,
            name: name,
            grade: grade,
            userType: userType,
            userSpecialism: userSpecialism,
            baseLocation: baseLocation,
            businessUnitId: businessUnitId
        }

        const res = await accessApiPost(`/user/`, data);
        if(userType === 'RESOURCE_MANAGER'){
            console.log(res);
            const data = {
                rmId: res.user.id,
                businessUnitId: businessUnitId
            }
            console.log(data);
            await accessCandidatePost(`/resourceManager`, data)
        }

        return res;
    } catch (e) {
        return error;
    }
}