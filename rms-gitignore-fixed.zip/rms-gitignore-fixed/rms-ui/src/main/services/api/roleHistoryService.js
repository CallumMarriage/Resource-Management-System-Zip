import {error} from "../model/error";
import {accessApiGet} from "./apiRepo";

export async function retrieveRoleHistory(id) {
    try {
        console.log('Making request to Role API')
        let res = await accessApiGet(`/roles?userId=${id}`);

        if (res.roleList === undefined) {
            return {
                roleList: []
            }
        }

        return res;

    } catch (e) {
        return error;
    }
}