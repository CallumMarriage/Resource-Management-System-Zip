import {error} from "../model/error";
import {accessSubmissionDelete, accessSubmissionGet, accessSubmissionPost, accessSubmissionPut} from "./submissionRepo";
import {retrieveResourceManagerBuById} from "../candidate/candidateService";

export async function rejectSubmission(subId) {

    try {
        console.log('Making request to Role API')

        await accessSubmissionDelete(`/role/submission/reject/${subId}`);
        return true
    } catch (e) {
        console.log(e);
        return error;
    }
}


export async function approveSubmission(subId) {

    try {
        console.log('Making request to Role API')

        await accessSubmissionPut(`/role/submission/approve/${subId}`);
        return true;
    } catch (e) {
        console.log(e);
        return error;
    }
}


export async function retrieveNewRoleSubmissionForRm(rmId) {
    try {
        console.log('Making request to Role API')

        const rm = await retrieveResourceManagerBuById(rmId);

        console.log(rm);

        const res = await accessSubmissionGet(`/role/submissions?buId=${rm.buId}`);

        if (res.roleSubmissions === undefined) {
            return {
                roleSubmissions: []
            }
        }

        return res;
    } catch (e) {
        console.log(e);
        return error;
    }
}

export async function addNewRoleSubmission(userId, role) {
    console.log("Making request to add new Role Submission");
    const body = {
        userId,
        role: {
            startDate: role.startDate,
            endDate: role.endDate,
            accountNumber: role.accountNumber,
            accountName: role.accountName,
            projectCode: role.projectCode,
            projectName: role.projectName,
            businessUnit: role.businessUnitId,
            description: role.description,
            grade: role.grade,
            baseLocation: role.baseLocation,
            roleName: role.roleName,
            roleType: role.roleType
        }
    }
    try {
        await accessSubmissionPost('/role/submission/submit', body);
        return true;
    } catch (e) {
        return error;
    }
}