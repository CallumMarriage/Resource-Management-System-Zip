import {get, put, post, del} from "../dao/dao"

export async function accessSubmissionGet(endpoint) {
    return await get(endpoint, process.env.REACT_APP_SUBMISSION_HOST)
}

export async function accessSubmissionPost(endpoint, body) {
    return await post(endpoint, body, process.env.REACT_APP_SUBMISSION_HOST)
}

export async function accessSubmissionPut(endpoint, body) {
    await put(endpoint, body, process.env.REACT_APP_SUBMISSION_HOST)
}

export async function accessSubmissionDelete(endpoint, body) {
    await del(endpoint, body, process.env.REACT_APP_SUBMISSION_HOST)
}
