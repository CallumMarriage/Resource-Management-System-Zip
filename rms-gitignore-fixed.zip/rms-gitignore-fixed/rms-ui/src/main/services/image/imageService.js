import {error} from "../model/error";
import {accessImageGet, accessImagePost} from "./imageRepo";

export async function uploadImageFile(accountId, file) {
    try {
        console.log('Making upload image request to Account API')

        const body = {
            accountId: accountId,
            base64EncodedImage: file
        }

        await accessImagePost(`/image`, body);
        return true;
    } catch (e) {
        console.log(e)
        return error
    }
}

export async function retrieveImageFile(accountId) {
    try {
        console.log('Making GET image request to Account API')

        let image = await accessImageGet(`/image?accountId=${accountId}`)
        return image.base64Image;
    } catch (e) {
        return error
    }
}
