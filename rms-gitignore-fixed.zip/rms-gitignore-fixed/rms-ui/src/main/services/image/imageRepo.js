import {get, post} from "../dao/dao"

export async function accessImageGet(endpoint) {
    return await get(endpoint, process.env.REACT_APP_IMAGE_SERVICE_HOST);
}

export async function accessImagePost(endpoint, body) {
    return await post(endpoint, body, process.env.REACT_APP_IMAGE_SERVICE_HOST);
}
