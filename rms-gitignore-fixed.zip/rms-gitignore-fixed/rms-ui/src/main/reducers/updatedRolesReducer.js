const INITIAL_STATE = {
    updatedRoles: [],
};

export default function updatedRolesReducer(state = INITIAL_STATE, action) {
    switch (action.type) {
        case 'UPDATE_ROLE':
            return {
                ...state,
                updatedRoles: [ ...state.updatedRoles, action.roleToUpdate ]
            }
        case 'REMOVE_UPDATED_ROLE':
            return {
                ...state,
                updatedRoles: [...state.updatedRoles.slice(0, action.roleToRemove)]
            }
        case 'REMOVE_ALL_UPDATED_ROLES':
            return {
                ...state,
                updatedRoles: []
            }
        default:
            return state;
    }
};
