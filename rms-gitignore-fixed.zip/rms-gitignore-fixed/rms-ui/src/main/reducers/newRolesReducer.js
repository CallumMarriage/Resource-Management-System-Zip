const INITIAL_STATE = {
    newRoles: [],
};

export default function newRolesReducer(state = INITIAL_STATE, action) {
    switch (action.type) {
        case 'UPDATE_NEW_ROLE':
            return {
                ...state,
                newRoles: [ ...state.newRoles, action.newRole ]
            }
        case 'REMOVE_ROLE':
            return {
                ...state,
                newRoles: [...state.newRoles.slice(0, action.roleToRemove)]
            }
        case 'REMOVE_ALL_ROLES':
            return {
                ...state,
                newRoles: []
            }
        default:
            return state;
    }
};
