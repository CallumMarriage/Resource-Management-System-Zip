import { combineReducers } from 'redux';

import ssoReducer from './ssoReducer';
import userReducer from "./userReducer";
import newRolesReducer from "./newRolesReducer";
import updatedRolesReducer from "./updatedRolesReducer";

export default combineReducers( {
    auth: ssoReducer,
    user: userReducer,
    projectUpdate: newRolesReducer,
    roleUpdate: updatedRolesReducer
});