import React, {useEffect} from 'react';
import {connect} from 'react-redux';

import Header from "./components/header/Header";
import Footer from "./components/footer/Footer";
import Navbar from "./components/nav-bar/Navbar";
import MyRouter from "./router/Router";
import Grid from "@material-ui/core/Grid";
import {unstable_createMuiStrictModeTheme as createMuiTheme, ThemeProvider} from '@material-ui/core/styles';
import CircularProgress from "@material-ui/core/CircularProgress";

import './App.css';
import Auth from "./components/auth/Auth";

const theme = createMuiTheme({
    typography: {
        fontFamily: 'Ubuntu'
    },
    palette: {
        primary: {
            light: '#12ABDB',
            dark: '#6D64CC',
            main: '#0070AD',
        },
        secondary: {
            main: '#ffffff',
            dark: '#D9D9D6',
            light: '#80B8D6'
        }
    },
    success: {
        main: '#A9C23F',
        dark: '#15596B',
        light: '#95E616'
    },
    error: {
        main: '#E03E52',
        dark: '#CB2980',
        light: '#FF7E83'
    },
    overrides: {
        MuiButton: {
            root: {
                borderRadius: '32px',
                fontSize: '16pt',
                fontWeight: 'medium',
                color: 'white',
                textDecoration: 'none',
                textTransform: 'none',
                maxHeight: '48px',
                width: 'auto',
                "&:hover": {
                    backgroundColor: '#80B8D6',
                    color: '#0070AD'
                }
            }
        },
        MuiPaper: {
            root: {
                backgroundColor: 'white',
                margin: 'auto'
            }
        }
    }
});

function App(props) {


    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    return (
        <div className="App">
            <ThemeProvider theme={theme}>
                <Grid container>
                    <Grid item xs={12}>
                        <Header/>
                    </Grid>
                    <Grid item xs={12}>
                        {renderPage(props)}
                    </Grid>
                    <Grid item xs={12}>
                        <Footer/>
                    </Grid>
                </Grid>
            </ThemeProvider>
        </div>
    );

}

function renderPage(props) {

    if (props.isSignedIn) {
        if (props.userExists) {
            return (
                <Grid container style={{ marginBottom: '50px'}}>
                    <Grid item xs={12}>
                        <Navbar/>
                    </Grid>
                    <Grid item xs={11} style={{margin: 'auto', marginTop: '10px'}}>
                        {RenderRouter(props)}
                    </Grid>
                </Grid>
            )
        } else if (props.userExists !== null) {
            return (
                <Grid container>
                    {RenderRouter(props)}
                </Grid>
            )
        }
    }
    if (props.loading) {
        return (
            <Grid item xs={8}>
                <Auth/>
                <CircularProgress style={{margin: 'auto'}}/>
            </Grid>
        )
    }
    return (
        <Grid item xs={12}>
            <Auth/>
        </Grid>
    )
}

function RenderRouter(props) {
    return (<MyRouter isSignedIn={props.isSignedIn}
                      userExists={props.userExists}
                      user={props.user}/>)

}


const mapStateToProps = (state) => {
    return {
        isSignedIn: state.auth.isSignedIn,
        ssoId: state.auth.ssoId,
        loading: state.auth.loading,
        userExists: state.user.userExists,
        user: state.user.user,
        authFailed: state.user.authFailed
    };
}

export default connect(mapStateToProps)(App);