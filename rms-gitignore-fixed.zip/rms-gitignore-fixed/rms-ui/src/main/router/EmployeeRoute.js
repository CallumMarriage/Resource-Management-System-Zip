import React from 'react';
import {Redirect, Route} from 'react-router-dom';

function EmployeeRoute({component: C, appProps, ...rest}) {
    return (
        <Route
            {...rest}
            render={
                props =>
                    appProps.isSignedIn ?
                        !appProps.userExists ?
                            <Redirect to={{pathname: "/SignUp", state: {from: appProps.location}}}/>
                            :
                            <C {...props} {...appProps} /> :
                        <Redirect to={{pathname: "/Login", state: {from: appProps.location}}}/>
            }
        />
    );
}

export default EmployeeRoute;