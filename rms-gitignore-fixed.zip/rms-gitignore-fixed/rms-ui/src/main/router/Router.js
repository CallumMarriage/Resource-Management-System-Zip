import {Redirect, Route, Switch} from "react-router-dom";
import EmployeeRoute from "./EmployeeRoute";
import Home from "../components/home/Home";
import MyCapgeminiCv from "../components/my-cap-cv/MyCapgeminiCv";
import FindRoles from "../components/find-roles/FindRoles";
import NotFound from "../components/not-found/NotFound";
import React from "react";
import MyApplications from "../components/my-applications/MyApplications";
import ViewRole from "../components/sub-pages/role/ViewRole";
import Account from "../components/sub-pages/account/Account";
import Project from "../components/sub-pages/project/Project";
import SearchAccounts from "../components/search-accounts/SearchAccounts";
import ProjectManagerSpace from "../components/project-manager-space/ProjectManagerSpace";
import AddNewAccount from "../components/sub-pages/account/AddNewAccount";
import AddNewProject from "../components/sub-pages/project/AddNewProject";
import SignUp from "../components/login/SignUp";
import ProjectManagerRoute from "./ProjectManagerRoute";
import Unauthorised from "../components/not-found/Unauthorised";
import SignUpRoute from "./SignUpRoute";
import ViewCandidates from "../components/resource-manager-space/view-candidates/ViewCandidates";
import Candidate from "../components/sub-pages/candidate/Candidate";
import UpdateProject from "../components/sub-pages/project/UpdateProject";
import AddNewRoleForProject from "../components/sub-pages/project/AddNewRoleForProject";
import ServiceUnavailable from "../components/service-unavailable/ServiceUnavailable";
import ResourceManagerRoute from "./ResourceManagerRoute";
import AddNewRoleSubmission from "../components/sub-pages/role/AddNewRoleSubmission";
import MapWrapper from "../components/find-roles/MapWrapper";
import Demand from "../components/resource-manager-space/demand/Demand";
import CandidateApplications from "../components/resource-manager-space/application-approvals/CandidateApplications";
import NewRoleSubmissions from "../components/resource-manager-space/submission-approvals/NewRoleSubmissions";
import Shortlist from "../components/resource-manager-space/demand/Shortlist";
import AddCandidateToShortlist from "../components/sub-pages/candidate/AddCandidateToShortlist";
import MyShortlisted from "../components/my-applications/MyShortlisted";
import UpdateRole from "../components/sub-pages/role/UpdateRole";

export default function MyRouter(props) {
    return (
        <div style={{width: '100%', minHeight: '500px'}}>
            <Switch>
                <Redirect from={"/"} to={"/Home"} exact/>
                <SignUpRoute exact path={'/SignUp'}
                             component={SignUp}
                             appProps={{
                                 isSignedIn: props.isSignedIn,
                                 userExists: props.userExists
                             }}/>

                {createEmployeeRoute("/Home", props, Home)}

                {createEmployeeRoute("/SignUp", props, Home)}
                {createEmployeeRoute("/MyCapgeminiCV", props, MyCapgeminiCv)}
                {createEmployeeRoute("/SubmitRole", props, AddNewRoleSubmission)}
                {createEmployeeRoute("/SearchAccounts", props, SearchAccounts)}

                {createEmployeeRoute("/Applications/FindRoles", props, FindRoles)}
                {createEmployeeRoute("/Applications/FindRoles/RoleMap", props, MapWrapper)}
                {createEmployeeRoute("/Applications/MyApplications", props, MyApplications)}
                {createEmployeeRoute("/Applications/MyShortlisted", props, MyShortlisted)}

                {createEmployeeRoute("/SearchAccounts/Account/:accountId/Project/:projectId/ViewRole/:id", props, ViewRole)}
                {createEmployeeRoute("/SearchAccounts/Account/:accountId/Project/:projectId", props, Project)}
                {createEmployeeRoute("/SearchAccounts/Account/:accountId", props, Account)}

                {createResourceManagerRoute("/ResourceManagement/NewRoleSubmissions", props, NewRoleSubmissions)}
                {createResourceManagerRoute("/ResourceManagement/ShortListApplications", props, CandidateApplications)}
                {createResourceManagerRoute("/ResourceManagement/ViewCandidates", props, ViewCandidates)}
                {createResourceManagerRoute("/ResourceManagement/ViewCandidates/Candidate/:candidateId",
                    props, Candidate)}
                {createResourceManagerRoute("/ResourceManagement/Demand", props, Demand)}
                {createResourceManagerRoute("/ResourceManagement/Demand/:roleId/Shortlist", props, Shortlist)}
                {createResourceManagerRoute("/ResourceManagement/Demand/:roleId/Shortlist/AddCandidate", props,
                    AddCandidateToShortlist)}

                {createProjectManagerRoute("/ProjectManagement", props, ProjectManagerSpace)}
                {createProjectManagerRoute("/ProjectManagement/AddNewAccount", props, AddNewAccount)}
                {createProjectManagerRoute("/ProjectManagement/UpdateAccount", props, AddNewAccount)}
                {createProjectManagerRoute("/ProjectManagement/AddNewProject", props, AddNewProject)}
                {createProjectManagerRoute("/ProjectManagement/UpdateProject", props, UpdateProject)}
                {createProjectManagerRoute("/ProjectManagement/Project/:projectId/Role/:roleId/UpdateRole",
                    props, UpdateRole)}
                {createProjectManagerRoute("/ProjectManagement/AddNewRole", props, AddNewRoleForProject)}
                {createProjectManagerRoute("/ProjectManagement/UpdateRole", props, ViewRole)}

                <Route path={"/ServiceUnavailable"} exact={true} component={ServiceUnavailable}/>
                <Route path="/Unauthorised" exact={true} component={Unauthorised}/>
                <Route path="*" exact={true} component={NotFound}/>
            </Switch>
        </div>
    )
}

function createProjectManagerRoute(path, props, component) {

    let userType = null;
    if (props.user !== undefined && props.user !== null) {
        userType = props.user.userType;
    }

    return (
        <ProjectManagerRoute exact path={path}
                             component={component}
                             appProps={{
                                 isSignedIn: props.isSignedIn,
                                 userExists: props.userExists,
                                 userType: userType,
                                 authFailed: props.authFailed
                             }}/>
    )
}

function createResourceManagerRoute(path, props, component) {

    let userType = null;
    if (props.user !== undefined && props.user !== null) {
        userType = props.user.userType;
    }

    return (
        <ResourceManagerRoute exact path={path}
                              component={component}
                              appProps={{
                                  isSignedIn: props.isSignedIn,
                                  userExists: props.userExists,
                                  userType: userType,
                                  authFailed: props.authFailed
                              }}/>
    )
}

function createEmployeeRoute(path, props, component) {

    return (
        <EmployeeRoute exact path={path}
                       component={component}
                       appProps={{
                           isSignedIn: props.isSignedIn,
                           userExists: props.userExists
                       }}/>
    )
}