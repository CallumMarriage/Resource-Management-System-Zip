export const addUpdatedRole = (roleToUpdate) => {
    return {
        type: 'UPDATE_ROLE',
        roleToUpdate: roleToUpdate
    };
}

export const removeUpdatedRole = (roleToRemove) => {

    return {
        type: "REMOVE_UPDATED_ROLE",
        roleToRemove: roleToRemove
    };
};

export const removeAllUpdatedRoles = () => {
    return {
        type: "REMOVE_ALL_UPDATED_ROLES"
    }
}