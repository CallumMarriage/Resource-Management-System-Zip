export const addNewRole = (newRole) => {
    return {
        type: 'UPDATE_NEW_ROLE',
        newRole: newRole
    };
}

export const removeRole = (roleToRemove) => {

    return {
        type: "REMOVE_ROLE",
        roleToRemove: roleToRemove
    };
};

export const removeAllRoles = () => {
    return {
        type: "REMOVE_ALL_ROLES"
    }
}