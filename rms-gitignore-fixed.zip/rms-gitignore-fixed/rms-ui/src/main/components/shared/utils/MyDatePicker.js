import React from 'react';
import DateFnsUtils from '@date-io/date-fns';
import {DatePicker, MuiPickersUtilsProvider} from '@material-ui/pickers';
import createMuiTheme from "@material-ui/core/styles/createMuiTheme";
import {ThemeProvider} from "styled-components";
import withStyles from "@material-ui/core/styles/withStyles";

const theme = createMuiTheme({
    datePicker: {
        selectColor: 'pink'
    }
});


const StyledDatePicker = withStyles({

    root: {
        borderRadius: '32px',
        fontSize: '16pt',
        fontWeight: 'medium',
        backgroundColor: '#ffffff',
        color: 'white',
        textDecoration: 'none',
        textTransform: 'none',
        maxHeight: '48px',
        width: 'auto',
        "&:hover": {
            backgroundColor: '#80B8D6',
            color: '#0070AD'
        }

    }

})(DatePicker)


class MyDatePicker extends React.Component {
    constructor(props) {
        super(props);
    }

    disableDates = (date) => {
        return date < Date.parse(this.props.parentStartDate) ||
            date > Date.parse(this.props.parentEndDate);
    }

    render() {
        return (
            <ThemeProvider theme={theme}>

                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <DatePicker value={this.props.date}
                                showTodayButton={true}
                                openTo={"year"}
                                format="dd/MM/yyyy"
                                inputVariant={"outlined"}
                                onChange={this.props.handleChange}
                                shouldDisableDate={this.disableDates}
                                style={{width: '80%', padding: '20px'}}/>

                </MuiPickersUtilsProvider>
            </ThemeProvider>
        )
    }
}


export default MyDatePicker;