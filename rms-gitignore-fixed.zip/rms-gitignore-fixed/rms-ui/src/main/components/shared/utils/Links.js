import {Link} from "react-router-dom";
import React from "react";

export function AccountLink(props, Content) {
    return (
        <Link style={{textDecoration: 'none'}} to={{
            pathname: `/SearchAccounts/Account/${props.accountNumber}`,
            state: {accountNumber: props.accountNumber}
        }}>
            <Content props={props}/>
        </Link>
    )
}

export function CandidateLink(props, Content) {
    return (
        <Link style={{textDecoration: 'none'}} to={{
            pathname: `/ResourceManagement/ViewCandidates/Candidate/${props.id}`,
            state: {
                candidateId: props.id,
                currentRoleId: props.currentRoleId,
                fullName: props.fullName,
                userSpecialism: props.userSpecialism
            }
        }}>
            <Content props={props}/>

        </Link>
    )
}

export function ProjectLink(props, Content) {
    return (
        <Link style={{textDecoration: 'none'}} to={{
            pathname: `/SearchAccounts/Account/${props.accountNumber}/Project/${props.projectCode}`,
            state: {projectCode: props.projectCode, accountName: props.accountName}
        }}>
            <Content props={props}/>
        </Link>
    )
}

export function RoleLink(props, Content) {
    return (
        <Link style={{textDecoration: 'none'}} to={{
            pathname: `/SearchAccounts/Account/${props.accountNumber}/Project/${props.projectCode}/ViewRole/${props.id}`,
            state: {role: props}
        }}>
            <Content props={props}/>
        </Link>
    )
}

export function AddNewProjectLink(props, Content) {
    return (

        <Link style={{ textDecoration: 'none' }} to={{
            pathname: "/ProjectManagement/AddNewProject",
            state: {accountNumber: props.accountNumber}}}>
            <Content/>
        </Link>

    )
}