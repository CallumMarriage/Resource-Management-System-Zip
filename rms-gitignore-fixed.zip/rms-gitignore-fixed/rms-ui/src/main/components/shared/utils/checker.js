export function handleListItemCheck(listItem) {
    return listItem.value === 'PLEASE_SELECT';
}

export function checkRoleDetails(roleName, roleType, baseLocation,
                                 businessUnit, grade, setAsErrored ){
    let hasError = false
    if (roleName.value === '') {
        setAsErrored(roleName, 'roleName')
        hasError = true
    }

    if (handleListItemCheck(roleType)) {
        setAsErrored(roleType, 'roleType')
        hasError = true
    }

    if (handleListItemCheck(baseLocation, 'baseLocation')) {
        setAsErrored(baseLocation, 'baseLocation')
        hasError = true
    }

    if (handleListItemCheck(businessUnit, 'businessUnit')) {
        setAsErrored(businessUnit, 'businessUnit')
        hasError = true
    }
    if (handleListItemCheck(grade)) {
        this.setAsErrored(grade, 'grade')
        hasError = true
    }
    return hasError;
}