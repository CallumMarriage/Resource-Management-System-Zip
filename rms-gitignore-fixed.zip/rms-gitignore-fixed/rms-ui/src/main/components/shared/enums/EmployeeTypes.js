const employeeTypes = [
    {
        value: 'PLEASE_SELECT',
        label: 'Please Select'
    },
    {
        value: 'RESOURCE_MANAGER',
        label: 'Resource Manager'
    },
    {
        value: 'PROJECT_MANAGER',
        label: 'Project Manager'
    },
    {
        value: 'CANDIDATE',
        label: 'Candidate'
    }
]

export function getEmployeeTypes(){
    return employeeTypes;
}