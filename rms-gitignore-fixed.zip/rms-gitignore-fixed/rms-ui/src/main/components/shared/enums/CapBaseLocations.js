const CapBaseLocations = [
    {
        value: 'PLEASE_SELECT',
        label: 'Please select'
    },
    {
        value: 'HOLBORN',
        label: 'Holborn'
    },
    {
        value: 'ASTON',
        label: 'Aston'
    },
    {
        value: 'TREFOREST',
        label: 'Treforest'
    },
    {
        value: 'WOKING',
        label: 'Woking'
    },
    {
        value: 'SALE',
        label: 'Sale'
    },
    {
        value: 'TOLTEC',
        label: 'Toltec'
    },
    {
        value: 'GLASGOW',
        label: 'Glasgow'
    },
    {
        value: 'INVERNESS',
        label: 'Inverness'
    },
    {
        value: 'LIVERPOOL',
        label: 'Liverpool'
    },
    {
        value: 'CANARY_WHARF',
        label: 'Canary Wharf'
    },
    {
        value: 'SHEFFIELD',
        label: 'Sheffield'
    },
    {
        value: 'ROTHERHAM',
        label: 'Rotherham'
    },
    {
        value: 'NAIRN',
        label: 'Nairn'
    },
    {
        value: 'TELFORD',
        label: 'Telford'
    }
]

export function getCapBaseLocations() {
    return CapBaseLocations;
}
