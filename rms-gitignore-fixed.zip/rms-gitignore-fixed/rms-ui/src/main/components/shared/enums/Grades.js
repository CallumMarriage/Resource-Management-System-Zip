export default [
    {
        value: 'A10',
        label: 'A10'
    },
    {
        value: 'A9',
        label: 'A9'
    },
    {
        value: 'A8',
        label: 'A8'
    },
    {
        value: 'A7',
        label: 'A7'
    },
    {
        value: 'A6',
        label: 'A6'
    },
    {
        value: 'A5',
        label: 'A5'
    },
    {
        value: 'A4',
        label: 'A4'
    },
    {
        value: 'A3',
        label: 'A3'
    },
    {
        value: 'A2',
        label: 'A2'
    },
    {
        value: 'A1',
        label: 'A1'
    }
]