import {retrieveBusinessUnits} from "../../../services/candidate/businessUnitService";
import ListSelector from "./ListSelector";
import React from "react";
import Error from "../Error";
import CircularProgress from "@material-ui/core/CircularProgress";


class BusinessUntSelector extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            hasError: false,
            businessUnit: null,
            businessUnits: [],
        }
    }

    async componentDidMount() {
        const bus = await retrieveBusinessUnits();


        if (bus.hasError) {
            this.setState({
                loading: false,
                hasError: true
            })
        } else {
            const formattedBus = [{
                label: 'Please select',
                value: 'PLEASE_SELECT'
            }]
            const newBus = bus.businessUnitList.map((bu) => ({
                label: bu.name,
                value: bu.id
            }));

            const combined = formattedBus.concat(newBus);
            if(this.props.businessUnit === null
                || this.props.businessUnit === undefined
                || this.props.businessUnit.value == ""){
                this.props.updateBusinessUnit(combined[0].value);
                this.setState({
                    businessUnits: combined,
                    hasError: false,
                    loading: false
                });
            } else {
                const bu = combined.filter(bu => bu.value === this.props.businessUnit)

                this.props.updateBusinessUnit(bu[0].value);

                this.setState({
                    businessUnits: combined,
                    hasError: false,
                    loading: false
                });
            }
        }
    }

    render() {
        if (this.state.hasError) {
            return <Error/>
        }

        if (this.state.loading) {
            return <CircularProgress style={{marginTop: '20px'}}/>
        }

        return(
            <ListSelector list={this.state.businessUnits}
                          id={"businessUnit"}
                          label={"Business Unit"}
                          value={this.props.businessUnit}
                          onChange={this.props.handleChange}
                          text={"Please select your Business Unit"}/>
        )
    }

}

export default BusinessUntSelector;