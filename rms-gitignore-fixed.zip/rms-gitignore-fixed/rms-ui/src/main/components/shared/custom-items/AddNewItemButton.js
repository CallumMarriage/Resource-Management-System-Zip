import BuildIcon from "@material-ui/icons/Build";
import {Typography} from "@material-ui/core";
import React from "react";
import {AddNewButtonStyle} from "./SharedStyledItems";

export default function AddNewItemButton(props){
    return (
        <AddNewButtonStyle>
            <BuildIcon style={{marginRight: '10px'}}/>
            <Typography variant={"h6"}>
                {props.label}
            </Typography>
        </AddNewButtonStyle>
    )
}