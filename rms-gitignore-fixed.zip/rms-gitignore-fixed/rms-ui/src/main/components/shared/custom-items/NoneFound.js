import Paper from "@material-ui/core/Paper";
import {Typography} from "@material-ui/core";
import React from "react";

export default function NoneFound(props) {
    return (
        <Paper style={{
            padding: '0px',
            margin: 'auto',
            marginTop: '20px',
            width: '90%',
            paddingBottom: '20px',
            paddingTop: '20px',
            backgroundColor: 'white'
        }}>
            <Typography variant={"h6"} color={"primary"}>
                {props.title}
            </Typography>
        </Paper>
    )
}