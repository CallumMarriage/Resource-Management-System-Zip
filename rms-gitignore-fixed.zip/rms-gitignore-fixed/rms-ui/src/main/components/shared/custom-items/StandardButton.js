import {Button} from "@material-ui/core";
import withStyles from "@material-ui/core/styles/withStyles";

export default withStyles(theme => ({
    root: {
        backgroundColor: theme.palette.primary.main
    }
}))(Button)