import Grid from "@material-ui/core/Grid";
import InputLabel from "@material-ui/core/InputLabel";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import React from "react";

export default function ListSelector(props){
    return(
        <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
            <InputLabel htmlFor={props.id}>{props.label} *</InputLabel>
            <TextField
                id={props.id}
                select
                name={props.id}
                value={props.value.value}
                error={props.value.hasError}
                onChange={(e) => props.onChange(e)}
                helperText={props.text}
                variant="outlined"
                style={{width: '80%', padding: '10px'}}>
                {props.list.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                        {option.label}
                    </MenuItem>
                ))}
            </TextField>
        </Grid>
    )
}