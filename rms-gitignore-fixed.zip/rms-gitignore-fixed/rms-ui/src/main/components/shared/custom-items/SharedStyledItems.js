import {Button, withStyles} from "@material-ui/core";
import Paper from "@material-ui/core/Paper";

export const StyledPaper = withStyles({
    root: {
        marginBottom: '50px',
        width: '90%',
        paddingRight: '10%',
        paddingLeft: '10%',
        paddingBottom: '20px',
        paddingTop: '20px'

    }
})(Paper);

export const BackButton = withStyles((theme) => ({
    root: {
        backgroundColor: '#15626b',
        padding: '10px',
        float: 'left',
        margin: '10px',
        height: '30px'
    }
}))(Button);

export const AddNewButtonStyle = withStyles((theme) => ({
    root: {
        width: '50%',
        backgroundColor: theme.palette.success.dark,
        color: theme.palette.secondary.main,
        "&:hover": {
            backgroundColor: theme.palette.success.light,
            color: theme.palette.success.dark
        }
    }
}))(Button)

export const MapButtonStyle = withStyles((theme) => ({
    root: {
        width: '90%',
        backgroundColor: '#0f9a9c',
        margin: 'auto',
        marginTop: '10px',
        "&:hover": {
            backgroundColor: theme.palette.success.light,
            color: theme.palette.success.dark
        }
    }
}))(Button)

export const FormButton = withStyles((theme) => ({
    root: {
        width: '80%',
        height: '60px',
        color: 'white',
        backgroundColor: theme.palette.primary.main,
        position: 'relative',
        bottom: '0'
    }
}))(Button);


export const StyledButton = withStyles({
    root: {
        width: '100%',
        marginTop: '10px'
    }
})(Button)