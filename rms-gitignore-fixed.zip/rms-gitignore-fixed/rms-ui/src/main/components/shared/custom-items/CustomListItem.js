import ListItem from "@material-ui/core/ListItem";
import Grid from "@material-ui/core/Grid";
import {Typography} from "@material-ui/core";
import React from "react";

export default function CustomListItem(props) {
    return (
        <ListItem id={props.title}>
            <Grid item xs={6}>
                <Typography variant={'body1'} color={"primary"}>
                    {props.title}
                </Typography>
            </Grid>
            <Grid item xs={6}>
                <Typography variant={'body1'}>
                    {props.value}
                </Typography>
            </Grid>
        </ListItem>
    )
}