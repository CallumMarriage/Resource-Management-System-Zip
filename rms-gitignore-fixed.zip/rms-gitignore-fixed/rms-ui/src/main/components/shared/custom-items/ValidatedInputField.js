import TextField from "@material-ui/core/TextField";
import React from "react";

export default function ValidatedInputField(props) {
    return (
        <TextField id={props.id}
                   name={props.id}
                   error={props.value.hasError}
                   defaultValue={props.value.value}
                   onChange={(e) => props.handleChange(e)}
                   aria-describedby={props.describe}
                   helperText={props.value.hasError ? props.helper: ''}
                   style={{width: '80%', padding: '10px'}}
                   variant="outlined"
        />
    )
}