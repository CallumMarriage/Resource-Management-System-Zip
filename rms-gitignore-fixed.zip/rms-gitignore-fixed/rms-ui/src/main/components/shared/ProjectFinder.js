import {retrieveAccountInfo} from "../../services/api/accountService";
import {retrieveProjectInfo} from "../../services/api/projectService";
import Grid from "@material-ui/core/Grid";
import InputLabel from "@material-ui/core/InputLabel";
import TextField from "@material-ui/core/TextField";
import ListSelector from "./custom-items/ListSelector";
import React from "react";
import CircularProgress from "@material-ui/core/CircularProgress";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";
import ErrorIcon from "@material-ui/icons/Error";

class ProjectFinder extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            potentialRoles: [],
            potentialProjects: [],
            accountCorrect: false,
            currentRole: null,
            currentProject: '',
            currentAccount: '',
            loadingAccountVerification: false,
            hasError: false,
            completed: false,
        }

        this.handleAccountChange = this.handleAccountChange.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }


    async handleAccountChange(event) {
        const accountNumber = event.target.value;

        this.setState({
            accountNumber: accountNumber
        })


        if (accountNumber == null || accountNumber === "" || accountNumber.length < 10) {
            this.setState({
                accountCorrect: false,
                loadingAccountVerification: false,
                potentialRoles: [],
                completed: false
            })
        } else {

            this.setState({
                loadingAccountVerification: true,
                completed: true
            })

            const res = await retrieveAccountInfo(accountNumber);

            let doesExist = false;

            if (res.hasError) {
                doesExist = false
            }
            if (res.account !== undefined) {
                doesExist = true
            }

            if (!doesExist) {
                this.setState({
                    loadingAccountVerification: false,
                    accountCorrect: false,
                })
            } else {

                let potentialProjects = [];

                res.projectList.forEach(project => {
                    let projectInfo = {
                        label: project.projectName,
                        id: project.projectCode,
                        value: project
                    }
                    potentialProjects.push(projectInfo)
                })

                this.setState({
                    loadingAccountVerification: false,
                    accountCorrect: true,
                    accountName: res.account.accountName,
                    potentialProjects: potentialProjects,
                    currentProject: potentialProjects[0]
                })
            }
        }
    }

    async setProject(event) {

        const project = event.target.value;

        const projectInfo = await retrieveProjectInfo(project.projectCode);

        if (projectInfo.hasError) {
            alert('issue');
            return;
        }

        let potentialRoles = [];

        projectInfo.roleList.forEach(role => {
            let roleInfo = {
                label: role.roleName,
                id: role.id,
                value: role
            }
            potentialRoles.push(roleInfo)
        })

        this.setState({
            currentProject: event.target.value,
            potentialRoles: potentialRoles,
            currentRole: potentialRoles[0]
        })
    }

    renderProjectList() {
        if (this.state.potentialProjects.length === 0 || this.state.accountCorrect === false) {
            return null;
        } else {
            return (
                <ListSelector list={this.state.potentialProjects}
                              id={"currentProject"}
                              label={"Current Project"}
                              value={this.state.currentProject}
                              onChange={this.setProject.bind(this)}
                              text={"Please select from the list your project"}/>
            )
        }
    }

    renderRoleList() {
        let currentRole = this.props.currentRole;
        if(currentRole === null){
            currentRole = ''
        }
        if (this.state.potentialRoles.length === 0 || this.state.accountCorrect === false) {
            return null;
        } else {
            return (
                <ListSelector list={this.state.potentialRoles}
                              id={"currentRole"}
                              label={"Current Role"}
                              value={currentRole}
                              onChange={this.props.handleChange}
                              text={"Please select from the list the role you have"}/>
            )
        }
    }


    renderAccountVerified(loading, verified, completed) {

        if (loading) {
            return (
                <CircularProgress style={{marginTop: '20px'}}/>
            )
        }

        if (completed) {
            if (verified) {
                return (
                    <CheckCircleIcon style={{width: '50px', height: '50px', color: "green"}}/>
                )
            } else {
                return (
                    <ErrorIcon style={{margin: 'auto', color: "red", height: '100%', width: '50px'}}/>
                )
            }
        }

        return (
            <div/>
        )
    }

    render() {
        return (
            <Grid container>
                <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
                    <InputLabel htmlFor="accountNumber">Account Number</InputLabel>
                    <TextField id="accountNumber"
                               aria-describedby="What account are you on?"
                               variant="outlined"
                               onChange={this.handleAccountChange.bind(this)}
                               style={{width: '60%', padding: '10px'}}
                    />
                    {
                        this.renderAccountVerified(
                            this.state.loadingAccountVerification,
                            this.state.accountCorrect,
                            this.state.completed)}
                </Grid>
                {this.renderProjectList()}
                {this.renderRoleList()}

            </Grid>
        )

    }
}

export default ProjectFinder;