import {Typography, withStyles} from "@material-ui/core";
import Grid from "@material-ui/core/Grid";
import React from "react";
import Paper from "@material-ui/core/Paper";
import {ProjectLink} from "../../../shared/utils/Links";
import {Link} from "react-router-dom";
import StandardButton from "../../../shared/custom-items/StandardButton";

export default function MyProjectTile(props){
    const project = props.project;
    project.accountName = props.accountName;
    return (
        <ProjectPaper>
            <Typography variant={"h6"}>
                {props.project.projectName}
            </Typography>
            <Typography variant={"body1"}>
                Start Date {props.project.startDate}
            </Typography>
            <Typography variant={"body1"}>
                End Date {props.project.endDate}
            </Typography>
            <Grid container>
                <Grid item xs={12} md={6}>
                    {
                        <Link style={{textDecoration: 'none'}} to={{
                            pathname: `/ProjectManagement/UpdateProject`,
                            state: {project: project}
                        }}>
                            <UpdateProjectButton/>
                        </Link>
                    }
                </Grid>
                <Grid item xs={12} md={6}>
                    {ProjectLink(props.project, ViewProjectButton)}
                </Grid>
            </Grid>
        </ProjectPaper>
    )
}

function ViewProjectButton(props){
    return (
        <ProjectButtonStyle>
            View
        </ProjectButtonStyle>
    )
}

function UpdateProjectButton(props){
    return(
        <ProjectButtonStyle>
            Update
        </ProjectButtonStyle>
    )
}

const ProjectButtonStyle = withStyles({
    root: {
        width: '80%',
        height: '60px',
        marginTop: '10%',
        fontSize: '1em'
    }
})(StandardButton)


const ProjectPaper = withStyles({
    root: {
        width: '100%',
        height: '100%',
        margin: '0px',
        padding: '10px',
    }
})(Paper)
