import Grid from "@material-ui/core/Grid";
import {AddNewProjectLink} from "../../../shared/utils/Links";
import React from "react";
import {withStyles} from "@material-ui/core";
import Paper from "@material-ui/core/Paper";
import MyProjectTile from "./MyProjectTile";
import AddNewItemButton from "../../../shared/custom-items/AddNewItemButton";

export default function MyProjectContainer(props) {
    return (
        <ProjectsPaper>
            <Grid container spacing={5}>
                {props.account.projects.map((project) => {
                    return (
                        <Grid item xs={6} md={3} key={project.projectCode}>
                            <MyProjectTile project={project}
                                           accountName={props.account.targetAccount.accountName}/>
                        </Grid>
                    )
                })}
                <Grid item xs={6} md={6}>
                    {AddNewProjectLink({
                            accountNumber: props.account.targetAccount.accountCode},
                        AddNewProject)}
                </Grid>
            </Grid>
        </ProjectsPaper>
    )
}

const ProjectsPaper = withStyles((theme) => ({
    root: {
        height: 'fit-content',
        padding: '40px',
        backgroundColor: theme.palette.secondary.dark
    }
}))(Paper)

function AddNewProject() {
    return (
        <AddNewItemButton label={'Add a new Project'}/>
    )
}
