import Grid from "@material-ui/core/Grid";
import {Typography, withStyles} from "@material-ui/core";
import Paper from "@material-ui/core/Paper";
import React from "react";
import {retrieveAccountsAndProjectsForPm} from "../../../services/api/projectService";
import CircularProgress from "@material-ui/core/CircularProgress";
import Error from "../../shared/Error";
import MyProjectsContainer from "./projects/MyProjectsContainer";
import NoneFound from "../../shared/custom-items/NoneFound";

class MyAccounts extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            myAccounts: [],
            hasError: false,
            loading: true
        }
    }

    async componentDidMount() {
        let userId = this.props.userId;

        if (userId === null) {
            return;
        }

        const myAccounts = await retrieveAccountsAndProjectsForPm(userId);


        if (myAccounts.hasError) {
            this.setState({
                hasError: true,
                loading: false
            })
            return;
        }

        this.setState({
            myAccounts: myAccounts.accountAndProjectsList,
            loading: false,
            hasError: false
        })

    }

    render() {
        const myAccounts = this.state.myAccounts;


        if (this.state.loading) {
            return (
                <CircularProgress style={{marginTop: '20px'}}/>
            )
        } else if (this.state.hasError) {
            return (
                <Error/>
            )
        } else if (myAccounts.length === 0) {
            return (
                <NoneFound title={"You have no accounts"}/>
            )
        }

        return (
            <Grid container>
                <Grid item xs={12}>
                    <div>
                        <Grid container>
                            {
                                myAccounts.map((account) => {
                                    return (
                                        <Grid item xs={12} key={account.targetAccount.accountCode}>
                                            <Grid container>
                                                <Grid item xs={12}>
                                                    <AccountTile account={account.targetAccount}/>
                                                </Grid>
                                                <Grid item xs={12}>
                                                    <MyProjectsContainer account={account}/>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                    )
                                })
                            }
                        </Grid>
                    </div>
                </Grid>
            </Grid>
        );
    }
}

export default MyAccounts;


function AccountTile(account) {

    return (
        <AccountPaper style={{marginTop: '20px'}}>
            <Typography variant={"h6"}>
                {account.account.accountName}
            </Typography>
        </AccountPaper>
    )
}


const AccountPaper = withStyles({
    root: {
        width: '50%',
        margin: 'auto',
        background: '#027bb6',
        color: 'white',
        marginLeft: 0,
        borderRadius: 0,
        borderTopRightRadius: '30px'
    }
})(Paper)

