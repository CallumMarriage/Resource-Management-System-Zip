import React from "react";
import Grid from "@material-ui/core/Grid";
import TitleContainer from "../header/TitleContainer";
import Paper from "@material-ui/core/Paper";
import {Typography} from "@material-ui/core";
import {Link} from "react-router-dom";
import {connect} from "react-redux";
import MyAccounts from "./my-accounts/MyAccounts";
import AddNewItemButton from "../shared/custom-items/AddNewItemButton";

class ProjectManagerSpace extends React.Component {

    render() {
        return (
            <Grid container>
                <TitleContainer title={'Project and Account Management'}/>
                <Grid item xs={6}>
                    <Paper style={{width: '96%', margin: 'auto', padding: '4%'}}>
                        <Typography variant={"h6"} color={"primary"}>
                            Your Project Management Space
                        </Typography>
                        <Typography variant={"body1"}>
                            This space contains all of the projects that you are project manager for
                            as well as the projects for the accounts that you are account manager for.
                        </Typography>
                    </Paper>
                </Grid>
                <Grid item xs={6} style={{margin: 'auto'}}>
                    <Link to={{
                        pathname: `/ProjectManagement/AddNewAccount`,
                        state: {userId: this.props.userId}
                    }} style={{textDecoration: 'none'}}>
                        <AddNewItemButton label={'Add a new Account'}/>
                    </Link>
                </Grid>
                <Grid item xs={12}>
                    <MyAccounts userId={this.props.userId}/>
                </Grid>
            </Grid>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id,
    };
}

export default connect(mapStateToProps)(ProjectManagerSpace);