import {GoogleMap, InfoWindow, Marker, withGoogleMap, withScriptjs} from "react-google-maps"
import React from "react";

export const MyMapComponent = withScriptjs(withGoogleMap((props) =>
    <GoogleMap
        defaultZoom={8}
        defaultCenter={{lat: props.baseLocationX, lng: props.baseLocationY}}
    >
        <Marker key={"yourBase"}
                position={{lat: props.baseLocationX, lng: props.baseLocationY}}
        >
            <InfoWindow>
                <div>
                    Your base
                </div>
            </InfoWindow>
        </Marker>
        {
            props.roles.map((role) => {
                return (
                    <div key={role.id}>
                        <Marker key={role.id}
                                position={{lat: role.baseLocationX, lng: role.baseLocationY}}
                                onClick={() => props.onMarkerClick(role)}>
                            <InfoWindow options= {{maxWidth : 100}}>
                                <div>
                                    <p>
                                        {role.accountName}
                                    </p>
                                    {role.roleName}
                                </div>
                            </InfoWindow>
                        </Marker>
                    </div>
                )
            })
        }
    </GoogleMap>
))
