import Typography from "@material-ui/core/Typography";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import {getRoleTypes} from "../shared/enums/RoleTypes";
import React from "react";
import withStyles from "@material-ui/core/styles/withStyles";
import Paper from "@material-ui/core/Paper";
import {findRolesWithFilters} from "../../services/api/roleService";
import getDistance from 'geolib/es/getDistance';
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import MyDatePicker from "../shared/utils/MyDatePicker";
import StandardButton from "../shared/custom-items/StandardButton";

const StyledPaper = withStyles({
    root: {
        marginBottom: '20px'
    }
})(Paper);

class Filter extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            roleType: getRoleTypes()[0].value,
            accountName: '',
            projectName: '',
            distance: '',
            startDate: new Date(),
            endDate: new Date("01/01/2030")
        }
        this.filter = this.filter.bind(this);
        this.resetFilter = this.resetFilter.bind(this);

    }

    handleChange(event) {
        this.setState({
            [event.target.name]: event.target.value
        })
    }

    handleStartDateChange = (date) => {
        this.setState({
            startDate: date
        })
    }

    handleEndDateChange = (date) => {
        this.setState({
            endDate: date
        })
    }

    resetFilter(){
        this.setState({
            roleType: getRoleTypes()[0].value,
            accountName: '',
            projectName: '',
            distance: '',
            startDate: new Date(),
            endDate: new Date("01/01/2030")
        })
        this.props.resetFilter();
    }

    async filter() {
        let filters = []

        this.props.setAsFiltering();

        if (this.state.roleType !== '' && this.state.roleType !== 'PLEASE_SELECT') {
            filters.push(`roleType=${this.state.roleType}`)
        }

        if (this.state.accountName !== '') {
            filters.push(`accountName=${this.state.accountName}`)
        }

        if (this.state.projectName !== '') {
            filters.push(`projectName=${this.state.projectName}`)
        }

        if(this.state.startDate !== null){
            filters.push(`startDate=${new Date(this.state.startDate).toLocaleDateString()}`)
        }

        if(this.state.endDate !== null){
            filters.push(`endDate=${new Date(this.state.endDate).toLocaleDateString()}`)
        }


        let response = await findRolesWithFilters(filters);

        if (response.hasError) {
            alert('error running filter')
            this.props.setAsErrored();
        } else {
            if(this.state.distance !== 0 && this.state.distance !== ''){
                response = response.filter(role =>
                    getDistance(
                        { latitude: role.baseLocationX, longitude: role.baseLocationY },
                        { latitude: this.props.baseLocationX, longitude: this.props.baseLocationY }
                    ) < (this.state.distance * 1000)
                )
            }
            this.props.setFilteredPotentialRoles(response);
        }
    }

    render() {
        return (
            <StyledPaper style={{width: '90%'}}>
                <Typography variant={"h6"} color={"primary"} style={{padding: '30px'}}>
                    Use these filters to refine your search
                </Typography>
                <Grid container spacing={1}>
                    <Grid item xs={12}>
                        <TextField style={{
                            width: '90%',
                            height: '5%'
                        }}
                                   id="outlined-search-pr"
                                   label={"Search By Project"}
                                   name={"projectName"}
                                   value={this.state.projectName}
                                   type="search"
                                   variant="outlined"
                                   onChange={this.handleChange.bind(this)}
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField style={{
                            width: '90%',
                            height: '20%'
                        }}
                                   id="outlined-search-acc"
                                   label="Search By Account"
                                   name={"accountName"}
                                   value={this.state.accountName}
                                   type="search"
                                   variant="outlined"
                                   onChange={this.handleChange.bind(this)}
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField
                            id="roleType"
                            name={"roleType"}
                            select
                            value={this.state.roleType}
                            inputProps={{style: {textAlign: 'center'}}}
                            onChange={this.handleChange.bind(this)}
                            helperText="Search by role type"
                            variant="outlined"
                            style={{width: '90%', padding: '10px'}}>
                            {getRoleTypes().map((option) => (
                                <MenuItem id={option.value}
                                          name={"roleType"}
                                          key={option.value}
                                          value={option.value}>
                                    {option.label}
                                </MenuItem>
                            ))}
                        </TextField>
                    </Grid>
                    <Grid item xs={12}>
                        <TextField style={{
                            width: '90%',
                            height: '20%'
                        }}
                                   id="outlined-search-dist"
                                   label="Search By Distance km"
                                   name={"distance"}
                                   value={this.state.distance}
                                   type="search"
                                   variant="outlined"
                                   onChange={this.handleChange.bind(this)}
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <InputLabel htmlFor="startDate">Start Date</InputLabel>
                        <MyDatePicker id={"startDate"}
                                      date={this.state.startDate}
                                      handleChange={this.handleStartDateChange}/>
                    </Grid>
                    <Grid item xs={12}>
                        <InputLabel htmlFor="endDate">End Date</InputLabel>
                        <MyDatePicker id={"endDate"}
                                      date={this.state.endDate}
                                      handleChange={this.handleEndDateChange}/>
                    </Grid>
                    <Grid item xs={6}>
                        <StandardButton style={{width: '80%',margin: 'auto', backgroundColor: '#15596B'}}
                                        onClick={this.resetFilter}>
                            Reset
                        </StandardButton>
                    </Grid>
                    <Grid item xs={6}>
                        <StandardButton style={{width: '80%', margin: 'auto', backgroundColor: '#12ABDB'}}
                            onClick={this.filter}>
                            Search
                        </StandardButton>
                    </Grid>
                </Grid>
            </StyledPaper>
        )
    }
}

const StyledButton = withStyles({
    root: {
        width: '80%'
    }
})(StandardButton)

export default Filter;