import Role from "./Role";
import React from "react";
import NoneFound from "../shared/custom-items/NoneFound";

export default function RolesContainer(props) {
    if (props.potentialRoles.length === 0) {
        return (
            <NoneFound title={"There are no roles available matching your search"}/>

        )
    }
    return (
        <div>
            {props.potentialRoles.map(role => {
                return (
                    <div key={role.id}>
                        <Role projectName={role.projectName}
                              projectCode={role.projectCode}
                              accountName={role.accountName}
                              description={role.description}
                              accountNumber={role.accountNumber}
                              baseLocationX={role.baseLocationX}
                              baseLocationY={role.baseLocationY}
                              grade={role.grade}
                              baseLocation={role.baseLocation}
                              roleName={role.roleName}
                              startDate={role.startDate}
                              endDate={role.endDate}
                              isRoleOpen={role.isRoleOpen}
                              certainty={role.certainty}
                              key={role.id}
                              roleType={role.roleType}
                              id={role.id}
                        />
                    </div>
                )
            })}
        </div>
    )
}