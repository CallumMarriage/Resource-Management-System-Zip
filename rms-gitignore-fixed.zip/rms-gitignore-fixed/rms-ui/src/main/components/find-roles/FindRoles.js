import React from "react";
import {connect} from "react-redux";
import CircularProgress from "@material-ui/core/CircularProgress";
import Grid from "@material-ui/core/Grid";

import RolesContainer from "./RolesContainer";
import TitleContainer from "../header/TitleContainer";
import {retrievePotentialRoles} from "../../services/api/roleService";
import Error from "../shared/Error";
import Filter from "./Filter";
import {withStyles} from "@material-ui/core";
import Paper from "@material-ui/core/Paper";
import {Link} from "react-router-dom";
import {MapButtonStyle} from "../shared/custom-items/SharedStyledItems";


class FindRoles extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            potentialRoles: [],
            filterActive: false,
            filteredPotentialRoles: null,
            loading: true,
            hasError: false
        };
    }

    setAsFiltering() {
        this.setState({
            searching: true,
            loading: true,
            filterActive: true,
            filteredPotentialRoles: []
        })
    }

    resetFilter() {
        this.setState({
            filterActive: false,
            hasError: false,
            loading: false,
            filteredPotentialRoles: null
        })
    }

    setAsErrored() {
        this.setState({
            filterActive: false,
            hasError: true,
            loading: false,
            filteredPotentialRoles: null
        })
    }

    setFilteredPotentialRoles(roles) {
        this.setState({
            filteredPotentialRoles: roles,
            loading: false,
            hasError: false,
            filterActive: true
        })
    }

    async componentDidMount() {
        const res = await retrievePotentialRoles();
        this.saveResponse(res);
    }

    saveResponse(res) {

        if (res == null) {
            this.setState({
                loading: false,
                hasError: false
            })
        } else if (res.hasError) {
            this.setState({
                hasError: true,
                loading: false,
                error: res.error
            })
        } else {
            this.setState({
                potentialRoles: res,
                loading: false,
                hasError: false,
                searching: false
            })
        }
    }

    render() {

        let potentialRoles = this.state.potentialRoles;

        if (this.state.filterActive) {
            potentialRoles = this.state.filteredPotentialRoles;
        }

        const userId = this.props.userId;

        return (
            <Grid container>
                <TitleContainer title={'Find new roles'}/>

                <Grid item xs={12} md={4}>
                    <Filter setFilteredPotentialRoles={this.setFilteredPotentialRoles.bind(this)}
                            setAsErrored={this.setAsErrored.bind(this)}
                            setAsFiltering={this.setAsFiltering.bind(this)}
                            resetFilter={this.resetFilter.bind(this)}
                            baseLocationX={this.props.baseLocationX}
                            baseLocationY={this.props.baseLocationY}
                    />
                </Grid>
                <Grid item md={8} xs={12}>
                    <RolesContainerPaper>
                        <Link style={{textDecoration: 'none'}} to={{
                            pathname: `/Applications/FindRoles/RoleMap`,
                            state: {
                                roles: potentialRoles,
                                baseLocationX: this.props.baseLocationX,
                                baseLocationY: this.props.baseLocationY
                            }
                        }}>
                            <MapButtonStyle>
                                View roles on the map
                            </MapButtonStyle>
                        </Link>
                        {loadPotentialRolesBox(this.state.loading,
                            this.state.hasError, potentialRoles, userId)}

                    </RolesContainerPaper>
                </Grid>
            </Grid>
        );
    }
}


function loadPotentialRolesBox(loading, hasError, potentialRoles) {

    if (loading) {
        return (
            <CircularProgress/>
        )
    }

    if (hasError) {
        return (
            <Error/>
        )
    }

    return (
        <RolesContainer potentialRoles={potentialRoles}/>
    )

}

const RolesContainerPaper = withStyles((theme) => ({
            root: {
                backgroundColor: theme.palette.secondary.dark,
                height: '800px',
                overflowY: 'auto'
            }
        }
    )
)(Paper)

const mapStateToProps = (state) => {
    return {
        userId: state.user.user.userId,
        baseLocationX: state.user.user.baseLocationX,
        baseLocationY: state.user.user.baseLocationY
    };
}

export default connect(mapStateToProps)(FindRoles);