import {MyMapComponent} from "./MapComponent";
import React from "react";
import {Redirect} from "react-router-dom";
import TitleContainer from "../header/TitleContainer";
import Grid from "@material-ui/core/Grid";
import {Typography} from "@material-ui/core";
import Paper from "@material-ui/core/Paper";
import Filter from "./Filter";
import Error from "../shared/Error";
import CircularProgress from "@material-ui/core/CircularProgress";
import {BackButton} from "../shared/custom-items/SharedStyledItems";

class MapWrapper extends React.PureComponent {
    state = {
        isMarkerShown: false,
        targetRole: null,
        filteredPotentialRoles: [],
        loading: false,
        hasError: false,
        filterActive: false
    }

    handleMarkerClick = (role) => {
        this.setState({
            targetRole: role
        })
    }

    setFilteredPotentialRoles = (roles) => {
        this.setState({
            filteredPotentialRoles: roles,
            loading: false,
            hasError: false,
            filterActive: true
        })
    }

    setAsFiltering = () => {
        this.setState({
            searching: true,
            loading: true,
            filterActive: true,
            filteredPotentialRoles: []
        })
    }

    resetFilter = () => {

        this.setState({
            filterActive: false,
            hasError: false,
            loading: false,
            filteredPotentialRoles: null
        })
    }

    setAsErrored = () => {
        this.setState({
            filterActive: false,
            hasError: true,
            loading: false,
            filteredPotentialRoles: null
        })
    }


    render() {
        const targetRole = this.state.targetRole;
        if(targetRole !== null) {
            return (
                <Redirect style={{textDecoration: 'none'}} to={{
                    pathname: `/SearchAccounts/Account/${targetRole.accountNumber}/Project/${targetRole.projectCode}/ViewRole/${targetRole.id}`,
                    state: {role: targetRole}
                }}/>
            )
        }

        let roles = [];

        if(this.state.filterActive){
            roles = this.state.filteredPotentialRoles
        } else {
            roles = this.props.location.state.roles;
        }

        return (
            <Grid container>
                <TitleContainer title={"Role Map"}/>
                <Grid item xs={12}>
                    <BackButton onClick={this.props.history.goBack}>
                        Back
                    </BackButton>
                </Grid>
                <Grid item xs={12} md={4}>
                    <Paper style={{width: '80%',
                        height: '100px',
                        padding: '5%',
                        marginBottom: '10px'}}>
                        <Typography variant={"body1"}>
                            The role map shows where currently available roles are.
                            Each location is based on the closest Capgemini Office to the role.
                            You can click on each role to see more information.
                        </Typography>
                    </Paper>
                    <Filter setFilteredPotentialRoles={this.setFilteredPotentialRoles.bind(this)}
                            setAsErrored={this.setAsErrored.bind(this)}
                            setAsFiltering={this.setAsFiltering.bind(this)}
                            resetFilter={this.resetFilter.bind(this)}
                            baseLocationX={this.props.location.state.baseLocationX}
                            baseLocationY={this.props.location.state.baseLocationY}/>
                </Grid>
                <Grid item xs={12} md={8}>
                    {this.renderMap(roles)}
                </Grid>
            </Grid>
        )
    }

    renderMap = (roles) => {
        if(this.state.hasError){
            return <Error/>
        }

        if(this.state.loading){
            return <CircularProgress style={{marginTop: '20px'}}/>
        }

        return(
            <MyMapComponent
                isMarkerShown={this.state.isMarkerShown}
                roles={roles}
                baseLocationX={this.props.location.state.baseLocationX}
                baseLocationY={this.props.location.state.baseLocationY}
                onMarkerClick={this.handleMarkerClick}
                googleMapURL="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyCth6gDE10kODR-o409hLVwNMHqRdkyJPg&libraries=geometry,drawing,place"
                loadingElement={<div style={{height: `100%`}}/>}
                containerElement={<div style={{height: `100%`, width: '100%', margin: 'auto'}}/>}
                mapElement={<div style={{height: `100%`}}/>}
            />
        )
    }
}



export default MapWrapper;