import React from "react";

import Paper from "@material-ui/core/Paper";
import {createMuiTheme, Typography} from "@material-ui/core";
import Grid from "@material-ui/core/Grid";
import withStyles from "@material-ui/core/styles/withStyles";

import {ThemeProvider} from "styled-components";

import AccountImage from "../sub-pages/account/AccountImage";
import {AccountLink, ProjectLink, RoleLink} from "../shared/utils/Links";
import StandardButton from "../shared/custom-items/StandardButton";

const theme = createMuiTheme({
    typography: {
        h5: {
            fontSize: 12,
        },
        body1: {
            fontWeight: 500,
        },
    },
});

const StyledButton = withStyles((theme) => ({
    root: {
        width: '100%',
        backgroundColor: theme.palette.secondary.main,
        color: theme.palette.primary.main,
        textTransform: 'none',
        borderRadius: '0',
        maxHeight: 'fit-content',
        "&:hover": {
            backgroundColor: theme.palette.secondary.dark
        }
    }
}))(StandardButton);

const WhiteTypo = withStyles({
    root: {
        display: "initial",
        textTransform: 'none'
    }
})(Typography)


export default function Role(props) {
    return (
        <Paper style={
            {
                margin: 'auto',
                marginTop: '20px',
                height: 'fit-content',
                marginBottom: '20px',
                padding: '20px',
                width: '90%'
            }
        }>
            <ThemeProvider theme={theme}>
                <Grid container style={{height: 'match-parent'}}>
                    <Grid item xs={4} md={4} style={{height: 'match-parent'}}>
                        <div style={{width: '80%', margin: 'auto'}}>
                            <AccountImage accountNumber={props.accountNumber}/>
                        </div>

                        <Grid item xs={12}>
                            {AccountLink({
                                accountNumber: props.accountNumber,
                                accountName: props.accountName
                            }, AccountButton)}
                        </Grid>

                        <Grid item xs={12}>
                            {
                                ProjectLink({
                                        projectCode: props.projectCode,
                                        projectName: props.projectName,
                                        accountName: props.accountName,
                                        accountNumber: props.accountNumber
                                    },
                                    ProjectButton
                                )
                            }
                        </Grid>
                    </Grid>

                    <Grid item xs={8} style={{height: 'match-parent'}}>
                        {RoleLink(props, RoleButtonContent)}
                    </Grid>
                </Grid>
            </ThemeProvider>
        </Paper>
    )
}

function ProjectButton(props) {
    return (
        <StyledButton>
            <WhiteTypo variant="h6">
                {props.props.projectName}
            </WhiteTypo>
        </StyledButton>
    )
}


function AccountButton(props) {
    return (
        <StyledButton>
            <Typography variant={"h6"}>
                {props.props.accountName}
            </Typography>
        </StyledButton>
    )
}

const OrangeTypo = withStyles((theme) => ({
    root: {
        color: theme.palette.error.light,
        float: "right"
    }
}))(Typography);

const LightTypo = withStyles((theme) => ({
    root: {
        color: theme.palette.primary.light,
        float: "right"
    }
}))(Typography)

function RenderCertainty(props) {

    if(props.certainty < 30){
        return (
            <Typography variant={"h5"}
                        style={{float: 'right'}}
                        color={"error"}>
                Certainty {props.certainty}%
            </Typography>
        )
    } else if (props.certainty < 60){
        return (
            <OrangeTypo variant={"h5"}>
                Certainty {props.certainty}%
            </OrangeTypo>
        )
    } else if (props.certainty < 80){
        return (
            <LightTypo variant={"h5"}>
                Certainty {props.certainty}%
            </LightTypo>
        )
    } else {
        return (
            <Typography variant={"h5"}
                        style={{float: 'right'}}
                        color={"primary"}>
                Certainty {props.certainty}%
            </Typography>
        )
    }
}

function RoleButtonContent(props) {
    return (
        <StyledButton>

            <Grid container>
                <Grid item xs={12}>
                    <Typography variant="h5" color={"Primary"} style={{float: 'left'}}>
                        Grade  {props.props.grade}
                    </Typography>
                    <RenderCertainty certainty={props.props.certainty}/>

                </Grid>
                <Grid item xs={12} style={{borderTop: '1px solid lightgrey', padding: '30px', marginTop: '10px'}}>
                    <Grid container spacing={1}>
                        <Grid item xs={12}>
                            <Typography variant="h5" color={"textPrimary"}>
                                {props.props.roleName}
                            </Typography>
                        </Grid>
                        <Grid item xs={3}>
                            <Typography variant={"h6"} color={"textPrimary"}>
                                Start Date
                            </Typography>
                        </Grid>
                        <Grid item xs={3}>
                            <Typography variant="h6" color={"primary"}>
                                {props.props.startDate}
                            </Typography>
                        </Grid>
                        <Grid item xs={3}>
                            <Typography variant={"h6"} color={"textPrimary"}>
                                End Date
                            </Typography>
                        </Grid>
                        <Grid item xs={3}>
                            <Typography variant="h6" color={"primary"}>
                                {props.props.endDate}
                            </Typography>
                        </Grid>
                        <Grid item xs={12}>
                            <Typography variant={"subtitle1"} color={"textPrimary"}>
                                {props.props.description.substr(0, 100) + "..."}
                            </Typography>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </StyledButton>
    )
}