import Grid from "@material-ui/core/Grid";
import TitleContainer from "../../header/TitleContainer";
import React from "react";
import Paper from "@material-ui/core/Paper";
import {Typography, withStyles} from "@material-ui/core";
import {retrieveRoleHistory} from "../../../services/api/roleHistoryService";
import CircularProgress from "@material-ui/core/CircularProgress";
import {RoleLink} from "../../shared/utils/Links";
import {BackButton} from "../../shared/custom-items/SharedStyledItems";
import {retrieveUserById} from "../../../services/candidate/candidateService";
import Error from "../../shared/Error";

class Candidate extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            roleHistory: [],
            hasError: false,
            loading: true,
        }
    }

    async componentDidMount() {

        const candidateInfo = await retrieveUserById(this.props.location.state.candidateId);

        const res = await retrieveRoleHistory(this.props.location.state.candidateId);

        if (res.hasError || candidateInfo.hasError) {
            this.setState({
                hasError: true,
                loading: false
            })
        } else {
            this.setState({
                roleHistory: res.roleList,
                loading: false,
                hasError: false,
                candidate: candidateInfo
            })
        }
    }

    render() {
        if (this.state.hasError) {
            return <Error/>
        }

        if (this.state.loading) {
            return <CircularProgress/>
        }

        return (
            <Grid container>
                <TitleContainer title={this.state.candidate.fullName}/>
                <Grid item xs={12}>
                    <BackButton onClick={this.props.history.goBack}>
                        Back
                    </BackButton>
                </Grid>
                <Grid item xs={6}>
                    <Paper style={{padding: '20px', width: '90%', margin: 'auto'}}>
                        <Typography variant={"h6"}>
                            This candidate is a {this.state.candidate.userSpecialism}
                        </Typography>
                    </Paper>
                </Grid>

                <Grid item xs={6}>

                    <Paper style={{padding: '20px', width: '90%', margin: 'auto'}}>
                        <Typography variant={"h6"}>
                            Role History
                        </Typography>
                        {
                            RenderRoleHistory(this.state.loading,
                                this.state.hasError,
                                this.state.roleHistory, this.state.candidate.currentRoleId)
                        }
                    </Paper>
                </Grid>

            </Grid>
        )
    }
}

function RenderRoleHistory(loading, hasError, roleHistory, currentRoleId) {
    if (loading) {
        return (
            <CircularProgress style={{marginTop: '20px'}}/>
        )
    } else if (hasError) {
        return (
            <Typography variant={"subtitle1"}>
                Oops, something has gone wrong retrieving the role history for this user.
            </Typography>
        )
    } else if (roleHistory.length === 0) {
        return (
            <Typography variant={"subtitle1"}>
                No roles for this user
            </Typography>
        )
    }

    return (
        <Paper>
            <Grid container>
                {
                    roleHistory.map((role) => {
                        role.currentRoleId = currentRoleId
                        return (
                            <Grid item xs={12} key={role.id}>
                                <Grid container>
                                    <Grid item xs={12}>
                                        {
                                            RoleLink(role, RenderRole)
                                        }
                                    </Grid>
                                </Grid>
                            </Grid>
                        )
                    })
                }
            </Grid>
        </Paper>
    )

}

const StyledRolePaper = withStyles((theme) => ({
    root: {
        backgroundColor: theme.palette.primary.light,
        color: theme.palette.secondary.main,
        margin: '10px',
        padding: '20px'
    }
}))(Paper);

function RenderRole(props) {
    const role = props.props
    return (
        <StyledRolePaper>
            <Grid container>
                <Grid item xs={12}>
                    <Typography variant={"body1"}>
                        {role.roleName} at {role.accountName}
                    </Typography>
                </Grid>
                <Grid item xs={12}>
                    {
                        RenderTitle(role, role.currentRoleId)
                    }
                </Grid>
            </Grid>
        </StyledRolePaper>
    )
}

function RenderTitle(role, currentRoleId) {
    if (role.id === currentRoleId) {
        return (
            <Typography variant={"body2"}>
                This is the candidate's current role.
            </Typography>
        )
    } else {
        return (
            <Typography variant={"body2"}>
                From {role.startDate} until {role.endDate}
            </Typography>
        )
    }
}

export default Candidate;