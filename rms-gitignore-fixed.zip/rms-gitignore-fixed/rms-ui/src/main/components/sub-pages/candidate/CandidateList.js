import React from "react";
import Grid from "@material-ui/core/Grid";
import CandidateItem from "./CandidateItem";
import NoneFound from "../../shared/custom-items/NoneFound";

class CandidateList extends React.Component {

    constructor(props) {
        super(props);

        this.state = {}
    }

    render() {
        if(this.props.candidates.length === 0){
            return <NoneFound title={"No candidates found matching the provided name"}/>
        }
        return (
            <Grid container>
                {

                    this.props.candidates.map(candidate => {
                        return (
                            <Grid item xs={4}>
                                <CandidateItem candidate={candidate}
                                               addToShortlist={this.props.addToShortlist}
                                />
                            </Grid>
                        )
                    })
                }
            </Grid>
        )
    }
}

export default CandidateList;