import TitleContainer from "../../header/TitleContainer";
import {FormPaper} from "../shared/FormPaper";
import Grid from "@material-ui/core/Grid";
import {BackButton} from "../../shared/custom-items/SharedStyledItems";
import {Typography} from "@material-ui/core";
import TextField from "@material-ui/core/TextField";
import React from "react";
import CandidateList from "./CandidateList";
import {retrieveCandidatesByFullName} from "../../../services/candidate/candidateService";
import {addCandidateToShortlist} from "../../../services/application/shortlistService";
import StandardButton from "../../shared/custom-items/StandardButton";

class AddCandidateToShortlist extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            role: this.props.location.state.role,
            candidateName: null,
            candidates: []
        }
    }

    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        })
    }

    async search() {
        const res = await retrieveCandidatesByFullName(this.state.candidateName);

        if (res.hasError) {
            this.setState({
                hasError: res.hasError,
                loading: false
            })
        } else {
            this.setState({
                loading: false,
                candidates: res.candidates
            })
        }
    }

    async addCandidateToShortlist(userId){
        const res = await addCandidateToShortlist(userId, this.state.role.id)
        if(res.hasError){
            alert("Error adding candidate to shortlist")
        } else {
            alert("Successfully added candidate to shortlist")
            this.props.history.goBack();
        }
    }

    render() {

        return (
            <Grid container>
                <TitleContainer title={"Add a Candidate to shortlist"}/>
                <FormPaper>
                    <div style={{width: '100%'}}>

                        <Grid container spacing={1}>
                            <Grid item xs={12}>
                                <Grid container>
                                    <Grid item xs={3}>
                                        <BackButton onClick={this.props.history.goBack}>
                                            Cancel
                                        </BackButton>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <Typography variant={"h6"}>
                                            Search for a candidate to add to role {this.state.role.roleName}
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item xs={9}>
                                <TextField style={{
                                    width: '90%',
                                    marginTop: '20px',
                                    height: '5%'
                                }}
                                           id="outlined-search"
                                           label={"Search candidates by name"}
                                           name={"candidateName"}
                                           value={this.state.candidateName}
                                           type="search"
                                           variant="outlined"
                                           onChange={this.handleChange.bind(this)}
                                />
                            </Grid>
                            <Grid item xs={3}>
                                <StandardButton onClick={this.search.bind(this)} style={{
                                    width: '90%',
                                    marginTop: '20px',
                                    height: '100%'
                                }}>
                                    Search
                                </StandardButton>
                            </Grid>
                            <Grid item xs={12}>
                                <CandidateList candidates={this.state.candidates}
                                               addToShortlist={this.addCandidateToShortlist.bind(this)}/>
                            </Grid>
                        </Grid>
                    </div>
                </FormPaper>
            </Grid>
        )
    }
}

export default AddCandidateToShortlist;