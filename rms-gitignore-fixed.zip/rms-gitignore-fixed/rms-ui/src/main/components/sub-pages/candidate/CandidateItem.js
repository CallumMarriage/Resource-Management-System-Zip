import Paper from "@material-ui/core/Paper";
import React from "react";
import Grid from "@material-ui/core/Grid";
import {Typography} from "@material-ui/core";
import StandardButton from "../../shared/custom-items/StandardButton";


export default function CandidateItem(props) {
    return (
        <Paper style={{padding: '20px', margin: '10px'}}>
            <Grid container spacing={2}>
                <Grid item xs={5}>
                    <Typography variant={"body2"} color={"primary"}>
                        Name
                    </Typography>
                </Grid>
                <Grid item xs={5}>
                    <Typography variant={"body2"} color={"primary"}>
                        {props.candidate.fullName}
                    </Typography>
                </Grid>
                <Grid item xs={5}>
                    <Typography variant={"body2"} color={"Primary"}>
                        Grade
                    </Typography>
                </Grid>
                <Grid item xs={5}>
                    <Typography variant={"body2"} color={"primary"}>
                        {props.candidate.grade}
                    </Typography>
                </Grid>
                <Grid item xs={5}>
                    <Typography variant={"body2"} color={"primary"}>
                        User Specialism
                    </Typography>
                </Grid>
                <Grid item xs={5}>
                    <Typography variant={"body2"} color={"primary"}>
                        {props.candidate.userSpecialism}
                    </Typography>
                </Grid>
                <Grid item xs={5}>
                    <Typography variant={"body2"} color={"primary"}>
                        Base Location
                    </Typography>
                </Grid>
                <Grid item xs={5}>
                    <Typography variant={"body2"} color={"primary"}>
                        {props.candidate.baseLocation}
                    </Typography>
                </Grid>
                <Grid item xs={5}>
                    <Typography variant={"body2"} color={"primary"}>
                        Current Role
                    </Typography>
                </Grid>
                <Grid item xs={5}>
                    <Typography variant={"body2"} color={"primary"}>
                        {props.candidate.currentRoleId}
                    </Typography>
                </Grid>
                <Grid item xs={12}>
                    <StandardButton onClick={() => props.addToShortlist(props.candidate.id)}>
                        Add Candidate
                    </StandardButton>
                </Grid>
            </Grid>
        </Paper>
    )
}