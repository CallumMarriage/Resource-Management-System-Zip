import List from "@material-ui/core/List";
import Grid from "@material-ui/core/Grid";
import ListItem from "@material-ui/core/ListItem";
import {Button, Typography} from "@material-ui/core";
import Divider from "@material-ui/core/Divider";
import React from "react";
import withStyles from "@material-ui/core/styles/withStyles";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import Error from "../../shared/Error";
import {applyForRole, hasUserAlreadyApplied} from "../../../services/application/applicationService";
import CustomListItem from "../../shared/custom-items/CustomListItem";
import {CandidateLink} from "../../shared/utils/Links";
import {getUserIdFromAssignment} from "../../../services/assignment/assignmentService";
import {retrieveUserById} from "../../../services/candidate/candidateService";
import {Redirect} from "react-router-dom";

class RoleInformation extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            hasError: false,
            userAlreadyApplied: false,
            candidateName: null,
            candidateId: null
        }
    }

    async componentDidMount() {


        let userAlreadyApplied = await hasUserAlreadyApplied(this.props.userId, this.props.role.id);

        if (userAlreadyApplied.hasError) {
            this.setState({
                loading: false,
                hasError: true
            })
            return;
        }

        let candidate = null;

        if (!this.props.role.isRoleOpen &&
            (this.props.userType === 'RESOURCE_MANAGER' ||
                this.props.userType === 'PROJECT_MANAGER')) {
            let candidateId = await getUserIdFromAssignment(this.props.role.id)
            if ( candidateId === undefined || candidateId.hasError) {
                this.setState({
                    loading: false,
                    hasError: true
                })
                return;
            }
            candidate = await retrieveUserById(candidateId.userId);
            if (candidate.hasError) {
                this.setState({
                    loading: false,
                    hasError: true
                })
                return;
            }
        }

        this.setState({
            loading: false,
            hasError: false,
            userAlreadyApplied: userAlreadyApplied.userAlreadyApplied,
            candidate: candidate
        })
    }

    RenderApplyButton() {

        if (this.state.loading) {
            return (
                <CircularProgress style={{marginTop: '20px'}}/>
            )
        } else if (this.state.hasError) {
            return (
                <Error/>
            )
        }



        if (this.props.role.isRoleOpen === true &&
            this.state.userAlreadyApplied === false &&
            this.props.role.id !== this.props.currentRoleId) {
            return (
                <ListItem>
                    <Grid item xs={12}>
                        <StyledButton onClick={this.apply.bind(this)}>
                            <Typography variant={"body1"}>
                                Apply to be shortlisted
                            </Typography>
                        </StyledButton>
                    </Grid>
                </ListItem>
            )
        } else {
            return null;
        }
    }

    async apply() {
        let res = await applyForRole(this.props.userId, this.props.role)


        if (res.hasError) {
            this.props.retrieveRoleData(this.props.role.id);
            alert("Failed to apply for role")
        } else {
            this.props.retrieveRoleData(this.props.role.id);
            alert("Successfully applied to role")
            this.setState({
                applied: true
            })
        }
    }

    renderIsFilled(isRoleOpen) {
        if (isRoleOpen === false) {
            return 'Yes'
        } else {
            return 'No'
        }
    }

    renderCandidateName() {


        if (this.state.candidateName != null) {
            return (
                <ListItem>
                    <Grid item xs={6}>
                        <Typography variant={'body1'} color={"primary"}>
                            Candidate
                        </Typography>
                    </Grid>
                    <Grid item xs={6}>
                        {
                            CandidateLink({
                                id: this.state.candidate.candidateId,
                                fullName: this.state.candidate.candidateName
                            }, this.CandidateName)
                        }
                    </Grid>
                </ListItem>
            )
        } else {
            return null;
        }
    }

    CandidateName(props) {
        return (
            <Typography variant={'body1'} color={"primary"}>
                {props.props.fullName}
            </Typography>
        )
    }

    render() {
        if (this.state.applied) {
            return (
                <Redirect to={"/Applications/MyApplications"}/>
            )
        }

        if (this.state.hasError) {
            return (<Error/>)
        }

        if (this.state.loading) {
            return <CircularProgress/>
        }

        return (
            <Background>
                <List>
                    <Grid container>
                        <ListItem>
                            <Grid item xs={12}>
                                <Typography variant={'h6'}>
                                    Role information
                                </Typography>
                            </Grid>
                        </ListItem>
                        <Divider/>
                        <CustomListItem title={"Account Name"}
                                        value={this.props.role.accountName}/>
                        <Divider/>
                        <CustomListItem title={"Project Name"}
                                        value={this.props.role.projectName}/>
                        <Divider/>
                        <CustomListItem title={"Desired Grade"}
                                        value={this.props.role.grade}/>
                        <Divider/>
                        <CustomListItem title={"Role Type"}
                                        value={this.props.roleType.label}/>
                        <Divider variant="inset"/>
                        <CustomListItem title={"Role Start Date"}
                                        value={this.props.role.startDate}/>
                        <Divider/>
                        <CustomListItem title={"Role End Date"}
                                        value={this.props.role.endDate}/>
                        <Divider/>
                        <CustomListItem title={"Currently filled"}
                                        value={this.renderIsFilled(this.props.role.isRoleOpen)}/>
                        <Divider/>
                        {this.renderCandidateName()}
                        {this.RenderApplyButton()}
                    </Grid>
                </List>
            </Background>
        )
    }
}


export default RoleInformation;

const Background = withStyles((theme) => ({
    root: {
        width: '80%',
        padding: '5%',
        margin: 'auto',
    }
}))(Paper)

const StyledButton = withStyles((theme) => ({
        root: {
            marginTop: '2%',
            width: '100%',
            height: '50px',
            backgroundColor: theme.palette.success.main
        }
    })
)(Button)