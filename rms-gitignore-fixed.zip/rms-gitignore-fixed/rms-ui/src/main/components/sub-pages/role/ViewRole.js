import React from "react";
import {connect} from "react-redux";

import {getRoleTypes} from "../../shared/enums/RoleTypes";
import Error from "../../shared/Error";
import TitleContainer from "../../header/TitleContainer";
import {retrieveRole} from "../../../services/api/roleService";

import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import { Typography} from "@material-ui/core";
import CircularProgress from "@material-ui/core/CircularProgress";
import RoleInformation from "./RoleInformation";
import Breadcrumbs from "@material-ui/core/Breadcrumbs";
import Link from "@material-ui/core/Link";
import {Link as ReactLink} from "react-router-dom";
import {FormButton, MapButtonStyle} from "../../shared/custom-items/SharedStyledItems";

class ViewRole extends React.Component {

    constructor(props) {
        super(props);

        let role = null;

        if (props.location.state !== undefined) {
            role = props.location.state.role;
        }

        this.state = {
            userAlreadyApplied: false,
            hasError: false,
            loading: true,
            role: role
        }
    }

    async componentDidMount() {

        let shouldRequestData = false;
        let roleId = null;

        if (this.props.location.state === undefined) {
            shouldRequestData = true;
            roleId = this.props.match.params.id;
        } else if (this.state.role.dataMissing) {
            shouldRequestData = true;
            roleId = this.state.role.id;
        }

        if (shouldRequestData) {
            await this.retrieveRoleData(roleId)
            return;
        }

        this.setState({
            loading: false,
            hasError: false,
        })
    }

    async retrieveRoleData(roleId) {
        const res = await retrieveRole(roleId);

        if (res === undefined || res.hasError) {
            this.setState({
                loading: false,
                hasError: true
            })
            return;
        }

        this.setState({
            role: res,
            loading: false,
            hasError: false
        })
    }


    render() {

        const role = this.state.role;

        if (this.state.loading) {
            return <CircularProgress/>
        }

        if (this.state.hasError) {
            return (
                <Error/>
            );
        }

        const roleType = getRoleTypes()
            .find(roleT => roleT.value === role.roleType);

        if (roleType === undefined) {
            return (
                <Error/>
            )
        }

        return (
            <Grid container>
                <Breadcrumbs aria-label="breadcrumb" style={{marginTop: '20px', marginBottom: '10px'}}>
                    <Link color="inherit" href="/SearchAccounts" onClick={this.handleClick}>
                        Search Accounts
                    </Link>
                    <Link color="inherit" href={`/SearchAccounts/Account/${role.accountNumber}`} onClick={this.handleClick}>
                        {role.accountName}
                    </Link>
                    <Link color="inherit" href={`/SearchAccounts/Account/${role.accountNumber}/Project/${role.projectCode}?accountName=${role.accountName}`} onClick={this.handleClick}>
                        {role.projectName}
                    </Link>
                    <Typography color="textPrimary">{role.roleName}</Typography>
                </Breadcrumbs>
                <TitleContainer title={`${role.roleName} at ${role.projectName}`}/>
                <Grid item xs={7}>
                    <Paper>
                        <Typography variant={'h5'}>
                            Role responsibilities
                        </Typography>
                        <Typography variant={'body1'} style={{padding: '40px', textAlign: 'left'}}>
                            {role.description}
                        </Typography>
                        <Grid container>
                            <Grid item xs={6}>
                                <ReactLink style={{textDecoration: 'none'}} to={{
                                    pathname: `/Applications/FindRoles/RoleMap`,
                                    state: {
                                        roles: [role],
                                        baseLocationX: this.props.baseLocationX,
                                        baseLocationY: this.props.baseLocationY
                                    }
                                }}>
                                    <MapButtonStyle style={{marginBottom: '10px'}}>
                                        View role on the map
                                    </MapButtonStyle>
                                </ReactLink>
                            </Grid>
                            <Grid item xs={6}>
                                <ReactLink style={{textDecoration: 'none'}} to={"/Applications/FindRoles"}>
                                    <FormButton style={{margin: '10px'}}>
                                        Find more roles here
                                    </FormButton>
                                </ReactLink>
                            </Grid>
                        </Grid>
                    </Paper>
                </Grid>
                <Grid item xs={5}>
                    <RoleInformation role={role}
                                     userId={this.props.userId}
                                     roleType={roleType}
                                     userType={this.props.userType}
                                     currentRoleId={this.props.currentRoleId}
                                     retrieveRoleData={this.retrieveRoleData.bind(this)}
                    />
                </Grid>
            </Grid>
        )

    }
}

const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id,
        currentRoleId: state.user.user.currentRoleId,
        userType: state.user.user.userType,
        baseLocationX: state.user.user.baseLocationX,
        baseLocationY: state.user.user.baseLocationY
    };
}

export default connect(mapStateToProps)(ViewRole);
