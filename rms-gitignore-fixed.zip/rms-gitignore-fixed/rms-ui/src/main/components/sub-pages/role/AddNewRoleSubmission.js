import React from "react";
import {connect} from "react-redux";

import {getRoleTypes} from "../../shared/enums/RoleTypes";
import TitleContainer from "../../header/TitleContainer";
import {addNewRoleSubmission} from "../../../services/submission/submissionService";

import Grid from "@material-ui/core/Grid";
import InputLabel from "@material-ui/core/InputLabel";
import TextField from "@material-ui/core/TextField";
import Paper from "@material-ui/core/Paper";
import {Typography} from "@material-ui/core";
import EndDateForm from "./EndDateForm";
import ErrorIcon from '@material-ui/icons/Error';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import {retrieveAccountInfo} from "../../../services/api/accountService";
import CircularProgress from "@material-ui/core/CircularProgress";
import {Redirect} from "react-router-dom";
import {getCapBaseLocations} from "../../shared/enums/CapBaseLocations";
import {BackButton, FormButton} from "../../shared/custom-items/SharedStyledItems";
import {FormPaper} from "../shared/FormPaper";
import MyDatePicker from "../../shared/utils/MyDatePicker";
import BusinessUntSelector from "../../shared/custom-items/BusinessUntSelector";
import {checkRoleDetails} from "../../shared/utils/checker";
import ValidatedInputField from "../../shared/custom-items/ValidatedInputField";
import ListSelector from "../../shared/custom-items/ListSelector";
import MenuItem from "@material-ui/core/MenuItem";
import grades from "../../shared/enums/Grades";

class AddNewRoleSubmission extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            startDate: new Date(),
            endDate: null,
            roleName: {value: '', hasError: false},
            roleDescription: {value: '', hasError: false},
            roleType: {value: getRoleTypes()[0].value, hasError: false},
            baseLocation: {value: getCapBaseLocations()[0].value, hasError: false},
            potentialProjects: this.resetPotentialProjects(),
            project: this.resetPotentialProjects()[0],
            accountName: {value: '', hasError: false},
            accountNumber: {value: '', hasError: false},
            businessUnit: {value: '', hasError: false},
            grade: {value: grades[0].value, hasError: false},
            loadingAccountVerification: false,
            hasError: false,
            currentRole: true,
            completed: false,
            accountCorrect: undefined,
            added: false
        };
    }

    resetPotentialProjects = () => {
        return [{
            label: 'Please select',
            id: 'Please Select',
            value: 'PLEASE_SELECT',
            hasError: false
        }]
    }

    handleRadioChange = (event) => {
        this.setState({
            [event.target.name]: event.target.checked,
            endDate: null
        });
    }

    async handleAccountChange(event) {
        const accountNumber = event.target.value;

        this.setState({
            ['accountNumber']: {
                value: accountNumber,
                hasError: false
            }
        })


        if (accountNumber == null || accountNumber === "" || accountNumber.length < 10) {
            this.setState({
                accountCorrect: false,
                loadingAccountVerification: false,
                completed: false
            })
        } else {

            this.setState({
                loadingAccountVerification: true,
                completed: true
            })

            const res = await retrieveAccountInfo(accountNumber);

            let doesExist = false;

            if (res.hasError) {
                doesExist = false
            }
            if (res.account !== undefined) {
                doesExist = true
            }

            if (!doesExist) {
                this.setState({
                    loadingAccountVerification: false,
                    accountCorrect: false,
                    potentialProjects: this.resetPotentialProjects()
                })
            } else {

                const newBus = res.projectList.map((project) => ({
                    label: project.projectName,
                    id: project.projectCode,
                    value: {
                        projectCode: project.projectCode,
                        projectName: project.projectName
                    }
                }));

                const combined = this.state.potentialProjects.concat(newBus);

                this.setState({
                    loadingAccountVerification: false,
                    accountCorrect: true,
                    accountName: {
                        value: res.account.accountName,
                        hasError: false
                    },
                    potentialProjects: combined
                })
            }
        }
    }

    handleChange = (event) => {
        this.setState({
            [event.target.name]: {
                value: event.target.value,
                hasError: false
            }
        })
    }

    handleStartDateChange = (date) => {
        this.setState({
            startDate: date
        })
    }

    handleEndDateChange = (date) => {
        this.setState({
            endDate: date
        })
    }

    setAsErrored(listItem, name) {
        this.setState({
            [name]: {
                hasError: true,
                value: listItem.value,
            }
        })
    }

    async submit() {

        let hasError = checkRoleDetails(this.state.roleName, this.state.roleType,
            this.state.baseLocation, this.state.businessUnit, this.state.grade,
            this.setAsErrored.bind(this));

        if (this.state.project.value === 'PLEASE_SELECT') {
            this.setAsErrored(this.state.project, 'project')
            hasError = true
        }

        if (this.state.accountNumber.value === '') {
            this.setAsErrored(this.state.accountNumber, 'accountNumber')
            hasError = true
        }

        if (hasError) {
            alert('Please make sure required fields are filled in')
            return;
        }

        const res = await addNewRoleSubmission(this.props.userId, {
            roleName: this.state.roleName.value,
            description: this.state.roleDescription.value,
            roleType: this.state.roleType.value,
            baseLocation: this.state.baseLocation.value,
            businessUnitId: this.state.businessUnit.value,
            accountNumber: this.state.accountNumber.value,
            accountName: this.state.accountName.value,
            projectCode: this.state.project.value.projectCode,
            projectName: this.state.project.value.projectName,
            startDate: this.state.startDate,
            endDate: this.state.endDate
        })

        if (res !== undefined && res.hasError) {
            this.setState({
                hasError: res.hasError
            })
        } else {
            this.setState({
                added: true
            })
            alert('Successfully Added new role');
        }
    }

    updateBusinessUnit = (businessUnit) => {
        this.setState({
            businessUnit: {
                value: businessUnit,
                hasError: false
            }
        })
    }

    render() {
        if (this.state.added) {
            return (
                <Redirect to={"/MyCapgeminiCv"}/>
            )
        }

        return (
            <Grid container>
                <TitleContainer title={"Add a new Role"}/>
                <FormPaper>
                    <div style={{width: '100%'}}>

                        <Grid container>
                            <Grid item xs={12}>
                                <Grid container>
                                    <Grid item xs={3}>
                                        <BackButton onClick={this.props.history.goBack}>
                                            Cancel
                                        </BackButton>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <Typography variant={"h6"}>
                                            Add your role details
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
                                <InputLabel htmlFor="roleName">Role Name</InputLabel>
                                <ValidatedInputField describe={"Name of the role"}
                                                     handleChange={this.handleChange.bind(this)}
                                                     id={"roleName"}
                                                     helper={'Please enter role name'}
                                                     value={this.state.roleName}/>
                            </Grid>
                            <ListSelector list={grades}
                                          id={"grade"}
                                          label={"What grade are you looking for?"}
                                          value={this.state.grade}
                                          onChange={this.handleChange}
                                          text={"Please select from the list the required grade"}/>

                            <ListSelector list={getRoleTypes()}
                                          id={"roleType"}
                                          label={"Role Type"}
                                          value={this.state.roleType}
                                          onChange={this.handleChange}
                                          text={"Please select from the list what closest matches your role"}/>

                            <ListSelector list={getCapBaseLocations()}
                                          id={"baseLocation"}
                                          label={"Base Location"}
                                          value={this.state.baseLocation}
                                          onChange={this.handleChange}
                                          text={"Please select your base location"}/>

                            <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
                                <InputLabel htmlFor="accountNumber">Account Number</InputLabel>
                                <TextField id={"accountNumber"}
                                           name={"accountNumber"}
                                           error={this.state.accountNumber.hasError}
                                           defaultValue={this.state.accountNumber.value}
                                           onChange={(e) => this.handleAccountChange(e)}
                                           aria-describedby={'please enter that account Number'}
                                           helperText={this.state.accountNumber.hasError ? 'please enter that account Number' : ''}
                                           style={{width: '70%', padding: '10px'}}
                                           variant="outlined"
                                />
                                {
                                    renderAccountVerified(
                                        this.state.loadingAccountVerification,
                                        this.state.accountCorrect,
                                        this.state.completed)}
                            </Grid>
                            <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
                                <InputLabel htmlFor={'project'}>Project</InputLabel>
                                <TextField
                                    id={'project'}
                                    select
                                    name={'project'}
                                    value={this.state.project.value}
                                    error={this.state.project.hasError}
                                    onChange={(e) => this.handleChange(e)}
                                    helperText={"Please select from the list what closest matches your role"}
                                    variant="outlined"
                                    style={{width: '80%', padding: '10px'}}>
                                    {this.state.potentialProjects.map((option) => (
                                        <MenuItem key={option.id} value={option.value}>
                                            {option.label}
                                        </MenuItem>
                                    ))}
                                </TextField>
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <InputLabel htmlFor="startDate">Start Date</InputLabel>
                                <MyDatePicker id={"startDate"}
                                              date={this.state.startDate}
                                              handleChange={this.handleStartDateChange}
                                />
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <Paper style={{width: '80%', padding: '5px', margin: 'auto'}}>
                                    <EndDateForm currentRole={this.state.currentRole}
                                                 handleRadioChange={this.handleRadioChange}/>
                                    {
                                        renderEndDate(
                                            this.state.currentRole,
                                            this.state.endDate,
                                            this.handleEndDateChange)
                                    }
                                </Paper>
                            </Grid>
                            <BusinessUntSelector businessUnit={this.state.businessUnit}
                                                 updateBusinessUnit={this.updateBusinessUnit}
                                                 handleChange={this.handleChange}/>
                            <Grid item xs={12} style={{marginTop: '20px'}}>
                                <InputLabel htmlFor="description">Role Description</InputLabel>
                                <TextField
                                    style={{width: '80%', padding: '10px'}}
                                    multiline={true}
                                    id={"roleDescription"}
                                    name={"roleDescription"}
                                    onChange={(e) => this.handleChange(e)}
                                    rows={10}
                                    aria-label="Role description"
                                    placeholder="What are the main responsibilities of the role?"
                                    defaultValue=""
                                    variant="outlined"
                                />
                            </Grid>
                            <Grid item xs={12} style={{marginTop: '20px'}}>
                                <FormButton onClick={this.submit.bind(this)}>
                                    Submit
                                </FormButton>
                            </Grid>
                        </Grid>
                    </div>
                </FormPaper>
            </Grid>
        );
    }
}

function renderAccountVerified(loading, verified, completed) {

    if (loading) {
        return (
            <CircularProgress style={{marginTop: '20px'}}/>
        )
    }

    if (completed) {
        if (verified) {
            return (
                <CheckCircleIcon style={{
                    width: '70px',
                    height: '70px',
                    color: "green",
                    margin: 'auto'
                }}/>
            )
        } else {
            return (
                <ErrorIcon style={{
                    width: '70px',
                    height: '70px',
                    color: "red",
                    margin: 'auto'
                }}/>
            )
        }
    }

    return (
        <div/>
    )
}

function renderEndDate(currentRole, endDate, handleChange) {
    if (!currentRole) {
        return (
            <div>
                <InputLabel htmlFor="endDate">End Date</InputLabel>
                <MyDatePicker id={"endDate"} date={endDate} handleChange={handleChange}/>
            </div>
        )
    } else {
        return (
            <Typography variant={"subtitle2"}>
                If current role leave this enabled.
            </Typography>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id,
    };
}

export default connect(mapStateToProps)(AddNewRoleSubmission);