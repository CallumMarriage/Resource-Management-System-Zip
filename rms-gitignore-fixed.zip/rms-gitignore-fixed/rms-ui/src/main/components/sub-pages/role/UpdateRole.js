import React from "react";
import {connect} from "react-redux";

import {getRoleTypes} from "../../shared/enums/RoleTypes";
import TitleContainer from "../../header/TitleContainer";

import Grid from "@material-ui/core/Grid";
import InputLabel from "@material-ui/core/InputLabel";
import TextField from "@material-ui/core/TextField";
import {Typography} from "@material-ui/core";

import {Redirect} from "react-router-dom";
import {getCapBaseLocations} from "../../shared/enums/CapBaseLocations";
import {BackButton, FormButton} from "../../shared/custom-items/SharedStyledItems";
import {FormPaper} from "../shared/FormPaper";
import MyDatePicker from "../../shared/utils/MyDatePicker";
import {addNewRole, removeRole} from "../../../actions/newRoles";
import InputAdornment from "@material-ui/core/InputAdornment";
import {addUpdatedRole, removeUpdatedRole} from "../../../actions/updatedRoles";
import ValidatedInputField from "../../shared/custom-items/ValidatedInputField";
import ListSelector from "../../shared/custom-items/ListSelector";
import {checkRoleDetails} from "../../shared/utils/checker";
import BusinessUntSelector from "../../shared/custom-items/BusinessUntSelector";
import grades from "../../shared/enums/Grades";

class UpdateRole extends React.Component {
    constructor(props) {
        super(props);

        const currentRole = this.props.location.state.role;

        this.state = {
            startDate: currentRole.startDate,
            endDate: currentRole.endDate,
            roleName: {value: currentRole.roleName, hasError: false},
            description: {value: currentRole.description, hasError: false},
            roleType: {value: currentRole.roleType, hasError: false},
            certainty: currentRole.certainty,
            baseLocation: {value: currentRole.baseLocation, hasError: false},
            grade: {value: currentRole.grade, hasError: false},
            businessUnit: currentRole.businessUnit,
            newRole: this.props.location.state.newRole,
            hasError: false,
            added: false
        };
        this.updateBusinessUnit = this.updateBusinessUnit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }


    handleChange = (event) => {
        this.setState({
            [event.target.name]: {
                value: event.target.value,
                hasError: false
            }
        })
    }

    handleStartDateChange = (date) => {
        this.setState({
            startDate: date
        })
    }


    handlePercentChange = (event) => {

        if (event.target.value === '' ||
            (this.test(event.target.value) && this.testPerc(event.target.value)))  {
            this.setState({
                [event.target.name]: event.target.value
            })
        }
    }

    test = (num) => {
        return /^[0-9\b]+$/.test(num);
    }

    testPerc = (num) => {
        return num <= 100 && num > 0;
    }


    handleEndDateChange = (date) => {
        this.setState({
            endDate: date
        })
    }

    updateBusinessUnit(businessUnit){
        this.setState({
            businessUnit: {
                value: businessUnit,
                hasError: false
            }
        })
    }

    async submit() {

        const hasError = checkRoleDetails(this.state.roleName, this.state.roleType,
            this.state.baseLocation, this.state.businessUnit, this.setAsErrored.bind(this));

        if(hasError){
            alert('Please make sure required fields are filled in')
            return;
        }

        let role = {
            startDate: this.state.startDate,
            endDate: this.state.endDate,
            roleName: this.state.roleName.value,
            description: this.state.description.value,
            roleType: this.state.roleType.value,
            certainty: this.state.certainty,
            grade: this.state.grade.value,
            baseLocation: this.state.baseLocation.value,
            businessUnit: this.state.businessUnit.value,
            accountName: this.props.location.state.role.accountName,
            accountNumber: this.props.location.state.role.accountNumber,
            projectCode: this.props.location.state.role.projectCode,
            projectName: this.props.location.state.role.projectName};

        if(this.state.newRole){
            this.updateNewRole(role)
        } else {
            role.id = this.props.location.state.role.id
            this.updateExistingRole(role);
        }
        this.props.history.goBack();
    }

    setAsErrored(listItem, name) {
        this.setState({
            [name]: {
                hasError: true,
                value: listItem.value,
            }
        })
    }

    updateNewRole(roleToUpdate){
        this.props.removeRole(this.props.newRoles.indexOf(roleToUpdate));
        this.props.addNewRole(roleToUpdate);
    }

    updateExistingRole(roleToUpdate){
        this.props.removeUpdatedRole(this.props.updatedRoles.indexOf(roleToUpdate));
        this.props.addUpdatedRole(roleToUpdate);
    }

    render() {

        if (this.state.added) {
            return (
                <Redirect to={"/MyCapgeminiCv"}/>
            )
        }

        return (
            <Grid container>
                <TitleContainer title={"Update Role"}/>
                <FormPaper>
                    <div style={{width: '100%'}}>

                        <Grid container>
                            <Grid item xs={12}>
                                <Grid container>
                                    <Grid item xs={3}>
                                        <BackButton onClick={this.props.history.goBack}>
                                            Cancel
                                        </BackButton>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <Typography variant={"h6"}>
                                            Add your role details
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
                                <InputLabel htmlFor="roleName">Role Name</InputLabel>
                                <ValidatedInputField describe={"Name of the role"}
                                                     handleChange={this.handleChange.bind(this)}
                                                     id={"roleName"}
                                                     helper={'Please enter role name'}
                                                     value={this.state.roleName}/>
                            </Grid>
                            <ListSelector list={getRoleTypes()}
                                          id={"roleType"}
                                          label={"Role Type"}
                                          value={this.state.roleType}
                                          onChange={this.handleChange}
                                          text={"Please select from the list what closest matches your role"}/>
                            <ListSelector list={getCapBaseLocations()}
                                          id={"baseLocation"}
                                          label={"Base Location"}
                                          value={this.state.baseLocation}
                                          onChange={this.handleChange}
                                          text={"Please select your base location"}/>
                            <ListSelector list={grades}
                                          id={"grade"}
                                          label={"What grade are you looking for?"}
                                          value={this.state.grade}
                                          onChange={this.handleChange}
                                          text={"Please select from the list the required grade"}/>

                            <BusinessUntSelector handleChange={this.handleChange}
                                                 updateBusinessUnit={this.updateBusinessUnit}
                                                 businessUnit={this.state.businessUnit}/>

                            <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
                                <InputLabel htmlFor="certainty">Certainty</InputLabel>
                                <TextField id="certainty"
                                           inputProps={{style: {textAlign: 'center'}}}
                                           InputProps={{
                                               style: {textAlign: 'center'},
                                               startAdornment: <InputAdornment position="start">%</InputAdornment>,
                                           }}
                                           value={this.state.certainty}
                                           name={"certainty"}
                                           onChange={this.handlePercentChange}
                                           aria-describedby="How certain are you that this role will be actualised?"
                                           style={{width: '80%', padding: '10px'}}
                                           variant="outlined"
                                />
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <InputLabel htmlFor="startDate">Start Date</InputLabel>
                                <MyDatePicker id={"startDate"}
                                              date={this.state.startDate}
                                              handleChange={this.handleStartDateChange}
                                />
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <InputLabel htmlFor="endDate">End Date</InputLabel>
                                <MyDatePicker id={"endDate"} date={this.state.endDate}
                                              handleChange={this.handleEndDateChange}/>
                            </Grid>
                            <Grid item xs={12} style={{marginTop: '20px'}}>
                                <InputLabel htmlFor="description">Role Description</InputLabel>
                                <TextField
                                    style={{width: '80%', padding: '10px'}}
                                    multiline={true}
                                    id={"description"}
                                    value={this.state.description.value}
                                    name={"description"}
                                    onChange={this.handleChange}
                                    rows={10}
                                    aria-label="Role description"
                                    placeholder="What are the main responsibilities of the role?"
                                    defaultValue=""
                                    variant="outlined"
                                />
                            </Grid>
                            <Grid item xs={12} style={{marginTop: '20px'}}>
                                <FormButton onClick={this.submit.bind(this)}>
                                    Submit
                                </FormButton>
                            </Grid>
                        </Grid>
                    </div>
                </FormPaper>
            </Grid>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id,
        newRoles: state.projectUpdate.newRoles,
        updatedRoles: state.roleUpdate.updatedRoles
    };
}
export default connect(mapStateToProps,
    {removeRole, addNewRole, addUpdatedRole, removeUpdatedRole}
    )(UpdateRole);
