import React from "react";
import CustomListItem from "../../shared/custom-items/CustomListItem";
import List from "@material-ui/core/List";
import Grid from "@material-ui/core/Grid";
import ListItem from "@material-ui/core/ListItem";
import {Typography} from "@material-ui/core";
import Divider from "@material-ui/core/Divider";
import withStyles from "@material-ui/core/styles/withStyles";
import Paper from "@material-ui/core/Paper";


class RoleInformation extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            hasError: false,
            userAlreadyApplied: false
        }
    }

    render() {
        return (
            <Background>
                <List>
                    <Grid container>
                        <ListItem>
                            <Grid item xs={12}>
                                <Typography variant={'h6'}>
                                    Account information
                                </Typography>
                            </Grid>
                        </ListItem>
                        <Divider/>
                        <CustomListItem title={"Account Name"}
                                        value={this.props.account.accountName}/>
                        <Divider/>
                        <CustomListItem title={"Account Manager ID"}
                                        value={this.props.account.accountManagerId}/>
                        <Divider/>
                        <CustomListItem title={"Account Start Date"}
                                        value={this.props.account.startDate}/>
                        <Divider/>
                        <CustomListItem title={"Account End Date"}
                                        value={this.props.account.endDate}/>
                        <Divider/>
                    </Grid>
                </List>
            </Background>
        )
    }
}

const Background = withStyles((theme) => ({
    root: {
        width: '80%',
        padding: '5%',
        margin: 'auto'
    }
}))(Paper)

export default RoleInformation;
