import React from "react";

import StandardButton from "../../shared/custom-items/StandardButton";

export default function UpdateAccountImage(props){

    return (
        <div>
            <StandardButton onClick={props.setUpdatingFalse}>
                X
            </StandardButton>
            <input type="file" name="file" onChange={props.onChange.bind(this)}/>
            <StandardButton onClick={() => props.uploadImage()}>
                Upload Image
            </StandardButton>
        </div>
    )
}