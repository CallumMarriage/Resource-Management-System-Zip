import React from "react";
import TitleContainer from "../../header/TitleContainer";

import Grid from "@material-ui/core/Grid";
import InputLabel from "@material-ui/core/InputLabel";
import TextField from "@material-ui/core/TextField";
import {Typography} from "@material-ui/core";
import MyDatePicker from "../../shared/utils/MyDatePicker";
import {addNewAccount, isAccountAvailable} from "../../../services/api/accountService";
import {Redirect} from "react-router-dom";
import {BackButton, FormButton} from "../../shared/custom-items/SharedStyledItems";
import {FormPaper} from "../shared/FormPaper";
import ValidatedInputField from "../../shared/custom-items/ValidatedInputField";

class AddNewAccount extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            startDate: new Date(),
            endDate: new Date(),
            accountName: {value: '', hasError: false},
            accountDescription: { value: '', hasError: false},
            accountNumber: { value: '', hasError: false, helper: ''},
            hasError: false,
            completed: false,
            added: false
        };
    }

    handleChange = (event) => {
        this.setState({
            [event.target.id]: {
                value: event.target.value, hasError: false
            }
        })
    }

    handleStartDateChange = (date) => {
        this.setState({
            startDate: date
        })
    }

    handleEndDateChange = (date) => {
        this.setState({
            endDate: date
        })
    }

    handleRadioChange = (event) => {
        this.setState({
            [event.target.name]: event.target.checked,
            endDate: null
        });
    }

    isAccountValid = (accountNumber) => {
        return accountNumber.length === 10 &&
            /^\d+$/.test(accountNumber)
    }

    async handleAccountChange(event) {
        const accountNumber = event.target.value;

        if(!this.isAccountValid(accountNumber)){
            return;
        }

        const accountNumAvailable = await isAccountAvailable(accountNumber)

        if(!accountNumAvailable.accountAvailable){
            this.setState({
                accountNumber: {
                    value: accountNumber,
                    hasError: false
                }
            })
        } else {
            this.setState({
                ['accountNumber']: {
                    value: accountNumber,
                    hasError: true,
                    helper: 'Account number unavailable'
                }
            })
        }
    }


    async submit() {


        let hasError;

        if (this.state.accountName.value === '') {
            this.setState({
                accountName: {
                    value: this.state.accountName.value,
                    hasError: true
                }
            })
            hasError = true
        }

        let helper = '';

        if(this.state.accountNumber.value === ''){
            helper = 'Please enter the account number'
        } else if( !this.isAccountValid(this.state.accountNumber.value)) {
            helper = 'The account number should be all numbers and 10 digits'
        }

        if (helper !== '') {

            this.setState({
                accountNumber: {
                    value: this.state.accountNumber.value,
                    hasError: true,
                    helper: helper
                }
            })
            hasError = true
        }

        if(hasError){
            alert('Please complete all required fields');
            return;
        }

        const res = await addNewAccount(
            this.state.accountNumber.value,
            this.state.accountName.value,
            this.state.startDate,
            this.state.endDate,
            this.state.description.value,
            this.props.location.state.userId)

        if (res !== undefined && res.hasError) {
            this.setState({
                hasError: res.hasError
            })
            alert('Error adding account')
        } else {
            this.setState({
                added: true
            })
            alert('Successfully Added new account');
        }
    }

    render() {

        if (this.state.added) {
            return (
                <Redirect to={"/ProjectManagement"}/>
            )
        }

        return (
            <Grid container>
                <TitleContainer title={"Add a new Account"}/>
                <FormPaper>
                    <Grid container>
                        <Grid item xs={12}>
                            <BackButton onClick={this.props.history.goBack}>
                                Cancel
                            </BackButton>
                            <Typography variant={"h6"}>
                                Add the details for the new account.
                            </Typography>
                        </Grid>

                        <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
                            <InputLabel htmlFor="accountName">Account Name *</InputLabel>
                            <ValidatedInputField describe={"What was your role on the project"}
                                                 handleChange={this.handleChange}
                                                 id={"accountName"}
                                                 helper={'Please enter the name of the account'}
                                                 value={this.state.accountName}/>
                        </Grid>
                        <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
                            <InputLabel htmlFor="accountNumber">Account Number *</InputLabel>
                            <ValidatedInputField describe={"What is the internal account number?"}
                                                 handleChange={this.handleAccountChange.bind(this)}
                                                 id={"accountNumber"}
                                                 helper={this.state.accountNumber.helper}
                                                 value={this.state.accountNumber}/>
                        </Grid>
                        <Grid item xs={12} md={6}>
                            <InputLabel htmlFor="startDate">Start Date</InputLabel>
                            <MyDatePicker id={"startDate"}
                                          date={this.state.startDate}
                                          handleChange={this.handleStartDateChange}
                            />
                        </Grid>
                        <Grid item xs={12} md={6}>
                            <InputLabel htmlFor="endDate">End Date</InputLabel>
                            <MyDatePicker id={"startDate"}
                                          date={this.state.endDate}
                                          handleChange={this.handleEndDateChange}
                            />
                        </Grid>
                        <Grid item xs={12} style={{marginTop: '20px'}}>
                            <InputLabel htmlFor="description">Account Description</InputLabel>
                            <TextField
                                style={{width: '90%', padding: '10px'}}
                                multiline={true}
                                id={"description"}
                                onChange={this.handleChange}
                                rows={10}
                                aria-label="Account description"
                                placeholder="Briefly describe the account here"
                                defaultValue=""
                                variant="outlined"
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <FormButton onClick={this.submit.bind(this)}
                                        disabled={this.state.accountNumber.hasError}
                            >
                                Submit
                            </FormButton>
                        </Grid>

                    </Grid>
                </FormPaper>
            </Grid>
        );
    }
}


export default AddNewAccount;