import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import {IconButton, withStyles} from "@material-ui/core";
import AccountImage from "./AccountImage";
import React from "react";
import {uploadImageFile} from "../../../services/image/imageService";
import Typography from "@material-ui/core/Typography";
import StandardButton from "../../shared/custom-items/StandardButton";

class AccountImageSection extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            updating: false,
            fileToUpload: null,
            base64: null
        }
    }

    setUpdating() {
        this.setState({
            updating: true
        })
    }

    setUpdatingFalse() {
        this.setState({
            base64: null,
            updating: false
        })
    }

    onImageChange(e) {
        let files = e.target.files;
        let reader = new FileReader();
        reader.readAsDataURL(files[0]);

        reader.onload = e => {
            let base64 = e.target.result.substring(23)
            this.setState({
                fileToUpload: e.target.result,
                base64: base64
            })
        };
    }

    async uploadImage() {
        const uploaded = await uploadImageFile(
            this.props.accountNumber,
            this.state.fileToUpload)
        if (uploaded.hasError) {
            alert('Failed to upload image');
            this.setState({
                updating: false,
            })
        } else {
            alert('Successfully uploaded image')
            this.setState({
                updating: false,
            })
        }

    }

    render() {
        if (this.state.updating) {
            return (
                <Paper style={{width: '80%', height: '500px'}}>
                    <Grid container>
                        <Grid item xs={1}>
                            <IconButton onClick={this.setUpdatingFalse.bind(this)}>
                                X
                            </IconButton>
                        </Grid>
                        <Grid item xs={12}>
                        </Grid>
                        <Grid item xs={12}>
                            <AccountImage accountNumber={this.props.accountNumber} newImage={this.state.base64}/>

                        </Grid>
                        <Grid item xs={12} style={{marginTop: '50px'}}>

                            <Typography variant={"subtitle2"} color={"primary"}>
                                The image must be a jpeg.
                            </Typography>
                            <input type="file"
                                   name="file"
                                   onChange={this.onImageChange.bind(this)}/>

                            <StandardButton onClick={this.uploadImage.bind(this)}>
                                Upload Image
                            </StandardButton>
                        </Grid>
                    </Grid>
                </Paper>
            )
        } else {
            return (
                <Paper style={{height: '90%', padding: '20px'}}>
                    <StyledButton onClick={this.setUpdating.bind(this)}>
                        Update the account image
                    </StyledButton>
                    <div style={{width: '90%', margin: 'auto'}}>
                        <AccountImage accountNumber={this.props.accountNumber}/>

                    </div>
                </Paper>

            )
        }
    }
}


const StyledButton = withStyles((theme) => ({
    root: {
        height: '36px',
        borderRadius: '10px',
        marginBottom: '10px'
    }
}))(StandardButton)


export default AccountImageSection;