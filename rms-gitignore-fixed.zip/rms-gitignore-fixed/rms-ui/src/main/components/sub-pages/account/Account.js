import React from "react";

import Paper from "@material-ui/core/Paper";
import {Typography, withStyles} from "@material-ui/core";
import Grid from "@material-ui/core/Grid";
import {retrieveAccountInfo} from "../../../services/api/accountService";
import CircularProgress from "@material-ui/core/CircularProgress";
import Error from "../../shared/Error";
import TitleContainer from "../../header/TitleContainer";
import {ProjectLink} from "../../shared/utils/Links";
import {connect} from "react-redux";
import AccountImageSection from "./AccountImageSection";
import AccountInformation from "./AccountInformation";
import Link from "@material-ui/core/Link";
import Breadcrumbs from "@material-ui/core/Breadcrumbs";
import StandardButton from "../../shared/custom-items/StandardButton";

const StyledButton = withStyles((theme) => ({
    root: {
        width: '100%',
        height: '90%',
        margin: 'auto',
        backgroundColor: theme.palette.primary.dark,
        padding: '30px',
    }
}))(StandardButton)

const DescBackground = withStyles((theme) => ({
    root: {
        color: theme.palette.primary.main,
        padding: '20px',
        minHeight: '250px',
        marginBottom: '30px'
    }
}))(Paper)

class Account extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            image: null,
            accountNumber: this.props.match.params.accountId,
            account: null,
            projectList: null,
            hasError: false,
            loading: true
        }
    }

    async componentDidMount() {
        const res = await retrieveAccountInfo(this.state.accountNumber)
        if (res.hasError) {
            this.setState({
                hasError: true,
                loading: false
            })
        }

        this.setState({
            hasError: false,
            loading: false,
            account: res.account,
            projectList: res.projectList
        })
    }

    handleClick() {

    }

    render() {

        if (this.state.loading) {
            return (<CircularProgress/>
            )
        }

        if (this.state.hasError) {
            return (
                <Error/>
            )
        }

        return (
            <Grid container style={{marginBottom: '100px'}} spacing={3}>
                <Breadcrumbs aria-label="breadcrumb" style={{marginTop: '20px', marginBottom: '10px'}}>
                    <Link color="inherit" href="/SearchAccounts" onClick={this.handleClick}>
                        Search Accounts
                    </Link>
                    <Typography color="textPrimary">{this.state.account.accountName}</Typography>
                </Breadcrumbs>
                <TitleContainer title={this.state.account.accountName}/>
                <Grid item xs={6}>
                    <Grid container>
                        <Grid item xs={12}>
                            <AccountImageSection
                                accountNumber={this.state.account.accountCode}/>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item xs={6}>
                    <AccountInformation account={this.state.account}/>
                </Grid>
                <Grid item xs={12}>
                    <DescBackground>
                        <Typography variant={"h6"}>
                            Description
                        </Typography>
                        <Typography variant={"body1"} color={"textPrimary"}>
                            {this.state.account.description}
                        </Typography>
                    </DescBackground>
                </Grid>
                <Grid item xs={12} style={{marginTop: '-20px'}}>
                    <Paper>
                        <Grid container style={{padding: '20px'}} spacing={1}>
                            <Grid item xs={12}>
                                <Typography variant={"h6"} color={"primary"}>
                                    Projects
                                </Typography>
                            </Grid>
                            {this.state.projectList.map(project => {
                                project.accountName = this.state.account.accountName
                                return (
                                    <Grid item xs={3} key={project.projectCode}>
                                        {
                                            ProjectLink(project, ProjectItem)
                                        }
                                    </Grid>
                                )
                            })}
                        </Grid>
                    </Paper>

                </Grid>
            </Grid>
        )
    }
}

function ProjectItem(props) {
    return (
        <StyledButton key={props.props.projectCode}>
            <Typography variant={"h6"}>
                {props.props.projectName}
            </Typography>
        </StyledButton>)
}


const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id,
    };
}


export default connect(mapStateToProps)(Account);