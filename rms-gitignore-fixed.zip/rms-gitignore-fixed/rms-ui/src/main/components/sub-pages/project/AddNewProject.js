import React from "react";

import Grid from "@material-ui/core/Grid";
import InputLabel from "@material-ui/core/InputLabel";
import TextField from "@material-ui/core/TextField";
import {Typography} from "@material-ui/core";
import {addNewProject} from "../../../services/api/projectService";
import {Redirect} from "react-router-dom";
import TitleContainer from "../../header/TitleContainer";
import {BackButton, FormButton} from "../../shared/custom-items/SharedStyledItems";
import {connect} from "react-redux";
import {getCapBaseLocations} from "../../shared/enums/CapBaseLocations";
import {FormPaper} from "../shared/FormPaper";
import MyDatePicker from "../../shared/utils/MyDatePicker";
import ListSelector from "../../shared/custom-items/ListSelector";
import ValidatedInputField from "../../shared/custom-items/ValidatedInputField";
import {handleListItemCheck} from "../../shared/utils/checker";


class AddNewProject extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            startDate: new Date(),
            endDate: new Date(),
            projectName: {value: '', hasError: false},
            projectCode: {value: '', hasError: false, helper: ''},
            description: {value: '', hasError: false, helper: ''},
            accountNumber: props.location.state.accountNumber,
            baseLocation: {value: getCapBaseLocations()[0].value, hasError: false},
            baseLocations: getCapBaseLocations(),
            hasError: false,
            completed: false,
            added: false,
        };
    }

    handleChange = (event) => {
        this.setState({
            [event.target.name]: {
                value: event.target.value,
                hasError: false
            }
        })
    }

    handleStartDateChange = (date) => {
        this.setState({
            startDate: date
        })
    }

    handleEndDateChange = (date) => {
        this.setState({
            endDate: date
        })
    }

    async handleProjectCodeChange(event) {
        const projectCode = event.target.value;

        if(!this.isProjectCodeValid(projectCode)){
            return;
        }

        this.setState({
            projectCode: {
                value: projectCode,
                hasError: false
            }
        })
    }

    setAsErrored(listItem, name) {
        this.setState({
            [name]: {
                hasError: true,
                value: listItem.value,
            }
        })
    }

    isProjectCodeValid = (projectCode) => {
        return projectCode.length === 10 &&
            /^\d+$/.test(projectCode)
    }


    async submit() {
        let hasError = false
        if (this.state.projectName.value === '') {
            this.setAsErrored(this.state.projectName, 'projectName')
            hasError = true
        }

        if (handleListItemCheck(this.state.baseLocation, 'baseLocation')) {
            this.setAsErrored(this.state.baseLocation, 'baseLocation')
            hasError = true
        }

        let helper = '';

        if(this.state.projectCode.value === ''){
            helper = 'Please enter the project code'
        } else if(!this.isProjectCodeValid(this.state.projectCode.value)){
            helper = 'The project code should be all numbers and 10 digits'
        }

        if (helper !== '') {

            this.setState({
                projectCode: {
                    value: this.state.projectCode.value,
                    hasError: true,
                    helper: helper
                }
            })
            hasError = true
        }

        if (hasError) {
            alert('Please complete the form');
            return;
        }

        const res = await addNewProject(
            this.state.projectCode.value,
            this.state.accountNumber,
            this.state.projectName.value,
            this.state.description.value,
            this.state.baseLocation.value,
            this.props.userId,
            this.state.startDate,
            this.state.endDate);

        if (res !== undefined && res.hasError) {
            this.setState({
                hasError: res.hasError
            })
        } else {
            this.setState({
                added: true
            })
            alert('Successfully added new Project');
        }
    }

    render() {

        if (this.state.added) {
            return (
                <Redirect to={"/ProjectManagement"}/>
            )
        }

        if(this.state.hasError){
            alert('Error')
        }

        return (
            <Grid container>
                <TitleContainer title={"Add a new Project"}/>
                <FormPaper>
                    <Grid container>
                        <Grid item xs={12}>
                            <BackButton onClick={this.props.history.goBack}>
                                Cancel
                            </BackButton>
                            <Typography variant={"h6"}>
                                Add the details for the new project.
                            </Typography>
                        </Grid>
                        <Grid item md={6} xs={12} style={{marginTop: '20px'}}>
                            <InputLabel htmlFor="projectName">Project Name *</InputLabel>
                            <ValidatedInputField describe={"Name of the project"}
                                                 handleChange={this.handleChange.bind(this)}
                                                 id={"projectName"}
                                                 helper={'Please enter project name'}
                                                 value={this.state.projectName}/>
                        </Grid>
                        <Grid item md={6} xs={12} style={{marginTop: '20px'}}>
                            <InputLabel htmlFor="projectCode">Project Code *</InputLabel>
                            <ValidatedInputField describe={"Internal code for the project"}
                                                 handleChange={this.handleProjectCodeChange.bind(this)}
                                                 id={"projectCode"}
                                                 helper={this.state.projectCode.helper}
                                                 value={this.state.projectCode}/>
                        </Grid>
                        <ListSelector list={this.state.baseLocations}
                                      id={"baseLocation"}
                                      label={"Base Location"}
                                      value={this.state.baseLocation}
                                      onChange={this.handleChange}
                                      text={"Please select your base location"}/>
                        <Grid item md={6} xs={12}>
                            <InputLabel htmlFor="startDate">Start Date</InputLabel>
                            <MyDatePicker id={"startDate"}
                                          date={this.state.startDate}
                                          handleChange={this.handleStartDateChange}
                            />
                        </Grid>
                        <Grid item md={6} xs={12}>
                            <InputLabel htmlFor="endDate">End Date</InputLabel>
                            <MyDatePicker id={"startDate"}
                                          date={this.state.endDate}
                                          handleChange={this.handleEndDateChange}
                            />
                        </Grid>
                        <Grid item xs={12} style={{marginTop: '20px'}}>
                            <InputLabel htmlFor="description">Project Description</InputLabel>
                            <TextField
                                style={{width: '90%', padding: '10px'}}
                                multiline={true}
                                id={"description"}
                                name={"description"}
                                value={this.state.description.value}
                                onChange={this.handleChange.bind(this)}
                                rows={10}
                                aria-label="Project description"
                                placeholder="Briefly describe the project here"
                                variant="outlined"
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <FormButton onClick={this.submit.bind(this)}>
                                Submit
                            </FormButton>
                        </Grid>
                    </Grid>
                </FormPaper>
            </Grid>
        );
    }
}


const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id,
    };
}

export default connect(mapStateToProps)(AddNewProject);