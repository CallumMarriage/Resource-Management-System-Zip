import React from "react";
import {connect} from "react-redux";

import {getRoleTypes} from "../../shared/enums/RoleTypes";
import TitleContainer from "../../header/TitleContainer";

import Grid from "@material-ui/core/Grid";
import InputLabel from "@material-ui/core/InputLabel";
import TextField from "@material-ui/core/TextField";
import {Typography} from "@material-ui/core";
import {getCapBaseLocations} from "../../shared/enums/CapBaseLocations";
import {BackButton, FormButton} from "../../shared/custom-items/SharedStyledItems";
import {addNewRole} from "../../../actions/newRoles";
import {FormPaper} from "../shared/FormPaper";
import MyDatePicker from "../../shared/utils/MyDatePicker";
import InputAdornment from "@material-ui/core/InputAdornment";
import ValidatedInputField from "../../shared/custom-items/ValidatedInputField";
import {checkRoleDetails} from "../../shared/utils/checker";
import BusinessUntSelector from "../../shared/custom-items/BusinessUntSelector";
import ListSelector from "../../shared/custom-items/ListSelector";
import grades from "../../shared/enums/Grades";


class AddNewRoleForProject extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            startDate: Date.parse(this.props.location.state.projectStartDate),
            endDate: Date.parse(this.props.location.state.projectEndDate),
            roleName: {value: '', hasError: false},
            roleDescription: {value: '', hasError: false},
            certainty: 1,
            grade: {value: grades[0].value, hasError: false},
            roleType: {value: getRoleTypes()[0].value, hasError: false},
            baseLocation: {value: getCapBaseLocations()[0].value, hasError: false},
            baseLocations: getCapBaseLocations(),
            businessUnit: null
        };

        this.updateBusinessUnit = this.updateBusinessUnit.bind(this);
    }

    handleChange = (event) => {
        this.setState({
            [event.target.name]: {
                value: event.target.value,
                hasError: false
            }
        })
    }

    handleNumChange = (event) => {
        if (event.target.value === '' || this.test(event.target.value)) {
            this.setState({
                [event.target.name]: event.target.value
            })
        }
    }

    handlePercentChange = (event) => {

        if (event.target.value === '' ||
            (this.test(event.target.value) && this.testPerc(event.target.value))) {
            this.setState({
                [event.target.name]: event.target.value
            })
        }
    }

    test = (num) => {
        return /^[0-9\b]+$/.test(num);
    }

    testPerc = (num) => {
        return num <= 100 && num > 0;
    }

    handleStartDateChange = (date) => {
        this.setState({
            startDate: date
        })
    }

    handleEndDateChange = (date) => {
        this.setState({
            endDate: date
        })
    }

    async submit() {


        const hasError = checkRoleDetails(this.state.roleName,
            this.state.roleType, this.state.baseLocation,
            this.state.businessUnit, this.state.grade, this.setAsErrored.bind(this));

        if(hasError){
            alert('Please make sure required fields are filled in')
            return;
        }

        this.props.addNewRole({
            roleName: this.state.roleName.value,
            description: this.state.roleDescription.value,
            roleType: this.state.roleType.value,
            baseLocation: this.state.baseLocation.value,
            grade: this.state.grade.value,
            startDate: new Date(this.state.startDate).toISOString().substring(0, 10),
            endDate: new Date(this.state.endDate).toISOString().substring(0, 10),
            accountName: this.props.location.state.accountName,
            accountNumber: this.props.location.state.accountNumber,
            projectCode: this.props.location.state.projectCode,
            projectName: this.props.location.state.projectName,
            businessUnit: this.state.businessUnit.value,
            numRolesToAdd: this.state.numRolesToAdd,
            certainty: this.state.certainty
        });

        alert('Successfully created role to be added. Submit changes to make this permanent.');
        this.props.history.goBack();

    }

    setAsErrored(listItem, name) {
        this.setState({
            [name]: {
                hasError: true,
                value: listItem.value,
            }
        })
    }

    updateBusinessUnit(businessUnit){
        this.setState({
            businessUnit: {
                value: businessUnit,
                hasError: false
            }
        })
    }

    render() {

        return (
            <Grid container>
                <TitleContainer title={"Add a new Role"}/>
                <FormPaper>

                    <Grid container>
                        <Grid item xs={12}>
                            <Grid container>
                                <Grid item xs={3}>
                                    <BackButton onClick={this.props.history.goBack}>
                                        Cancel
                                    </BackButton>
                                </Grid>
                                <Grid item xs={6}>
                                    <Typography variant={"h6"}>
                                        Add your role details
                                    </Typography>
                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
                            <InputLabel htmlFor="roleName">Role Name *</InputLabel>
                            <ValidatedInputField describe={"Name of the role"}
                                                 handleChange={this.handleChange.bind(this)}
                                                 id={"roleName"}
                                                 helper={'Please enter role name'}
                                                 value={this.state.roleName}/>
                        </Grid>
                        <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
                            <InputLabel htmlFor="certainty">Certainty *</InputLabel>
                            <TextField id="certainty"
                                       inputProps={{style: {textAlign: 'center'}}}
                                       InputProps={{
                                           style: {textAlign: 'center'},
                                           startAdornment: <InputAdornment position="start">%</InputAdornment>,
                                       }}
                                       value={this.state.certainty}
                                       name={"certainty"}
                                       onChange={this.handlePercentChange}
                                       aria-describedby="How certain are you that this role will be actualised?"
                                       style={{width: '80%', padding: '10px'}}
                                       variant="outlined"
                            />
                        </Grid>
                        <ListSelector list={getRoleTypes()}
                                      id={"roleType"}
                                      label={"Role Type"}
                                      value={this.state.roleType}
                                      onChange={this.handleChange}
                                      text={"Please select from the list what closest matches your role"}/>

                        <Grid item xs={12} md={6}>
                            <InputLabel htmlFor="startDate">Start Date</InputLabel>
                            <MyDatePicker id={"startDate"}
                                          parentStartDate={this.props.location.state.projectStartDate}
                                          parentEndDate={this.props.location.state.projectEndDate}
                                          date={this.state.startDate}
                                          handleChange={this.handleStartDateChange}
                            />
                        </Grid>
                        <Grid item xs={12} md={6}>
                            <InputLabel htmlFor="endDate">End Date</InputLabel>
                            <MyDatePicker id={"endDate"}
                                          date={this.state.endDate}
                                          parentStartDate={this.props.location.state.projectStartDate}
                                          parentEndDate={this.props.location.state.projectEndDate}
                                          handleChange={this.handleEndDateChange}/>
                        </Grid>
                        <ListSelector list={grades}
                                      id={"grade"}
                                      label={"What grade are you looking for?"}
                                      value={this.state.grade}
                                      onChange={this.handleChange}
                                      text={"Please select from the list the required grade"}/>

                        <ListSelector list={this.state.baseLocations}
                                      id={"baseLocation"}
                                      label={"Base Location"}
                                      value={this.state.baseLocation}
                                      onChange={this.handleChange}
                                      text={"Please select your base location"}/>

                        <BusinessUntSelector handleChange={this.handleChange}
                                             updateBusinessUnit={this.updateBusinessUnit}
                                             businessUnit={this.state.businessUnit}/>

                        <Grid item xs={12}>
                            <InputLabel htmlFor="description">Role Description</InputLabel>
                            <TextField
                                style={{width: '90%', padding: '10px'}}
                                multiline={true}
                                id={"roleDescription"}
                                name={"roleDescription"}
                                onChange={this.handleChange}
                                rows={10}
                                value={this.state.roleDescription.value}
                                aria-label="Role description"
                                placeholder="What are the main responsibilities of the role?"
                                defaultValue=""
                                variant="outlined"
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <FormButton onClick={this.submit.bind(this)}>
                                Add
                            </FormButton>
                        </Grid>
                    </Grid>

                </FormPaper>
            </Grid>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id
    };
}

export default connect(mapStateToProps, {addNewRole})(AddNewRoleForProject);