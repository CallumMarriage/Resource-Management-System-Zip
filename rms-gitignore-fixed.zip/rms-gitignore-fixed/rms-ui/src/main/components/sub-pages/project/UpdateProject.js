import React from "react";
import {connect} from "react-redux";
import {Link, Redirect} from "react-router-dom";

import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import {Typography} from "@material-ui/core";
import InputLabel from "@material-ui/core/InputLabel";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import CircularProgress from "@material-ui/core/CircularProgress";

import MyDatePicker from "../../shared/utils/MyDatePicker";
import {BackButton, FormButton} from "../../shared/custom-items/SharedStyledItems";
import TitleContainer from "../../header/TitleContainer";
import {retrieveProjectInfo, updateProject} from "../../../services/api/projectService";
import Error from "../../shared/Error";

import RoleItem from "./RoleItem";
import {removeAllRoles} from "../../../actions/newRoles";
import {removeAllUpdatedRoles} from "../../../actions/updatedRoles";

class UpdateProject extends React.Component {

    constructor(props) {
        super(props);

        const projectDetails = props.location.state.project;

        this.state = {
            startDate: projectDetails.startDate,
            endDate: projectDetails.endDate,
            projectManagerId: this.props.userId,
            accountNumber: projectDetails.accountNumber,
            accountName: projectDetails.accountName,
            projectName: projectDetails.projectName,
            projectCode: projectDetails.projectCode,
            description: projectDetails.description,
            roleList: [],
            hasError: false,
            updated: false,
            loading: false
        };
    }

    async componentDidMount() {
        const res = await retrieveProjectInfo(this.state.projectCode);

        if (res.hasError) {
            this.setState({
                hasError: true,
                loading: false
            })
        } else {
            this.setState({
                hasError: false,
                loading: false,
                roleList: res.roleList
            })
        }
    }

    handleChange = (event) => {
        this.setState({
            [event.target.id]: event.target.value
        })
    }

    handleStartDateChange = (date) => {
        this.setState({
            startDate: date
        })
    }

    handleEndDateChange = (date) => {
        this.setState({
            endDate: date
        })
    }

    async submit() {
        // Check if roles are updated or are new roles.
        const res = await updateProject(this.state,
            this.props.newRoles,
            this.props.updatedRoles,
            [],
            this.props.userId);

        this.props.removeAllRoles();
        this.props.removeAllUpdatedRoles();

        if (res.hasError) {
            this.setState({
                hasError: res.hasError
            })
        } else {
            this.setState({
                added: true
            })
            alert('Successfully updated project');
        }
    }

    findRoleInUpdated(roleId) {
        const updatedRoles = this.props.updatedRoles;
        for (let i = 0; i < updatedRoles.length; i++) {
            if (updatedRoles[i].id === roleId) {
                return updatedRoles[i];
            }
        }

        return false;
    }

    renderExistingRole(role) {
        const updatedRole = this.findRoleInUpdated(role.id)
        if (updatedRole === false) {
            return (
                <RoleItem role={role}
                          newRole={false}
                />
            )
        } else {
            return null
        }
    }

    render() {
        if (this.state.loading) {
            return (
                <CircularProgress style={{marginTop: '20px'}}/>
            )
        }
        if (this.state.hasError) {
            return (
                <Error/>
            )
        }

        if (this.state.added) {
            return (
                <Redirect to={"/ProjectManagement"}/>)
        }

        let existingRoles = this.state.roleList;
        return (
            <Grid container>
                <TitleContainer title={"Update Project"}/>
                <Grid item xs={12}>
                    <Paper>
                        <Grid container spacing={1}>
                            <Grid item xs={12} md={9}>
                                <Grid container spacing={2}>
                                    <Grid item xs={12}>
                                        <BackButton onClick={this.props.history.goBack}>
                                            Cancel
                                        </BackButton>
                                        <Typography variant={"h6"}>
                                            Project Details
                                        </Typography>
                                    </Grid>

                                    <Grid item xs={6} style={{marginTop: '20px'}}>
                                        <InputLabel htmlFor="projectName">Project Name</InputLabel>
                                        <TextField id="projectName"
                                                   value={this.state.projectName}
                                                   onChange={this.handleChange}
                                                   inputProps={{style: {textAlign: 'center'}}}
                                                   aria-describedby="What was your role on the project"
                                                   style={{width: '80%', padding: '10px'}}
                                                   variant="outlined"
                                        />
                                    </Grid>
                                    <Grid item xs={6}>
                                        <InputLabel htmlFor="startDate">Start Date</InputLabel>
                                        <MyDatePicker id={"startDate"}
                                                      date={this.state.startDate}
                                                      handleChange={this.handleStartDateChange}
                                        />
                                    </Grid>
                                    <Grid item xs={6}>
                                        <InputLabel htmlFor="endDate">End Date</InputLabel>
                                        <MyDatePicker id={"startDate"}
                                                      date={this.state.endDate}
                                                      handleChange={this.handleEndDateChange}
                                        />
                                    </Grid>
                                    <Grid item xs={12} style={{marginTop: '20px'}}>
                                        <InputLabel htmlFor="description">Project Description</InputLabel>
                                        <TextField
                                            style={{width: '90%', padding: '10px'}}
                                            multiline={true}
                                            id={"description"}
                                            value={this.state.description}
                                            onChange={this.handleChange}
                                            rows={10}
                                            aria-label="Project description"
                                            placeholder="Briefly describe the project here"
                                            variant="outlined"
                                        />
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item xs={12} md={3}>
                                <Grid container spacing={2}>
                                    <Grid item xs={12}>
                                        <Typography variant={"h6"}>
                                            Existing Roles
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12}>
                                        <Grid container spacing={2}>
                                            {
                                                existingRoles.map((role) => {
                                                    return (
                                                        <Grid item xs={12}>
                                                            {
                                                                this.renderExistingRole(role)
                                                            }
                                                        </Grid>
                                                    )
                                                })
                                            }
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12}>
                                        <Typography variant={"h6"}>
                                            Updated Roles
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12}>
                                        <Grid container spacing={2}>
                                            {
                                                this.props.updatedRoles.map((role) => {
                                                    return (
                                                        <Grid item xs={12}>
                                                            <RoleItem role={role}
                                                                      newRole={false}
                                                            />
                                                        </Grid>
                                                    )
                                                })
                                            }
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12}>
                                        <Typography variant={"h6"}>
                                            New Roles
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12}>
                                        <Grid container spacing={2}>
                                            {
                                                this.props.newRoles.map((role) => {
                                                    return (
                                                        <Grid item xs={12}>
                                                            <RoleItem role={role}
                                                                      newRole={true}
                                                            />
                                                        </Grid>
                                                    )
                                                })
                                            }
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12}>
                                        <Link style={{textDecoration: 'none'}} to={{
                                            pathname: `/ProjectManagement/AddNewRole`,
                                            state: {
                                                projectCode: this.state.projectCode,
                                                projectName: this.state.projectName,
                                                projectStartDate: this.state.startDate,
                                                projectEndDate: this.state.endDate,
                                                accountNumber: this.state.accountNumber,
                                                accountName: this.state.accountName
                                            }
                                        }}>
                                            <FormButton>
                                                Add a new role
                                            </FormButton>
                                        </Link>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item xs={12}>
                                <FormButton onClick={this.submit.bind(this)}>
                                    Submit
                                </FormButton>
                            </Grid>
                        </Grid>
                    </Paper>
                </Grid>
            </Grid>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        newRoles: state.projectUpdate.newRoles,
        updatedRoles: state.roleUpdate.updatedRoles,
        userId: state.user.user.id
    };
}

export default connect(mapStateToProps, {removeAllRoles, removeAllUpdatedRoles})(UpdateProject);