import List from "@material-ui/core/List";
import Grid from "@material-ui/core/Grid";
import ListItem from "@material-ui/core/ListItem";
import {Typography} from "@material-ui/core";
import Divider from "@material-ui/core/Divider";
import CustomListItem from "../../shared/custom-items/CustomListItem";
import React from "react";
import withStyles from "@material-ui/core/styles/withStyles";
import Paper from "@material-ui/core/Paper";

export default function ProjectInformation(props){
    return (
        <Background>
            <List>
                <Grid container>
                    <ListItem>
                        <Grid item xs={12}>
                            <Typography variant={'h6'}>
                                Project information
                            </Typography>
                        </Grid>
                    </ListItem>
                    <Divider/>
                    <CustomListItem title={"Project Name"}
                                    value={props.project.projectName}/>
                    <Divider/>
                    <CustomListItem title={"Project Start Date"}
                                    value={props.project.startDate}/>
                    <Divider/>
                    <CustomListItem title={"Project End Date"}
                                    value={props.project.endDate}/>
                    <Divider/>
                    <CustomListItem title={"Is Project Active?"}
                                    value={isProjectActive(props.project.startDate,
                                            props.project.endDate)}/>
                    <CustomListItem title={"Account Name"}
                                    value={props.accountName}/>
                    <Divider/>
                    <CustomListItem title={"Number of roles"}
                                    value={calculateNumberOfRoles(props.roleList)}/>
                    <Divider/>
                </Grid>
            </List>
        </Background>
    )
}

function isProjectActive(startDate, endDate){
    const date = new Date();

    if(Date.parse(startDate) > date){
        return 'Project is yet to start';
    }
    if(Date.parse(endDate) < date){
        return 'Project has been completed';
    } else {
        return 'Project is active';
    }

}

function calculateNumberOfRoles(roles){
    return roles.length;
}

const Background = withStyles((theme) => ({
    root: {
        width: '80%',
        padding: '5%',
        margin: 'auto'
    }
}))(Paper)