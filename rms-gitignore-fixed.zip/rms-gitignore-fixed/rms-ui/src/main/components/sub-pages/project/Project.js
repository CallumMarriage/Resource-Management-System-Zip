import React from "react";

import TitleContainer from "../../header/TitleContainer";
import Error from "../../shared/Error";
import {retrieveProjectInfo} from "../../../services/api/projectService";

import Grid from "@material-ui/core/Grid";

import CircularProgress from "@material-ui/core/CircularProgress";
import RolesChart from "./charts/RolesChart";
import ProjectInformation from "./ProjectInformation";
import Paper from "@material-ui/core/Paper";
import {Typography} from "@material-ui/core";
import Breadcrumbs from "@material-ui/core/Breadcrumbs";
import Link from "@material-ui/core/Link";

class Project extends React.Component {

    constructor(props) {
        super(props);

        let accountName = null;

        if(props.location.state !== undefined){
            accountName = props.location.state.accountName;
        } else {
            accountName = new URLSearchParams(props.location.search)
                .get('accountName');
        }

        this.state = {
            loading: true,
            hasError: false,
            project: null,
            accountName: accountName,
            projectCode: props.match.params.projectId,
            roleList: []
        }
    }

    async componentDidMount() {
        const res = await retrieveProjectInfo(this.state.projectCode)

        if (res.hasError) {
            this.setState({
                hasError: true,
                loading: false
            })
        } else {
            this.setState({
                hasError: false,
                loading: false,
                project: res.targetProject,
                roleList: res.roleList
            })
        }
    }

    render() {

        if (this.state.loading) {
            return (<CircularProgress/>
            )
        }

        if (this.state.hasError) {
            return (
                <Error/>
            )
        }

        const project = this.state.project;
        return (
            <Grid container spacing={3}>
                <Breadcrumbs aria-label="breadcrumb" style={{marginTop: '20px', marginBottom: '10px'}}>
                    <Link color="inherit" href="/SearchAccounts" onClick={this.handleClick}>
                        Search Accounts
                    </Link>
                    <Link color="inherit" href={`/SearchAccounts/Account/${this.state.project.accountNumber}`} onClick={this.handleClick}>
                        {this.state.accountName}
                    </Link>
                    <Typography color="textPrimary">{this.state.project.projectName}</Typography>
                </Breadcrumbs>
                <TitleContainer title={project.projectName + ' at ' + this.state.accountName}/>
                <Grid item xs={6} style={{marginBottom: '20px'}}>
                    <Paper style={{padding: '5%', height: '85%', paddingBottom: '7.5%'}}>
                        <Typography variant={"h6"} color={"primary"}>
                            Project Description
                        </Typography>
                        <Typography variant={"body1"} style={{marginTop: '10px'}}>
                            {project.description}
                        </Typography>
                    </Paper>
                </Grid>
                <Grid item xs={6}>
                    {
                        <ProjectInformation project={project}
                                            roleList={this.state.roleList}
                                            accountName={this.state.accountName}
                        />
                    }
                </Grid>
                <Grid item xs={12}>
                    <RolesChart targetProject={this.state.project}
                                roleList={this.state.roleList}/>
                </Grid>
            </Grid>
        )

    }
}

export default Project;