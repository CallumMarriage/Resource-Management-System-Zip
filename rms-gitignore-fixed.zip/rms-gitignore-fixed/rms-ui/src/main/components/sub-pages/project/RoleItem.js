import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import React from "react";
import {Typography, withStyles} from "@material-ui/core";
import Button from "@material-ui/core/Button";
import {connect} from "react-redux";
import {addNewRole, removeRole} from "../../../actions/newRoles";
import {Link} from "react-router-dom";

class RoleItem extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            hasError: false,
            candidateName: null
        }
    }

    removeRole() {
        const role = this.props.role;
        if (this.props.newRole) {
            this.props.removeRole(this.props.newRoles.indexOf(role));
        }
    }


    returnRemoveButton() {
        if (this.props.newRole) {
            return (
                <WhiteButton onClick={this.removeRole.bind(this)}
                             style={{fontSize: '10pt'}}>
                    Remove
                </WhiteButton>
            )
        }
    }

    updateRoleButton() {
        if(this.props.newRole){
            return (
                <Link style={{textDecoration: 'none'}} to={{
                    pathname: `/ProjectManagement/Project/${this.props.role.projectCode}/Role/NEW/UpdateRole`,
                    state: {
                        role: this.props.role,
                        newRole: true,
                        addRoleToUpdated: this.props.addRoleToUpdated
                    }
                }}>
                    <WhiteButton style={{fontSize: '10pt'}}>
                        Update
                    </WhiteButton>
                </Link>
            )
        } else {
            return (
                <Link style={{textDecoration: 'none'}} to={{
                    pathname: `/ProjectManagement/Project/${this.props.role.projectCode}/Role/${this.props.role.id}/UpdateRole`,
                    state: {
                        role: this.props.role,
                        newRole: false,
                        addRoleToUpdated: this.props.addRoleToUpdated
                    }
                }}>
                    <WhiteButton style={{fontSize: '10pt'}}>
                        Update
                    </WhiteButton>
                </Link>
            )
        }
    }

    render() {
        return (
            <Paper style={{width: '90%', margin: 'auto', backgroundColor: 'green', color: 'white'}}>
                <Grid container spacing={1}>
                    <Grid item xs={12}>
                        <Grid container>
                            <Grid item xs={6}>
                                <Typography variant={"body2"}>
                                    {this.props.role.roleName}
                                </Typography>
                            </Grid>
                            <Grid item xs={3}>
                                {this.returnRemoveButton()}
                            </Grid>
                            <Grid item xs={3}>
                                {this.updateRoleButton()}
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
            </Paper>
        )
    }
}

const WhiteButton = withStyles((theme) => ({
    root: {
        backgroundColor: theme.palette.secondary.main,
        color: theme.palette.success.main
    }
}))(Button)

const mapStateToProps = (state) => {
    return {
        newRoles: state.projectUpdate.newRoles
    };
}

export default connect(mapStateToProps, {removeRole, addNewRole})(RoleItem);