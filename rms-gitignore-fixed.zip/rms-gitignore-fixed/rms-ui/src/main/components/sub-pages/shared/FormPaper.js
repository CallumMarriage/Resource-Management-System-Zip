import {withStyles} from "@material-ui/core";
import Paper from "@material-ui/core/Paper";

export const FormPaper = withStyles({
    root: {
        width: '90%',
        paddingRight: '10%',
        paddingLeft: '10%',
        paddingBottom: '20px',
        paddingTop: '20px'
    }
})(Paper)