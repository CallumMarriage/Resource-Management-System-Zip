import React from 'react';
import {connect} from "react-redux";
import CircularProgress from "@material-ui/core/CircularProgress";
import {retrieveApplications} from "../../services/application/applicationService";

import Error from "../shared/Error";
import TitleContainer from "../header/TitleContainer";
import Grid from "@material-ui/core/Grid";
import Application from "./Application";
import NoneFound from "../shared/custom-items/NoneFound";
import {Typography} from "@material-ui/core";


class MyApplications extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            applications: [],
            loading: true,
            hasError: false
        };
    }

    async componentDidMount() {
        const userId = this.props.user.id;
        const res = await retrieveApplications(userId);
        this.setState({potentialRoles: []})
        if (res == null) {
            this.setState({
                loading: false
            })
        } else if (res.hasError) {
            this.setState({
                hasError: true,
                error: res.error,
                loading: false
            })
        } else {
            this.setState({
                applications: res.applicationInfoList,
                loading: false,
                searching: false
            })
        }
    }

    render() {

        return (
            <Grid container>
                <TitleContainer title={'My Applications'}/>
                {renderApplicationContainer(this.state.loading,
                    this.state.hasError,
                    this.state.applications, this.props.user.id)}
            </Grid>

        )
    }
}

function renderApplicationContainer(loading, hasError, applications, userId) {
    if (loading) {
        return (
            <CircularProgress style={{marginTop: '20px'}}/>
        )
    } else if (hasError) {
        return (
            <Error/>
        )
    } else if (applications.length === 0) {
        return (
            <NoneFound title={"You have no applications"}/>
        )
    }

    return (
        <Grid container spacing={1}>
            <Grid item xs={6} style={{margin: 'auto'}}>
                <Typography variant={"h6"} color={"primary"}>
                    Roles you have applied to be shortlisted for
                </Typography>
                <Typography variant={"body1"}>
                    Here are the roles that you have put yourself forward to be shortlisted for.
                    Your resource manager will review these applications and shortlist you when
                    they believe you are a good fit.
                </Typography>
            </Grid>
            <Grid item xs={12}>
                <Grid container spacing={2}>
                    {
                        applications.map((application) => {
                            return (
                                <Grid item xs={4} key={application.applicationId}>
                                    <Application application={application}/>
                                </Grid>
                            )
                        })
                    }
                </Grid>
            </Grid>
        </Grid>
    )
}

const mapStateToProps = (state) => {
    return {
        user: state.user.user,
    };
}

export default connect(mapStateToProps)(MyApplications);