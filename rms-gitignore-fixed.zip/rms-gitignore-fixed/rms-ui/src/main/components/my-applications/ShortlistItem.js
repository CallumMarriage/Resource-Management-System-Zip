import Paper from "@material-ui/core/Paper";
import List from "@material-ui/core/List";
import Grid from "@material-ui/core/Grid";
import ListItem from "@material-ui/core/ListItem";
import {Typography} from "@material-ui/core";
import Divider from "@material-ui/core/Divider";
import CustomListItem from "../shared/custom-items/CustomListItem";
import {AccountLink, ProjectLink, RoleLink} from "../shared/utils/Links";
import React from "react";

export default function ShortlistItem(props) {
    return (
        <Paper style={{margin: '20px'}}>
            <List>
                <Grid container>
                    <ListItem>
                        <Grid item xs={12}>
                            <Typography variant={'h6'}>
                                Shortlist item
                            </Typography>
                        </Grid>
                    </ListItem>
                    <ListItem>
                        <Grid item xs={6}>
                            <Typography variant={'body1'} color={"primary"}>
                                Account Number
                            </Typography>
                        </Grid>
                        <Grid item xs={6}>
                            {
                                AccountLink({
                                    accountNumber: props.role.accountNumber
                                }, AccountField)
                            }
                        </Grid>
                    </ListItem>
                    <Divider/>
                    <ListItem>
                        <Grid item xs={6}>
                            <Typography variant={'body1'} color={"primary"}>
                                Project Code
                            </Typography>
                        </Grid>
                        <Grid item xs={6}>
                            {
                                ProjectLink({
                                    accountNumber: props.role.accountNumber,
                                    projectCode: props.role.projectCode
                                }, ProjectField)
                            }
                        </Grid>
                    </ListItem>
                    <Divider/>

                    <ListItem>
                        <Grid item xs={6}>
                            <Typography variant={'body1'} color={"primary"}>
                                Role Id
                            </Typography>
                        </Grid>
                        <Grid item xs={6}>
                            {
                                RoleLink({
                                    accountNumber: props.role.accountNumber,
                                    projectCode: props.role.projectCode,
                                    id: props.role.id,
                                    dataMissing: true
                                }, RoleField)
                            }
                        </Grid>
                    </ListItem>
                    <Divider/>
                    <CustomListItem title={"Desired Grade"}
                                    value={'A6'}/>
                    <Divider/>
                    <Divider variant="inset"/>
                    <Divider/>
                </Grid>
            </List>
        </Paper>
    )
}

function AccountField(props) {
    return (
        <Typography variant={'body1'}>
            {props.props.accountNumber}
        </Typography>
    )
}

function ProjectField(props) {
    return (
        <Typography variant={'body1'}>
            {props.props.projectCode}
        </Typography>
    )
}


function RoleField(props) {
    return (
        <Typography variant={'body1'}>
            {props.props.id}
        </Typography>
    )
}
