import Grid from "@material-ui/core/Grid";
import React from "react";
import ShortlistItem from "./ShortlistItem";
import {retrieveShortlistForUser} from "../../services/application/shortlistService";
import {retrieveRole} from "../../services/api/roleService";
import Error from "../shared/Error";
import CircularProgress from "@material-ui/core/CircularProgress";
import {Typography} from "@material-ui/core";
import TitleContainer from "../header/TitleContainer";
import {connect} from "react-redux";
import NoneFound from "../shared/custom-items/NoneFound";

class MyShortlisted extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            shortlist: [],
            roles: [],
            loading: true,
            hasError: false
        }
    }

    async componentDidMount() {
        let res;
        if(this.props.retrieveShortlistForUser === undefined){
            res = await retrieveShortlistForUser(this.props.userId)

        } else {
            res = await this.props.retrieveShortlistForUser(this.props.userId)

        }

        if (res.hasError) {
            this.setState({
                hasError: true
            })
            return;
        }

        if(res.length === 0){
            this.setState({
                roles: [],
                loading: false
            })
            return;
        }
        const roles = await this.getData(res);

        this.setState({
            roles: roles,
            loading: false
        })
    }

    getData = async (res) => {
        return Promise.all(res.map(si => this.retrieveRole(si.roleId)))
    }

    async retrieveRole(roleId) {
        let role;
        if(this.props.retrieveRole === undefined){
            role = await retrieveRole(roleId)
        } else {
            role = await this.props.retrieveRole(roleId);
        }

        if (!role.hasError) {
            return role;
        }
    }

    renderShortlist() {

        if (this.state.hasError) {
            return <Error/>
        }

        if (this.state.loading) {
            return <CircularProgress style={{marginTop: '20px'}}/>
        }

        return (
            <Grid container spacing={2}>
                <Grid item xs={6} style={{margin: 'auto'}}>
                    <Typography variant={"h6"} color={"primary"}>
                        Roles you have been Shortlisted for
                    </Typography>
                    <Typography variant={"body1"}>
                        Here are the roles that you have been shortlisted for.
                        This means that you are one of the candidates put forward by your
                        resource manager to take on these roles.
                    </Typography>
                </Grid>
                <Grid item xs={12}>
                    {
                        renderShortlist(this.state.roles)
                    }
                </Grid>
            </Grid>
        )

    }

    render() {

        return (
            <Grid container>
                <TitleContainer title={"Shortlisted"}/>
                {this.renderShortlist()}
            </Grid>
        )
    }
}

function renderShortlist(roles){
    if(roles.length === 0){
        return (
            <NoneFound title={'You have not been shortlisted for any roles yet.'}/>
        )
    } else {
        return (
            <Grid container>
                {
                    roles.map((role) => {
                        return (
                            <Grid item xs={4} key={role.id} id={role.id}>
                                <ShortlistItem role={role}/>
                            </Grid>
                        )
                    })
                }
            </Grid>
        )
    }
}


const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id,
    };
}

export default connect(mapStateToProps)(MyShortlisted);