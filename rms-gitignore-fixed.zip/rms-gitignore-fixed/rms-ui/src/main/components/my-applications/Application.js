import React from "react";

import {Typography, withStyles} from "@material-ui/core";
import Paper from "@material-ui/core/Paper";
import List from "@material-ui/core/List";
import Grid from "@material-ui/core/Grid";
import ListItem from "@material-ui/core/ListItem";
import Divider from "@material-ui/core/Divider";
import CustomListItem from "../shared/custom-items/CustomListItem";
import {AccountLink, ProjectLink, RoleLink} from "../shared/utils/Links";

export default function Application(props) {
    return (
        <Paper style={{margin: '20px', border: '1px solid lightgrey'}}>
            <List>
                <Grid container>
                    <ListItem>
                        <Grid item xs={12}>
                            <Typography variant={'h6'}>
                                Application information
                            </Typography>
                        </Grid>
                    </ListItem>
                    <Divider/>
                    {renderStatus(props.application.applicationStatus)}
                    <Divider/>

                    <CustomListItem title={"Application ID"}
                                    value={props.application.projectId}/>
                    <Divider/>
                    <CustomListItem title={"Application Date"}
                                    value={props.application.applicationDate}/>
                    <Divider/>
                    <ListItem>
                        <Grid item xs={6}>
                            <Typography variant={'body1'} color={"primary"}>
                                Account Number
                            </Typography>
                        </Grid>
                        <Grid item xs={6}>
                            {
                                AccountLink({
                                    accountNumber: props.application.accountId
                                }, AccountField)
                            }
                        </Grid>
                    </ListItem>
                    <Divider/>
                    <ListItem>
                        <Grid item xs={6}>
                            <Typography variant={'body1'} color={"primary"}>
                                Project Code
                            </Typography>
                        </Grid>
                        <Grid item xs={6}>
                            {
                                ProjectLink({
                                    accountNumber: props.application.accountId,
                                    projectCode: props.application.projectId
                                }, ProjectField)
                            }
                        </Grid>
                    </ListItem>
                    <Divider/>

                    <ListItem>
                        <Grid item xs={6}>
                            <Typography variant={'body1'} color={"primary"}>
                                Role Id
                            </Typography>
                        </Grid>
                        <Grid item xs={6}>
                            {
                                RoleLink({
                                    accountNumber: props.application.accountId,
                                    projectCode: props.application.projectId,
                                    id: props.application.roleId,
                                    dataMissing: true
                                }, RoleField)
                            }
                        </Grid>
                    </ListItem>
                    <Divider/>
                    <CustomListItem title={"Desired Grade"}
                                    value={'A6'}/>
                    <Divider/>
                    <Divider variant="inset"/>
                    <Divider/>
                </Grid>
            </List>
        </Paper>
    )
}

function renderStatus(status) {

    if (status === 'ACCEPTED') {
        return (
            <SuccessStatusPaper>
                <Typography variant={"h6"} color={"secondary"}>
                    Your have been accepted for this role
                </Typography>
            </SuccessStatusPaper>
        )
    } else if (status === 'SHORTLISTED') {

        return (
            <ShortlistPaper>
                <Typography variant={"h6"} color={"secondary"}>
                    Your have been shortlisted for this role
                </Typography>
            </ShortlistPaper>
        )

    } else if (status === 'REJECTED') {
        return (
            <RejectedStatusPaper>

                <Typography variant={"h6"} color={"secondary"}>
                    Your application has been rejected
                </Typography>
            </RejectedStatusPaper>
        )
    } else {
        return (
            <InReviewStatusPaper>

                <Typography variant={"body1"}>
                    Your application is in review
                </Typography>
            </InReviewStatusPaper>
        )
    }
}

const RejectedStatusPaper = withStyles((theme) => ({
    root: {
        backgroundColor: theme.palette.error.dark,
        width: '100%',
        padding: '10px'
    }
}))(Paper);


const SuccessStatusPaper = withStyles((theme) => ({
    root: {
        backgroundColor: theme.palette.success.main,
    }
}))(RejectedStatusPaper);

const InReviewStatusPaper = withStyles((theme) => ({
    root: {
        backgroundColor: 'darkgrey',
        borderRadius: '0px',
        color: 'white',
        borderBottom: '2px solid darkgrey',
        boxShadow: 'none',
        width: '100%',
        padding: '10px'
    }
}))(Paper);

const ShortlistPaper = withStyles((theme) => ({
    root: {
        backgroundColor: theme.palette.primary.dark,
    }
}))(RejectedStatusPaper)

function AccountField(props) {
    return (
        <Typography variant={'body1'}>
            {props.props.accountNumber}
        </Typography>
    )
}

function ProjectField(props) {
    return (
        <Typography variant={'body1'}>
            {props.props.projectCode}
        </Typography>
    )
}


function RoleField(props) {
    return (
        <Typography variant={'body1'}>
            {props.props.id}
        </Typography>
    )
}
