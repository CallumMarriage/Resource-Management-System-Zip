import React from 'react';
import {connect} from "react-redux";

import Grid from "@material-ui/core/Grid";
import {Typography} from "@material-ui/core";
import Paper from "@material-ui/core/Paper";
import withStyles from "@material-ui/core/styles/withStyles";
import {AccountLink as accountLink, ProjectLink as projectLink, RoleLink} from "../shared/utils/Links";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import Divider from "@material-ui/core/Divider";
import CustomListItem from "../shared/custom-items/CustomListItem";

const SecondaryHeaderTyp = withStyles((theme) => ({
    root: {
        color: 'black',
        padding: '10px',
        fontSize: '1.5em'

    }
}))(Typography)

const Background = withStyles((theme) => ({
    root: {
        backgroundColor: 'white'
    }
}))(Paper)

class YourRole extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            hasError: false,
            rmName: null,
        }
    }


    renderRmName() {


    }

    render() {
        let project = this.props.currentProject;
        let account = this.props.currentAccount;

        let role = this.props.currentRole;

        return (
            <Background>
                <Grid container style={{padding: '20px'}}>
                    <Grid item xs={12}>
                        <SecondaryHeaderTyp>
                            Here you can find out all your current information
                        </SecondaryHeaderTyp>
                    </Grid>
                    <Grid item xs={12} md={12} style={{margin: 'auto'}}>
                        <List>
                            <Grid container style={{width: '100%', margin: 'auto'}}>

                                <Divider/>
                                <CustomListItem title={"Full name"}
                                                value={this.props.user.fullName}/>
                                <Divider/>
                                <CustomListItem title={"Specialism"}
                                                value={this.props.user.userSpecialism}/>
                                <Divider/>
                                <CustomListItem title={"Grade"}
                                                value={this.props.user.grade}/>
                                <Divider/>
                                <Divider variant="inset"/>
                                <CustomListItem title={"Base Location"}
                                                value={this.props.user.baseLocation}/>
                                <CustomListItem title={"Resource Manager"}
                                                value={this.props.user.resourceManagerName}/>

                                <Divider/>
                                {
                                    renderCurrentRole(role)
                                }
                                <Divider/>
                                {
                                    renderCurrentProject(project, account)
                                }
                                <Divider/>
                                {
                                    renderCurrentAccount(account)
                                }
                                <Divider light/>
                                {
                                    renderHelpInfo()
                                }
                            </Grid>
                        </List>
                    </Grid>
                </Grid>
            </Background>
        )
    }
}

function renderHelpInfo() {
    return (
        <ListItem style={{borderTop: '1px solid black', margin: '5px'}}>
            <div>
                <Typography variant={"subtitle1"}>
                    Is the above role information correct?
                </Typography>
                <Typography variant={"subtitle2"}>
                    If it is out of date you can update it here
                </Typography>
            </div>
        </ListItem>
    )
}

function renderResourceManager() {

    return (
        <CustomListItem title={"Resource Manager"}
                        value={'Not available'}/>
    )
}

function renderCurrentRole(role) {
    const RoleButton = (props) => (
        <Typography variant={'body1'} id={props.props.roleName}>
            {props.props.roleName}
        </Typography>
    )

    return renderLinkItem('Current Role',
        RoleLink,
        role,
        RoleButton,
        role
    );
}

function renderCurrentProject(project, account) {
    if (project != null) {
        project.accountName = account.accountName
    }
    const ProjectButton = (props) => (
        <Typography variant={'body1'} id={props.props.projectName}>
            {props.props.projectName}
        </Typography>
    )
    return renderLinkItem('Current Project',
        projectLink,
        project,
        ProjectButton,
        project
    );
}

function renderCurrentAccount(account) {

    const AccountButton = (props) => (
        <Typography variant={'body1'} id={props.props.accountName}>
            {props.props.accountName}
        </Typography>
    )

    let props;
    if(account !== null){
        props = {
            accountNumber: account.accountCode,
            accountName: account.accountName
        }

    }

    return renderLinkItem('Current Account',
        accountLink,
        account,
        AccountButton,
        props
    );
}


function renderLinkItem(title, link, value, Button, props) {
    if (value !== null) {
        return (
            <ListItem id={title}>
                <Grid item xs={6}>
                    <Typography variant={'body1'} color={"primary"}>
                        {title}
                    </Typography>
                </Grid>
                <Grid item xs={6}>
                    {
                        link(props, Button)
                    }
                </Grid>
            </ListItem>
        )
    } else {
        return (
            <CustomListItem title={title}
                            value={'None'}/>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        user: state.user.user,
        currentRole: state.user.currentRole,
        currentAccount: state.user.currentAccount,
        currentProject: state.user.currentProject
    };
}

export default connect(mapStateToProps)(YourRole);