import {Typography} from "@material-ui/core";
import React from "react";
import withStyles from "@material-ui/core/styles/withStyles";

import Paper from "@material-ui/core/Paper";

const StyledPaper = withStyles((theme) => ({
    root: {
        height: '100px',
        width: '100%',
        marginBottom: '10px',
        backgroundColor: theme.palette.primary.main,
        color: 'white',
        boxShadow: 'none',
        borderBottom: '2px solid #12ABDB',
        borderRadius: '0px',
        textAlign: 'center',
        display: "flex"
    }
}))(Paper)

const HeaderTypo = withStyles({
    root: {
        margin: 'auto'
    }
})(Typography)


export default function TitleContainer(props) {

    return (
        <StyledPaper>
            <HeaderTypo id={'TitleContainer'} variant={"h4"} align={'center'}>
                {props.title}
            </HeaderTypo>
        </StyledPaper>
    )
}