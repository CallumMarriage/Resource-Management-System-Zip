import React from "react";
import Link from "@material-ui/core/Link";
import {Typography} from "@material-ui/core";
import Grid from "@material-ui/core/Grid";


export default function Footer() {

    return (
        <Grid container style={{
            paddingTop: '1%',
            paddingBottom: '1%',
            borderRadius: 0,
            textAlign: 'center',
            width: '100%',
            color: 'white',
            height: '100px',
            position: "relative",
            backgroundColor: '#e6e7e9',
            bottom: '-10px'
        }}>
            <Grid item={true} xs={3}>
                <Grid container spacing={2} style={{marginLeft: '100px'}}>
                    <Grid item xs={4}>
                        <Link target="_blank" rel="noreferrer" href={"https://www.capgemini.com/privacy-policy/"}>
                            <Typography variant={"body2"} style={{color: '#7a7a7a'}}>
                                Privacy
                            </Typography>
                        </Link>
                    </Grid>

                    <Grid item xs={4}>
                        <Link target="_blank" rel="noreferrer" href={"https://www.capgemini.com/terms-of-use/"}>
                            <Typography variant={"body2"} style={{color: '#7a7a7a'}}>
                                Terms of use
                            </Typography>
                        </Link>
                    </Grid>
                </Grid>
            </Grid>
            <Grid item={true} xs={9}>
                <Typography variant={"body2"} style={{
                    color: '#7a7a7a',
                    float: 'right',
                    marginRight: '20px'
                }}>
                    All rights reserved by Capgemini. Copyright © 2021
                </Typography>
            </Grid>
        </Grid>
    )
}