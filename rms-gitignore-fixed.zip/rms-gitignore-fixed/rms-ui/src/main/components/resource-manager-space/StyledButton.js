import TableCell from "@material-ui/core/TableCell";
import React from "react";
import {withStyles} from "@material-ui/core";
import StandardButton from "../shared/custom-items/StandardButton";

export default function updateApp(isDisabled, application, title, callback){
    return (
        <TableCell component="th" scope={"row"}>
            <StyledButtonResourceManager disabled={!isDisabled}
                          onClick={() => callback(application)}>
                {title}
            </StyledButtonResourceManager>
        </TableCell>
    )
}

const StyledButtonResourceManager = withStyles((theme) => ({
    root: {
        backgroundColor: theme.palette.primary.main,
        color: 'white',
        width: '100px',
        height: '50px'
    },
    disabled: {
        color: 'lightgrey',
        backgroundColor: 'darkgrey'
    }
}))(StandardButton)
