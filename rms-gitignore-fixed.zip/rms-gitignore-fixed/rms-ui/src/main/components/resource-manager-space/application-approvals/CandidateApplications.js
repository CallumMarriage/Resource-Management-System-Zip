import Grid from "@material-ui/core/Grid";
import React from "react";
import {connect} from "react-redux";
import Paper from "@material-ui/core/Paper";
import CircularProgress from "@material-ui/core/CircularProgress";
import Error from "../../shared/Error";
import {Typography} from "@material-ui/core";
import Table from "@material-ui/core/Table";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import TableBody from "@material-ui/core/TableBody";
import TableContainer from "@material-ui/core/TableContainer";

import TitleContainer from "../../header/TitleContainer";
import {retrieveApplicationsForRm} from "../../../services/application/applicationService";
import CandidateApplication from "./CandidateApplication";
import NoneFound from "../../shared/custom-items/NoneFound";


class CandidateApplications extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            applications: null,
            hasError: false,
            loading: true,
            canReject: false,
            canReview: false,
            canApprove: false
        }

        this.RenderTable = this.RenderTable.bind(this);
    }

    async componentDidMount() {
        await this.retrieveCandidates();
    }

    async retrieveCandidates() {

        const applications = await retrieveApplicationsForRm(this.props.userId)
        if (applications.hasError) {
            this.setState({
                hasError: true,
                loading: false
            })
        } else {
            this.setState({
                applications: applications.applicationInfoList,
                loading: false,
                hasError: false
            })
        }
    }

    RenderTable() {
        if (this.state.loading) {
            return (
                <CircularProgress style={{marginTop: '20px'}}/>
            )
        } else if (this.state.hasError) {
            return (
                <Error/>
            )
        } else if (this.state.applications.length === 0){
            return <NoneFound title={"No applications to approve"}/>
        }

        return (
            <TableContainer component={Paper}>
                <Table size="small" aria-label="a dense table">
                    <TableHead>
                        <TableRow>
                            <CandidateTableCell content={"Candidate ID"}/>
                            <CandidateTableCell content={"Application date"}/>
                            <CandidateTableCell content={"Last updated date"}/>
                            <CandidateTableCell content={"Application Status"}/>
                            <CandidateTableCell content={"Role ID"}/>
                            <CandidateTableCell content={"Review"}/>
                            <CandidateTableCell content={"Reject"}/>
                            <CandidateTableCell content={"Accept"}/>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {this.state.applications.map((application) => (
                            <CandidateApplication
                                application={application}
                                afterFunction={this.retrieveCandidates.bind(this)}/>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        )
    }

    render() {

        return (
            <Grid container>
                <TitleContainer title={"Candidate Shortlist Applications"}/>
                <Grid item xs={12}>
                    {this.RenderTable()}
                </Grid>
            </Grid>
        )
    }
}


function CandidateTableCell(props) {
    return (
        <TableCell>
            <Typography variant={"subtitle1"} color={"textPrimary"}>
                {props.content}
            </Typography>
        </TableCell>
    )
}

const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id,
    };
}

export default connect(mapStateToProps)(CandidateApplications);