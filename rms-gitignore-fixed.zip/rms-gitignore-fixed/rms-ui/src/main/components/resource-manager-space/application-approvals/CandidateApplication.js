import TableRow from "@material-ui/core/TableRow";
import React from "react";
import TableCell from "@material-ui/core/TableCell";
import {Typography} from "@material-ui/core";
import updateApp from "../StyledButton";
import {
    markAsInReviewCandidateApplication,
    rejectCandidateApplication,
    shortlistCandidateApplication
} from "../../../services/application/applicationUpdateService";
import StandardButton from "../../shared/custom-items/StandardButton";
import {RoleLink} from "../../shared/utils/Links";

export default function CandidateApplication(props){
    const application = props.application;
    return (
        <TableRow key={application.applicationId}>
            <CandidateTableCellRow content={application.applicantId}/>
            <CandidateTableCellRow content={application.applicationDate}/>
            <CandidateTableCellRow content={application.lastUpdatedDate}/>
            <CandidateTableCellRow content={application.applicationStatus}/>
            <CandidateTableCellRow content={application.roleId}/>

            {renderInReviewButton(application, 'In Review', markAsInReview, props.afterFunction)}
            {renderButton(application, 'Reject', reject, props.afterFunction)}
            {renderButton(application, 'Approve', shortlist, props.afterFunction)}
        </TableRow>
    )
}

async function reject(application) {
    const res = await rejectCandidateApplication(application.applicationId);

    if(res.hasError){
        alert('Error updating shortlist application')
    } else {
        alert('Reject candidate ' + application.applicationId);
    }
    this.props.afterFunction();
}

async function shortlist(application, callback) {
    const res = await shortlistCandidateApplication(application.applicationId);

    if(res.hasError){
        alert('Error updating shortlist application')
    } else {
        alert('Shortlisted candidate ' + application.applicationId);
    }
    callback();
}

async function markAsInReview(application, callback) {
    const res = await markAsInReviewCandidateApplication(application.applicationId, this.props.userId);

    if(res.hasError){
        alert('Error updating shortlist application')
    } else {
        alert('Marked candidate app as in review ' + application.applicationId);
    }
   callback();
}


function returnIfNotFinalised(applicationStatus) {
    return applicationStatus === 'SUBMITTED'
        || applicationStatus === 'IN_REVIEW';
}

function CandidateTableCellRow(props) {
    return (
        <TableCell component="th" scope="row">
            <Typography variant={"body1"} color={"textSecondary"}>
                {props.content}
            </Typography>
        </TableCell>
    )
}

function renderButton(application, title, execution, callback) {
    const isDisabled = returnIfNotFinalised(application.applicationStatus);

    return (
        <TableCell component="th" scope={"row"}>
            <StandardButton disabled={!isDisabled}
                            onClick={() => execution(application,callback )}>
                {title}
            </StandardButton>
        </TableCell>
    )
}


function renderInReviewButton(application, afterFunction) {
    const isDisabled = application.applicationStatus !== 'IN_REVIEW'
        && application.applicationStatus !== 'ACCEPTED' &&
        application.applicationStatus !== 'SHORTLISTED'
        && application.applicationStatus !== 'REJECTED';


    return updateApp(isDisabled, application, 'Review', markAsInReview, afterFunction);
}