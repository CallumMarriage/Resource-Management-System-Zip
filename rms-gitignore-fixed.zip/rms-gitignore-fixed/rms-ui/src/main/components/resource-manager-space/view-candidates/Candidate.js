import Grid from "@material-ui/core/Grid";
import {Typography} from "@material-ui/core";
import {Link} from "react-router-dom";
import Paper from "@material-ui/core/Paper";
import React from "react";
import StandardButton from "../../shared/custom-items/StandardButton";

export default function Candidate(props) {
    return (
        <Paper style={{padding: '20px', width: '80%', height: 'fitContent'}}>
            <Grid container spacing={"1"}>
                <Typography variant={"h5"}>
                    {props.candidate.fullName}
                </Typography>
                <Grid item xs={12}>
                    <Grid container>
                        <Grid item xs={6}>
                            <Typography variant={"bod1"} color={"primary"}>
                                Candidate ID
                            </Typography>
                        </Grid>
                        <Grid item xs={6}>
                            <Typography variant={"body1"} color={"primary"}>
                                Current Role ID
                            </Typography>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item xs={12}>
                    <Grid container>
                        <Grid item xs={6}>
                            <Typography variant={"subtitle1"}>
                                {props.candidate.id}
                            </Typography>
                        </Grid>
                        <Grid item xs={6}>
                            <Typography variant={"subtitle1"}>
                                {
                                    currentRoleId(props.candidate.currentRoleId)
                                }
                            </Typography>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item xs={12}>
                    <Link style={{textDecoration: 'none'}} to={{
                        pathname: `/ResourceManagement/ViewCandidates/Candidate/${props.candidate.id}`,
                        state: {
                            candidateId: props.candidate.id,
                            currentRoleId: props.candidate.currentRoleId,
                            fullName: props.candidate.fullName,
                            userSpecialism: props.candidate.userSpecialism
                        }
                    }}>
                        <StandardButton style={{marginLeft: '10px',width: "100%", height: '100px'}}>
                            View
                        </StandardButton>
                    </Link>
                </Grid>
            </Grid>
        </Paper>
    )
}

function currentRoleId(currentRoleId) {
    if (currentRoleId === null || currentRoleId === undefined) {
        return (
            'User not assigned'
        )
    } else {
        return (
            currentRoleId
        )
    }
}
