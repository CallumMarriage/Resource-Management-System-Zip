import React from "react";

import Grid from "@material-ui/core/Grid";
import TitleContainer from "../../header/TitleContainer";
import CircularProgress from "@material-ui/core/CircularProgress";
import Error from "../../shared/Error";
import {retrieveCandidatesForResourceManager} from "../../../services/candidate/candidateService";
import {connect} from "react-redux";
import Candidate from "./Candidate";
import NoneFound from "../../shared/custom-items/NoneFound";
import TextField from "@material-ui/core/TextField";

class ViewCandidates extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            hasError: false,
            candidates: [],
            filteredList: null
        }
    }


    async componentDidMount() {

        const res = await retrieveCandidatesForResourceManager(this.props.userId);
        if (res.hasError) {
            this.setState({
                loading: false,
                hasError: true
            })
        }

        this.setState({
            candidates: res.candidates,
            loading: false
        })
    }

    handleChange = (event) => {
        this.setState({
            searchItem: event.target.value
        });
        this.setState({
            filteredList: this.state.candidates.filter(candidate =>
                candidate.fullName.toLocaleUpperCase().includes(event.target.value.toLocaleUpperCase()))
        })
    }

    render() {

        let candidates = this.state.candidates;
        if (this.state.filteredList !== null) {
            candidates = this.state.filteredList;
        }

        return (
            <Grid container>
                <TitleContainer title={"View Candidates"}/>
                <Grid item xs={12}>
                    <TextField style={{
                        width: '90%',
                        marginTop: '20px',
                        height: '5%'
                    }}
                               id="outlined-search"
                               label={"Search candidates by name"}
                               name={"candidateName"}
                               value={this.state.candidateName}
                               type="search"
                               variant="outlined"
                               onChange={this.handleChange.bind(this)}
                    />
                </Grid>
                <Grid item xs={12}>
                    <RenderCandidates candidates={candidates}
                                      loading={this.state.loading}
                                      hasError={this.state.hasError}
                    />
                </Grid>
            </Grid>
        )
    }
}

function RenderCandidates(props) {

    if (props.loading) {
        return (
            <CircularProgress style={{marginTop: '20px'}}/>
        )
    } else if (props.hasError) {
        return (
            <Error/>
        )
    } else if (props.candidates.length > 0) {
        return (
            <Grid container spacing={2} style={{marginTop: '10px'}}>
                {
                    props.candidates.map((candidate) => (
                        <Grid item xs={4} key={candidate.id}>
                            <Candidate candidate={candidate}/>
                        </Grid>
                    ))
                }
            </Grid>
        )
    } else {
        return (
            <NoneFound title={"You have no candidates assigned to you"}/>

        )
    }
}

const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id
    };
}

export default connect(mapStateToProps)(ViewCandidates);