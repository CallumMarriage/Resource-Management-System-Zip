import React from "react";
import Grid from "@material-ui/core/Grid";
import TitleContainer from "../../header/TitleContainer";
import DemandContainer from "./DemandContainer";

class Demand extends React.Component {

    constructor(props) {
        super(props);

    }

    render() {
        return (
            <Grid container>
                <TitleContainer title={"Demand"}/>
                <Grid item xs={12}>
                    <DemandContainer/>
                </Grid>
            </Grid>
        )
    }
}

export default Demand;