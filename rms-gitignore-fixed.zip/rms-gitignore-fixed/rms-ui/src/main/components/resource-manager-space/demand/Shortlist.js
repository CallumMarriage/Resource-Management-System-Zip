import Grid from "@material-ui/core/Grid";
import TitleContainer from "../../header/TitleContainer";
import React from "react";
import CircularProgress from "@material-ui/core/CircularProgress";
import Error from "../../shared/Error";
import {retrieveShortlist} from "../../../services/application/shortlistService";
import ShortlistedUser from "./ShortlistedCandidate";
import {Typography} from "@material-ui/core";
import NoneFound from "../../shared/custom-items/NoneFound";
import {BackButton} from "../../shared/custom-items/SharedStyledItems";
import {Link} from "react-router-dom";
import StandardButton from "../../shared/custom-items/StandardButton";

class Shortlist extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            shortlist: [],
            hasError: false,
            loading: true,
            role: props.location.state.role
        }

        this.retrieveShortlist = this.retrieveShortlist.bind(this);
    }

    async componentDidMount() {
        await this.retrieveShortlist();
    }

    async retrieveShortlist() {
        const res = await retrieveShortlist(this.state.role.id);
        if (res.hasError) {
            this.setState({
                loading: false,
                hasError: true
            })
        } else {
            this.setState({
                loading: false,
                shortlist: res
            })
        }
    }

    render() {
        if (this.state.loading) {
            return (
                <CircularProgress/>
            )
        }

        if (this.state.hasError) {
            return (
                <Error/>
            )
        }
        return (
            <Grid container>
                <TitleContainer title={`Short list for ${this.state.role.roleName}`}/>

                <Grid item xs={12} md={4} style={{margin: '20px'}}>
                    <Grid item xs={12}>
                        <BackButton onClick={this.props.history.goBack}>
                            Back
                        </BackButton>
                    </Grid>
                    <Grid item xs={12}>
                        <Typography variant={"h6"} style={{margin: '20px'}}>
                            What is the shortlist?
                        </Typography>
                        <Typography variant={"body1"} style={{marginTop: '40px'}}>
                            When you approve a member of the shortlist you will assign that role to the candidate.
                            This can not be undone.
                        </Typography>
                        <Typography variant={"body2"} style={{margin: '40px'}}>
                            Here are all of the users that you have shortlisted for {this.state.role.roleName}.
                            You can remove users from the shortlist or add new ones.
                            When your a user applies to a role, they are applying to be on the shortlist.
                            By confirming their application you add them to the shortlist.
                        </Typography>
                        <Link style={{textDecoration: 'none'}} to={{
                            pathname: `/ResourceManagement/Demand/${this.state.role.id}/Shortlist/AddCandidate`,
                            state: {
                                role: this.state.role
                            }
                        }}>
                            <StandardButton style={{width: '80%',
                                height: '100px',
                                backgroundColor: '#0070AD'
                            }} href={"/AddCandidate"}>
                                Add candidate to shortlist
                            </StandardButton>
                        </Link>
                    </Grid>
                </Grid>

                <Grid item xs={12} md={7} style={{margin: '20px'}}>
                    {
                        renderShortlist(this.state.shortlist, this.retrieveShortlist)
                    }
                </Grid>
            </Grid>
        )
    }

}

function renderShortlist(shortlist, retrieveShortlist) {

    if (shortlist.length === 0) {
        return <NoneFound title={"There are no candidates on the shortlist for this role."}/>
    }

    return (
        <Grid container>
            {
                shortlist.map((shortlistItem) => {

                    return (
                        <Grid item xs={12}>

                            <ShortlistedUser shortlistItem={shortlistItem} retrieveShortlist={retrieveShortlist}/>
                        </Grid>
                    )
                })
            }
        </Grid>
    )
}

export default Shortlist;