import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import {Typography} from "@material-ui/core";
import React from "react";
import Button from "@material-ui/core/Button";
import CircularProgress from "@material-ui/core/CircularProgress";
import Error from "../../shared/Error";
import {retrieveUserById} from "../../../services/candidate/candidateService";
import {Redirect} from "react-router-dom";
import confirmApp from "../../../services/application/confirmShortlistService";
import {rejectShortlistedCandidate} from "../../../services/application/shortlistService";
import StandardButton from "../../shared/custom-items/StandardButton";


/*
async function removeFromShortlist(userId, roleId) {
    const res = await rejectShortlistedCandidate(userId, roleId);

    if (res.hasError) {
        alert("Error approving shortlisted candidate")
    }
}
*/

class ShortlistedUser extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            user: null,
            loading: true,
            hasError: false,
            confirmed: false
        }
    }

    async approveCandidateForRole() {
        const res = await confirmApp(this.state.user.id,
            this.props.shortlistItem.roleId);
        if (res) {
            alert("Error approving shortlisted candidate")
        } else {
            this.setState({
                confirmed: true
            })
        }
    }

    async removeCandidateForRole(){
        const res = await rejectShortlistedCandidate(this.state.user.id,
            this.props.shortlistItem.roleId);
        if (res) {
            alert("Error approving shortlisted candidate")
        } else {
            alert("Shortlisted candidate has been removed")
            this.props.retrieveShortlist();
        }
    }

    async componentDidMount() {
        const res = await retrieveUserById(this.props.shortlistItem.userId)
        if (res.hasError) {
            this.setState({
                loading: false,
                hasError: true
            })
        } else {
            this.setState({
                loading: false,
                user: res
            })
        }
    }

    render() {
        if (this.state.loading) {
            return (
                <CircularProgress/>
            )
        }

        if (this.state.hasError) {
            return (
                <Error/>
            )
        }

        if (this.state.confirmed) {
            return (
                <Redirect to={"/ResourceManagement/Demand"}/>
            )
        }

        return (
            <Paper style={
                {
                    padding: '20px',
                    minHeight: '50px',
                    margin: 'auto',
                    textAlign: 'center'
                }}>
                <Grid container>
                    <Grid item xs={4}>
                        <Typography color={"primary"} variant={"h6"}>
                            {this.state.user.fullName}
                        </Typography>
                    </Grid>
                    <Grid item xs={4}>
                        <Typography variant={"h6"}>
                            {this.state.user.userSpecialism}
                        </Typography>
                    </Grid>
                    <Grid item xs={2}>
                        <StandardButton onClick={() => this.approveCandidateForRole(this.state.user.id,
                            this.props.shortlistItem.roleId)}>
                            Approve
                        </StandardButton>
                    </Grid>
                    <Grid item xs={2}>
                        <StandardButton onClick={() => this.removeCandidateForRole(this.state.user.id,
                            this.props.shortlistItem.roleId)}>
                            Remove
                        </StandardButton>
                    </Grid>
                </Grid>
            </Paper>
        )
    }
}

export default ShortlistedUser;