import NoneFound from "../../shared/custom-items/NoneFound";
import Role from "../../find-roles/Role";
import React from "react";
import Grid from "@material-ui/core/Grid";
import {Link as ReactLink} from "react-router-dom";
import {Typography, withStyles} from "@material-ui/core";
import StandardButton from "../../shared/custom-items/StandardButton";

class RoleDemandContainer extends React.Component {

    render() {
        if (this.props.potentialRoles.length === 0) {
            return (
                <NoneFound title={"There are no roles available matching your search"}/>

            )
        }
        return (
            <div style={{height: '600px', overflow: 'auto', backgroundColor: 'lightgrey'}}>
                {this.props.potentialRoles.map(role => {
                    return (
                        <Grid container key={role.id} style={{marginBottom: '15%'}}>
                            <Grid item xs={10} style={{height: '220px'}}>
                                <Role projectName={role.projectName}
                                      projectCode={role.projectCode}
                                      accountName={role.accountName}
                                      description={role.description}
                                      accountNumber={role.accountNumber}
                                      baseLocationX={role.baseLocationX}
                                      baseLocationY={role.baseLocationY}
                                      baseLocation={role.baseLocation}
                                      grade={role.grade}
                                      certainty={role.certainty}
                                      roleName={role.roleName}
                                      startDate={role.startDate}
                                      endDate={role.endDate}
                                      isRoleOpen={role.isRoleOpen}
                                      key={role.id}
                                      roleType={role.roleType}
                                      id={role.id}
                                />
                            </Grid>
                            <Grid item xs={2}>
                                {
                                    ShortlistButton(role)
                                }
                            </Grid>
                        </Grid>
                    )
                })}
            </div>
        )
    }
}

function ShortlistButton(role) {
    return (
        <StyledButton style={
            {
                margin: 'auto',
                marginTop: '20px',
                marginBottom: '20px',
                width: '90%',
                color: 'white'
            }
        }>
            <ReactLink style={{textDecoration: 'none'}} to={{
                pathname: `/ResourceManagement/Demand/${role.id}/Shortlist`,
                state: {
                    role: role
                }
            }}>

                <Typography variant={"body1"} color={"secondary"}>
                    Candidate Shortlist
                </Typography>
            </ReactLink>
        </StyledButton>
    )
}

const StyledButton = withStyles((theme)=> ({
    root: {
        minHeight: '100px',
        backgroundColor: theme.palette.primary.main

    }
}))(StandardButton)

export default RoleDemandContainer;