import React from "react";
import {retrieveDemand} from "../../../services/api/roleService";
import {connect} from "react-redux";
import CircularProgress from "@material-ui/core/CircularProgress";
import Error from "../../shared/Error";
import RoleDemandContainer from "./RoleDemandContainer";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import StandardButton from "../../shared/custom-items/StandardButton";
import stringSimilarity from "string-similarity";
import Paper from "@material-ui/core/Paper";
import {Typography} from "@material-ui/core";

class DemandContainer extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            roles: [],
            loading: true,
            hasError: false,
            filtering: false,
            projectName: '',
            accountName: '',
            roleName: ''
        }
    }

    async componentDidMount() {
        const res = await retrieveDemand(this.props.userId);
        if(res.hasError){
            this.setState({
                loading: false,
                hasError: true,
                filtering: false
            })
        } else {
            this.setState({
                loading: false,
                roles: res,
                filtering: false
            })
        }
    }

    handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    submit = (e) => {
        const filtered = this.state.roles.filter((role) => {
            return this.checkProjects(role.projectName) &&
                this.checkAccounts(role.accountName) &&
                this.checkRoles(role.roleName)
        })
        this.setState({
            filtered: filtered,
            filtering: true
        })
    }

    checkProjects = (projectName) => {
        return this.state.projectName === ''
        || (stringSimilarity.compareTwoStrings(projectName, this.state.projectName) > 0.5);
    }

    checkAccounts = (accountName) => {
        return this.state.accountName === ''
            || (stringSimilarity.compareTwoStrings(accountName, this.state.accountName) > 0.5);
    }

    checkRoles = (roleName) => {
        return this.state.roleName === ''
            || (stringSimilarity.compareTwoStrings(roleName, this.state.roleName) > 0.5);
    }

    reset = () => {
        this.setState({
            filtered: [],
            projectName: '',
            accountName: '',
            roleName: '',
            filtering: false
        })
    }

    render() {

        if (this.state.loading) {
            return (
                <CircularProgress/>
            )
        }

        if (this.state.hasError) {
            return (
                <Error/>
            )
        }

        let rolesToRender = this.state.roles;
        if(this.state.filtering){
            rolesToRender = this.state.filtered;
        }

        return (
            <Grid container spacing={2}>
                <Grid item xs={6}>
                        <Typography variant={"h6"} color={"primary"}>
                            What is demand?
                        </Typography>
                        <Typography variant={"body1"} style={{margin: '10px'}}>
                            When a role becomes available due that role will appear here.
                        </Typography>
                        <Typography variant={"body1"} style={{margin: '10px'}}>
                            This can be both potential roles for new projects and roles on existing projects.
                        </Typography>
                        <Typography variant={"body1"} style={{margin: '10px'}}>
                            To find the right candidates to shortlist use the View Candidates and use filters for tech stack and locations.
                        </Typography>
                </Grid>
                <Grid item xs={6}>
                    <Paper style={{padding: '20px', width: '400px'}}>
                        <Grid container spacing={1}>
                            <Grid item xs={12}>
                                <Typography variant={"h6"} color={"primary"}>
                                    For each available role there will be:
                                </Typography>
                            </Grid>
                            <Grid item xs={12}>
                                <ul style={{textAlign: 'left', width: '100%', margin: 'auto'}}>
                                    <li>
                                        <Typography variant={"body1"}>
                                            A predicted start and end date.
                                        </Typography>
                                    </li>
                                    <li>
                                        <Typography variant={"body1"}>
                                            A role description including tech stack where applicable.
                                        </Typography>
                                    </li>
                                    <li>
                                        <Typography variant={"body1"}>
                                            The likelihood of the role being confirmed as a percentage.
                                        </Typography>
                                    </li>
                                    <li>
                                        <Typography variant={"body1"}>
                                            And a list of shortlisted candidates for that role.
                                        </Typography>
                                    </li>
                                </ul>
                            </Grid>
                        </Grid>
                    </Paper>
                </Grid>
                <Grid item xs={3}>
                    <Paper style={{padding: '10px', width: '100%'}}>
                        <Grid container spacing={1}>
                            <Grid item xs={12}>
                                <Typography variant={"h6"} color={"primary"}>
                                    Filters
                                </Typography>
                            </Grid>
                            <Grid item xs={12}>
                                <TextField style={{
                                    width: '90%',
                                    height: '20%'
                                }}
                                           id="outlined-search-acc"
                                           label="Search By Account name"
                                           name={"accountName"}
                                           value={this.state.accountName}
                                           type="search"
                                           variant="outlined"
                                           onChange={this.handleChange.bind(this)}
                                />
                            </Grid>
                            <Grid item xs={12}>
                                <TextField style={{
                                    width: '90%',
                                    height: '20%'
                                }}
                                           id="outlined-search-acc"
                                           label="Search By Project Name"
                                           name={"projectName"}
                                           value={this.state.projectName}
                                           type="search"
                                           variant="outlined"
                                           onChange={this.handleChange.bind(this)}
                                />
                            </Grid>
                            <Grid item xs={12}>
                                <TextField style={{
                                    width: '90%',
                                    height: '20%'
                                }}
                                           id="outlined-search-acc"
                                           label="Search By Role Name"
                                           name={"roleName"}
                                           value={this.state.roleName}
                                           type="search"
                                           variant="outlined"
                                           onChange={this.handleChange.bind(this)}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <StandardButton style={{width: '80%',margin: 'auto', backgroundColor: '#15596B'}}
                                                onClick={this.reset.bind(this)}>
                                    Reset
                                </StandardButton>
                            </Grid>
                            <Grid item xs={6}>
                                <StandardButton style={{width: '80%', margin: 'auto', backgroundColor: '#12ABDB'}}
                                                onClick={this.submit.bind(this)}>
                                    Filter
                                </StandardButton>
                            </Grid>
                        </Grid>
                    </Paper>
                </Grid>
                <Grid item xs={9}>
                    <RoleDemandContainer potentialRoles={rolesToRender}/>
                </Grid>
            </Grid>
        )
    }
}



const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id,
    };
}

export default connect(mapStateToProps)(DemandContainer);