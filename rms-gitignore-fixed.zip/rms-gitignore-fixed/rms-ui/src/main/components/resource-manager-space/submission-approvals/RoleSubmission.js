import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import React from "react";
import {withStyles} from "@material-ui/core";
import {
    addNewRoleSubmission,
    approveSubmission,
    rejectSubmission
} from "../../../services/submission/submissionService";
import {addNewAssignment} from "../../../services/assignment/assignmentService";
import {addNewRole, updateRoleAsActive} from "../../../services/api/roleService";
import {updateUserCurrentProject} from "../../../services/candidate/candidateService";
import StandardButton from "../../shared/custom-items/StandardButton";

class RoleSubmission extends React.Component {

    async approveSub() {
        const res = await approveSubmission(this.props.sub.submissionId)

        const sub = this.props.sub.submittedRole;
        if (res.hasError) {
            alert('Failed to approve sub')
        } else {

           const role = await addNewRole(this.props.sub.candidateId, {
                roleName: sub.roleName,
                description: sub.description,
                roleType: sub.roleType,
                businessUnitId: sub.businessUnitId,
                baseLocation: sub.baseLocation,
                projectName: sub.projectName,
                projectCode: sub.projectCode,
                accountName: sub.accountName,
                accountNumber: sub.accountNumber,
                startDate: sub.startDate,
                endDate: sub.endDate,
            });

           if(res.hasError){
               await addNewRoleSubmission(this.props.sub.candidateId, sub);
               alert('Error approving submission')
           } else {
               const res = updateRoleAsActive(role.id);

               if(res.hasError){
                   alert('error updating role as active')
               } else {
                   const res = await addNewAssignment(this.props.sub.candidateId,
                       role.id, role.startDate, role.endDate)
                   if(res.hasError){
                       alert('Error adding assignment for candidate')
                   } else {
                       if(role.endDate === null){
                           const res = await updateUserCurrentProject(this.props.sub.candidateId, role.id)
                           if(res.hasError){
                               alert('Error adding assignment for candidate')
                           }
                       }
                   }
               }
           }

           this.props.updateRoleSubs();
        }
    }

    rejectSub(){
        const res = rejectSubmission(this.props.sub.submissionId)

        if(res.hasError){
            alert('Failed to reject sub')
        } else {
            this.props.updateRoleSubs();
        }
    }


    render() {
        const { sub } = this.props;
        return (
            <TableRow key={sub.submissionId}>
                <TableCell scope="row" align={"right"}>
                    {sub.submissionId}
                </TableCell>
                <TableCell scope="row" align={"right"}>
                    {sub.candidateId}
                </TableCell>
                <TableCell scope="row" align={"right"}>
                    {sub.submittedRole.roleName}
                </TableCell>
                <TableCell scope="row" align={"right"}>
                    {sub.submittedRole.accountNumber}
                </TableCell>
                <TableCell scope="row" align={"right"}>
                    {sub.submittedRole.projectCode}
                </TableCell>
                <TableCell scope="row" align={"right"}>
                    {sub.submittedRole.startDate}
                </TableCell>
                <TableCell scope="row" align={"right"}>
                    {sub.submittedRole.endDate}
                </TableCell>
                <TableCell component="th" scope={"row"}>
                    <StyledButtonResourceManager onClick={this.approveSub.bind(this)}>
                        Accept
                    </StyledButtonResourceManager>
                </TableCell>
                <TableCell component="th" scope={"row"}>
                    <StyledButtonResourceManager onClick={this.rejectSub.bind(this)}>
                        Reject
                    </StyledButtonResourceManager>
                </TableCell>
            </TableRow>
        )
    }
}

const StyledButtonResourceManager = withStyles((theme) => ({
    root: {
        backgroundColor: theme.palette.primary.main,
        color: 'white',
        width: '100px',
        height: '50px'
    },
    disabled: {
        color: 'lightgrey',
        backgroundColor: 'darkgrey'
    }
}))(StandardButton)

export default RoleSubmission;