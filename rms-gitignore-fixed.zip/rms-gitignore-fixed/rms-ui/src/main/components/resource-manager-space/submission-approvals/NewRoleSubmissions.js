import Grid from "@material-ui/core/Grid";
import React from "react";
import Paper from "@material-ui/core/Paper";
import Table from "@material-ui/core/Table";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import TableBody from "@material-ui/core/TableBody";


import TableContainer from "@material-ui/core/TableContainer";
import CircularProgress from "@material-ui/core/CircularProgress";
import Error from "../../shared/Error";
import {retrieveNewRoleSubmissionForRm} from "../../../services/submission/submissionService";
import {connect} from "react-redux";
import RoleSubmission from "./RoleSubmission";
import NoneFound from "../../shared/custom-items/NoneFound";
import TitleContainer from "../../header/TitleContainer";

class NewRoleSubmissions extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            roleSubmissions: null,
            hasError: false,
            loading: true
        }

        this.RenderTable = this.RenderTable.bind(this);
        this.updateRoleSubs = this.updateRoleSubs.bind(this);
    }


    async componentDidMount() {
        await this.updateRoleSubs();
    }

    RenderTable() {
        if (this.state.loading) {
            return (
                <CircularProgress style={{marginTop: '20px'}}/>
            )
        } else if (this.state.hasError) {
            return (
                <Error/>
            )
        } else if (this.state.roleSubmissions.length === 0) {
            return (
                <NoneFound title={"You have no submissions to approve"}/>
            )
        }

        return (
            <TableContainer component={Paper}>

                <Table size="small" aria-label="a dense table">
                    <TableHead>
                        <TableRow>
                            <TableCell align="right">Id</TableCell>
                            <TableCell align="right">Candidate</TableCell>
                            <TableCell align="right">Role Name</TableCell>
                            <TableCell align="right">Account Number</TableCell>
                            <TableCell align="right">Project Code</TableCell>
                            <TableCell align="right">Start Date</TableCell>
                            <TableCell align="right">End Date</TableCell>
                            <TableCell align="right">Approve</TableCell>
                            <TableCell align="right">Reject</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {
                            this.state.roleSubmissions.map((sub) => (
                                <RoleSubmission sub={sub} updateRoleSubs={this.updateRoleSubs.bind(this)}/>
                            ))}
                    </TableBody>
                </Table>
            </TableContainer>
        )

    }

    async updateRoleSubs() {
        const res = await retrieveNewRoleSubmissionForRm(this.props.userId);

        if (res.hasError) {
            this.setState({
                hasError: true,
                loading: false
            })
        } else {
            this.setState({
                loading: false,
                hasError: false,
                roleSubmissions: res.roleSubmissions
            })
        }
    }

    render() {

        return (
            <Grid container>
                <TitleContainer title={"Candidate Role Submissions"}/>

                <Grid item xs={12}>
                    {this.RenderTable()}
                </Grid>
            </Grid>
        )
    }
}


const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id,
    };
}

export default connect(mapStateToProps)(NewRoleSubmissions);