import React from 'react';
import {connect} from "react-redux";

import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import withStyles from "@material-ui/core/styles/withStyles";
import {Typography} from "@material-ui/core";

import TitleContainer from "../header/TitleContainer";
import InputLabel from "@material-ui/core/InputLabel";
import {handleAddNewUser} from "../../services/api/userService";
import {updateUserCreds, updateUserExists} from "../../actions/user";
import {Redirect} from "react-router-dom";
import {getEmployeeTypes} from "../shared/enums/EmployeeTypes";
import {getRoleTypes} from "../shared/enums/RoleTypes";
import {getCapBaseLocations} from "../shared/enums/CapBaseLocations";
import grades from "../shared/enums/Grades";
import ListSelector from "../shared/custom-items/ListSelector";
import ValidatedInputField from "../shared/custom-items/ValidatedInputField";
import BusinessUntSelector from "../shared/custom-items/BusinessUntSelector";
import {handleListItemCheck} from "../shared/utils/checker";
import StandardButton from "../shared/custom-items/StandardButton";

const StyledButton = withStyles((theme) => ({
    root: {
        margin: '10px',
        backgroundColor: theme.palette.primary.main,
        width: '90%',
        "&:hover": {
            backgroundColor: theme.palette.primary.light
        }
    }
}))(StandardButton);

class SignUp extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            name: {value: '', hasError: false},
            currentRole: null,
            currentProject: {value: '', hasError: false},
            currentAccount: {value: '', hasError: false},
            hasCurrentRole: false,
            grade: {value: grades[0].value, hasError: false},
            businessUnit: {value: '', hasError: false},
            userSpecialism: {value: getRoleTypes()[0].value, hasError: false},
            employeeType: {value: getEmployeeTypes()[0].value, hasError: false},
            employeeTypes: getEmployeeTypes(),
            baseLocation: {value: getCapBaseLocations()[0].value, hasError: false},
            baseLocations: getCapBaseLocations(),
            completed: false
        };

        this.updateBusinessUnit = this.updateBusinessUnit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleRadioChange = (event) => {
        this.setState({
            [event.target.name]: event.target.checked
        });
    }

    async submit() {

        let hasError = false
        if (this.state.name.value === '') {
            this.setState({
                name: {
                    value: this.state.name.value,
                    hasError: true
                }
            })
            hasError = true
        }

        if (handleListItemCheck(this.state.grade)) {
            this.setAsErrored(this.state.grade, 'grade')
            hasError = true
        }

        if (handleListItemCheck(this.state.userSpecialism)) {
            this.setAsErrored(this.state.employeeType, 'userSpecialism')
            hasError = true
        }

        if (handleListItemCheck(this.state.employeeType)) {
            this.setAsErrored(this.state.employeeType, 'employeeType')
            hasError = true
        }

        if (handleListItemCheck(this.state.businessUnit, 'businessUnit')) {
            this.setAsErrored(this.state.businessUnit, 'businessUnit')
            hasError = true
        }

        if (handleListItemCheck(this.state.baseLocation, 'baseLocation')) {
            this.setAsErrored(this.state.baseLocation, 'baseLocation')
            hasError = true
        }

        if (hasError) {
            alert('Please complete the form');
            return;
        }

        const res = await handleAddNewUser(
            this.props.ssoId,
            this.state.name.value,
            this.state.grade.value,
            this.state.employeeType.value,
            this.state.userSpecialism.value,
            this.state.baseLocation.value,
            this.state.businessUnit.value,);

        if (res.hasError) {
            alert('There has been an error')
        } else {
            alert('You have successfully created your profile!')
            this.props.updateUserCreds(res.user,
                res.currentRole,
                res.currentProject,
                res.currentAccount);
            this.props.updateUserExists(true);

            this.setState({
                completed: true
            })
        }
    }

    setAsErrored(listItem, name) {
        this.setState({
            [name]: {
                hasError: true,
                value: listItem.value,
            }
        })
    }

    handleChange = (e) => {
        this.setState({
            [e.target.name]: {
                value: e.target.value,
                hasError: false
            }
        })
    }

    setRole(event) {
        this.setState({
            currentRole: event.target.value
        })
    }

    updateBusinessUnit(businessUnit) {
        this.setState({
            businessUnit: {
                value: businessUnit,
                hasError: false
            }
        })
    }

    render() {

        if (this.state.completed) {
            return (
                <Redirect to={"/"}/>
            )
        }
        return (
            <Grid container>
                <TitleContainer title={"Sign up to our service"}/>
                <Grid item xs={12}>
                    <Paper style={{width: '60%', margin: 'auto', marginBottom: '100px'}}>

                        <Grid container>
                            <Grid item xs={12} style={{margin: 'auto'}}>
                                <Typography variant={"subtitle1"} style={{ margin: 'auto', marginTop: '30px'}}>
                                    Fill in your details in the form below so that you can start shaping your Capgemini journey
                                </Typography>
                                <Typography variant={"subtitle2"} color={"primary"} style={{margin: 'auto', padding: '10px'}}>
                                    You may need to scroll down to find the submit button.
                                </Typography>
                            </Grid>
                            <Grid item xs={12} md={6} style={{marginTop: '20px'}}>
                                <InputLabel htmlFor="name">Your Name *</InputLabel>
                                <ValidatedInputField id={"name"}
                                                     helper={"Please enter your name"}
                                                     value={this.state.name}
                                                     describe={"Please enter your name"}
                                                     handleChange={this.handleChange}/>
                            </Grid>
                            <ListSelector list={grades}
                                          id={"grade"}
                                          label={"What is your current Capgemini grade"}
                                          value={this.state.grade}
                                          onChange={this.handleChange}
                                          text={"Please select from the list your grade"}/>


                            <ListSelector list={this.state.employeeTypes}
                                          id={"employeeType"}
                                          label={"What is your role at Capgemini"}
                                          value={this.state.employeeType}
                                          onChange={this.handleChange}
                                          text={"Please select from the list the role you have"}/>

                            <ListSelector list={getRoleTypes()}
                                          id={"userSpecialism"}
                                          label={"What is your specialist field?"}
                                          value={this.state.userSpecialism}
                                          onChange={this.handleChange}
                                          text={"Please select from the list what closest matches your specialist area"}/>
                            <ListSelector list={this.state.baseLocations}
                                          id={"baseLocation"}
                                          label={"Base Location"}
                                          value={this.state.baseLocation}
                                          onChange={this.handleChange}
                                          text={"Please select your base location"}/>
                            <BusinessUntSelector handleChange={this.handleChange}
                                                 updateBusinessUnit={this.updateBusinessUnit}
                                                 businessUnit={this.state.businessUnit}/>
                            <Grid item xs={12} style={{marginBottom: '20px'}}>
                                <StyledButton onClick={this.submit.bind(this)}>
                                    Submit
                                </StyledButton>
                            </Grid>
                        </Grid>
                    </Paper>

                </Grid>
            </Grid>

        );
    }
}


const mapStateToProps = (state) => {
    return {
        ssoId: state.auth.ssoId
    };
}

export default connect(mapStateToProps, {updateUserExists, updateUserCreds})(SignUp);