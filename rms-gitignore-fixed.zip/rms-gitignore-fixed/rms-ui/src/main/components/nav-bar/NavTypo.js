import withStyles from "@material-ui/core/styles/withStyles";
import {Typography} from "@material-ui/core";

export default withStyles((theme) => ({
    root: {
        width: '85px',
        fontSize: 11,
        padding: '0px',
        textTransform: 'none',
    }
}))(Typography);