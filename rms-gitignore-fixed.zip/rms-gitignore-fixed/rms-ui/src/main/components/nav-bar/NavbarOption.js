import React from "react";
import {Typography} from '@material-ui/core';

import CircularProgress from "@material-ui/core/CircularProgress";
import {NavLink} from "react-router-dom";
import NavButton from "./NavButton";
import NavTypo from "./NavTypo";

function conditionalRenderNumber(number, loading) {
    if (number === undefined) {
        return (<div style={{width: '30px'}}/>)
    }
    let Value = () => {
        return (
            <CircularProgress style={{color: 'white'}}/>
        )
    }

    if (!loading) {
        Value = () => {
            return (
                <Typography variant={"body2"} style={{width: '30px'}}>
                    {number}
                </Typography>
            )
        }
    }

    return (
        <Value/>
    )

}


export default function NavbarOption(props) {
    const TheIcon = props.icon;

    return (
        <NavButton component={NavLink}
                   to={props.link} style={{padding: '0px'}}>

            <TheIcon/>
            <NavTypo variant="body2">
                {props.title}
            </NavTypo>
            {conditionalRenderNumber(props.number, props.loading)}

        </NavButton>
    )
}

