import withStyles from "@material-ui/core/styles/withStyles";
import Button from "@material-ui/core/Button";

export default withStyles((theme) => ({
    root: {
        textAlign: 'center',
        margin: 'auto',
        width: '160px',
        height: '40px',
        padding: '0px',
        borderBottom: '1px solid #15596B',
        backgroundColor: theme.palette.secondary.main,
        color: theme.palette.primary.main,
        "&.active": {
            backgroundColor: theme.palette.primary.main,
            fontWeight: 'bold',
            color: theme.palette.secondary.main,
            "& [className*='Typography']": {
                fontWeight: "bold",
                color: theme.palette.secondary.main,
                fontSize: '11pt'
            },
        },
    }
}))(Button)