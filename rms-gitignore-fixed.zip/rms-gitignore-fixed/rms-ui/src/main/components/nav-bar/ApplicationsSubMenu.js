import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import Fade from "@material-ui/core/Fade";
import React from "react";
import {Typography} from "@material-ui/core";
import {Link} from "react-router-dom";
import Applications from "./icons/Applications";
import CircularProgress from "@material-ui/core/CircularProgress";
import NavButton from "./NavButton";
import NavTypo from "./NavTypo";

export default function ApplicationsSubMenu(props) {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    return (
        <div style={{margin: 'auto'}}>
            <NavButton aria-controls="fade-menu"
                       aria-haspopup="true"
                       onClick={handleClick}>
                <Applications/>

                <NavTypo>
                    My Applications
                </NavTypo>
                <div style={{width: '30px'}}/>
            </NavButton>
            <Menu
                id="fade-menu"
                anchorEl={anchorEl}
                keepMounted
                style={{marginTop: '50px'}}
                open={open}
                onClose={handleClose}
                TransitionComponent={Fade}
            >
                <MenuItem style={{width: '180px'}}>
                    <Link style={{textDecoration: 'none'}}
                          to={"/Applications/MyApplications"} onClick={handleClose}>
                        {conditionalRenderNumber(props.numOfApps, props.loading)}

                    </Link>
                </MenuItem>
                <MenuItem>
                    <Link to={"/Applications/MyShortlisted"}
                          style={{textDecoration: 'none'}}
                          onClick={handleClose}>
                        <Typography variant={"body1"} color={"primary"}>
                            My Shortlisted
                        </Typography>
                    </Link>
                </MenuItem>
            </Menu>
        </div>
    );
}


function conditionalRenderNumber(number, loading) {
    if (number === undefined) {
        return null;
    }
    let Value = () => {
        return (
            <CircularProgress style={{color: 'white'}}/>
        )
    }

    if (!loading) {
        Value = () => {
            return (
                <Typography variant={"body1"} color={"primary"}>
                    My Applications - {number}
                </Typography>
            )
        }
    }

    return (
        <Value/>
    )

}