import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import Fade from "@material-ui/core/Fade";
import React from "react";
import Approvals from "./icons/Approvals";
import {Typography} from "@material-ui/core";
import {Link} from "react-router-dom";
import NavButton from "./NavButton";
import NavTypo from "./NavTypo";

export default function FadeMenu() {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    return (
        <div style={{margin: 'auto'}}>
            <NavButton aria-controls="fade-menu"
                       aria-haspopup="true"
                       onClick={handleClick}>
                <Approvals/>

                <NavTypo>
                    Resourcing
                </NavTypo>
                <div style={{width: '30px'}}/>
            </NavButton>
            <Menu
                id="fade-menu"
                anchorEl={anchorEl}
                keepMounted
                style={{marginTop: '50px'}}
                open={open}
                onClose={handleClose}
                TransitionComponent={Fade}
            >
                <MenuItem style={{width: '200px'}}>
                    <Link style={{textDecoration: 'none'}}
                          to={"/ResourceManagement/ViewCandidates"}
                          onClick={handleClose}>
                        <Typography variant={"body1"} color={"primary"}>
                            View Candidates
                        </Typography>
                    </Link>
                </MenuItem>
                <MenuItem>
                    <Link style={{textDecoration: 'none'}}
                          to={"/ResourceManagement/NewRoleSubmissions"}
                          onClick={handleClose}>
                        <Typography variant={"body1"} color={"primary"}>
                            New Role Submissions
                        </Typography>
                    </Link>
                </MenuItem>
                <MenuItem>
                    <Link style={{textDecoration: 'none'}} to={"/ResourceManagement/ShortListApplications"} onClick={handleClose}>
                        <Typography variant={"body1"} color={"primary"}>
                            Short List Applications
                        </Typography>
                    </Link>
                </MenuItem>
                <MenuItem>
                    <Link style={{textDecoration: 'none'}} to={"/ResourceManagement/Demand"} onClick={handleClose}>
                        <Typography variant={"body1"} color={"primary"}>
                            Demand
                        </Typography>
                    </Link>
                </MenuItem>
            </Menu>
        </div>
    );
}

