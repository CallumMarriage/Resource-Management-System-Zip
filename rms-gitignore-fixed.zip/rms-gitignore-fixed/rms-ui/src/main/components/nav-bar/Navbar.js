import React from "react";
import NavbarOption from "./NavbarOption";
import Paper from "@material-ui/core/Paper";
import {connect} from "react-redux";
import withStyles from "@material-ui/core/styles/withStyles";
import {retrieveNumOfApplications} from "../../services/application/applicationService";
import Grid from "@material-ui/core/Grid";
import CartIcon from "./icons/FindCart";
import SearchIcon from "./icons/SearchIcon";
import PMIcon from "./icons/PMIcon";
import HomeIcon from "./icons/HomeIcon";
import MyCapgemini from "./icons/MyCapgemini";
import FadeMenu from "./SubMenu";
import Auth from "../auth/Auth";
import ApplicationsSubMenu from "./ApplicationsSubMenu";

const styles = theme => ({
    root: {
        flexGrow: 1,
    },
    paper: {
        textAlign: 'center',
        backgroundColor: theme.palette.secondary.dark,
        fontcolor: 'white',
        width: '100%',
        height: '70px',
    }
});


class Navbar extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            numOfApps: '0',
        };
    }


    async componentDidMount() {
        if (this.props.user == null) {
            return;
        }

        console.log("Making request to receive number of apps")
        const res = await retrieveNumOfApplications(this.props.user.id);

        this.setState({
            loading: false,
            numOfApps: res.numOfApplications
        })
    }


    render() {

        const numOfApps = this.state.numOfApps

        if (this.props.isSignedIn) {
            return (
                <Paper className={this.props.classes.paper}>
                    <Grid container style={{margin: 'auto', height: '100%'}}>
                        <Auth/>

                        <NavbarOption link={"/Home"}
                                      icon={HomeIcon}
                                      title={"Home Page"}/>
                        <NavbarOption link="/MyCapgeminiCV"
                                      icon={MyCapgemini}
                                      title={"My CV"}/>
                        <ApplicationsSubMenu
                            loading={this.state.loading}
                            numOfApps={this.state.numOfApps}/>
                        <NavbarOption
                            link="/Applications/FindRoles"
                            icon={CartIcon}
                            title={"Role Finder"}/>
                        <NavbarOption link="/SearchAccounts"
                                      icon={SearchIcon}
                                      title={"Search Accounts"}/>

                        {
                            RenderProjectManagementComponent(
                                "/ProjectManagement",
                                PMIcon,
                                "Manage Projects", this.props.user.userType
                            )
                        }
                        {
                            RenderResourceManagerComponent(this.props.user)
                        }
                        <div style={{marginRight: '80px'}}/>
                    </Grid>
                </Paper>
            )
        } else {
            return (
                <div/>
            )
        }
    }
}

function RenderProjectManagementComponent(link, icon, title, userType) {
    if (userType === 'PROJECT_MANAGER') {
        return (
            <NavbarOption link={link}
                          icon={icon}
                          title={title}/>
        )
    } else {
        return null;
    }
}

function RenderResourceManagerComponent(user) {
    if (user.userType === 'RESOURCE_MANAGER') {
        return (
            <FadeMenu user={user}/>
        )
    } else {
        return null;
    }
}


const mapStateToProps = (state) => {
    return {
        user: state.user.user,
        isSignedIn: state.auth.isSignedIn,
    };
}

export default connect(mapStateToProps)(withStyles(styles)(Navbar));