import React from "react";

import TimelineSeparator from "@material-ui/lab/TimelineSeparator";
import TimelineDot from "@material-ui/lab/TimelineDot";
import TimelineConnector from "@material-ui/lab/TimelineConnector";
import TimelineContent from "@material-ui/lab/TimelineContent";
import {Link} from "react-router-dom";
import Typography from "@material-ui/core/Typography";
import withStyles from "@material-ui/core/styles/withStyles";
import TimelineItem from "@material-ui/lab/TimelineItem";
import Grid from "@material-ui/core/Grid";
import AccountImage from "../sub-pages/account/AccountImage";
import Box from "@material-ui/core/Box";
import StandardButton from "../shared/custom-items/StandardButton";
import moment from "moment";


const StyledButton = withStyles((theme) => ({
    root: {
        maxHeight: '160px',
        minHeight: '160px',
        backgroundColor: theme.palette.primary.main,
        textTransform: 'none',
        padding: '10px',
        boxShadow: '5px 5px grey',
    },
    label: {
        textTransform: 'none'
    },
}))(StandardButton);


export default function RoleItem(props) {
    const role = props.role;
    const number = props.number;

    let colour = '#12ABDB';
    if(number % 2 === 0){
        colour = '#0070AD'
    }

    return (
        <TimelineItem key={role.id}>
            <TimelineSeparator>
                <TimelineDot style={{width: '110px', height: '110px'}}>
                    <Typography variant={"h5"} style={{fontSize: '1em', padding: '30px'}}>
                        {role.startDate}
                    </Typography>
                </TimelineDot>
                <TimelineConnector/>
            </TimelineSeparator>
            <TimelineContent>
                <Link to={{
                    pathname: `/SearchAccounts/Account/${role.accountNumber}/Project/${role.projectCode}/ViewRole/${role.id}`,
                    state: {role: role}
                }} style={{textDecoration: 'none'}}>
                    <StyledButton style={{background: colour}}>
                        <Grid container>
                            <Grid item xs={3} style={{margin: 'auto'}}>
                                <AccountImage accountNumber={role.accountNumber}/>
                            </Grid>
                            <Grid item xs={9}>
                                <Grid container>
                                    <Grid item xs={12}>
                                        <Typography variant="h5" component="h1">
                                            <Box fontWeight="fontWeightBold" m={1}>
                                                {role.roleName} at {role.projectName}
                                            </Box>
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12}>
                                        <Typography variant={"h5"}>
                                            Role Began: {moment(role.startDate).format("DD MMMM YYYY")}
                                        </Typography>
                                        <Typography variant={"h5"}>
                                            Ended on: {moment(role.endDate).format("DD MMMM YYYY")}
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                    </StyledButton>
                </Link>
            </TimelineContent>
        </TimelineItem>
    )

}