import React from 'react';
import {connect} from "react-redux";

import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import withStyles from "@material-ui/core/styles/withStyles";
import {Typography} from "@material-ui/core";

import Error from "../shared/Error";
import {retrieveRoleHistory} from "../../services/api/roleHistoryService";

import TitleContainer from "../header/TitleContainer";
import CircularProgress from "@material-ui/core/CircularProgress";
import CustomizedTimeline from "./Timeline";
import {Link} from "react-router-dom";
import AddNewItemButton from "../shared/custom-items/AddNewItemButton";
import NoneFound from "../shared/custom-items/NoneFound";


const StyledPaper = withStyles((theme) => ({
    root: {
        border: 'solid 2px',
        borderColor: theme.palette.primary.main,
        backgroundColor: 'lightgrey',
        margin: 'auto',
        padding: '10px',
        width: '80%',
        marginTop: '20px'
    }
}))(Paper)

class MyCapgeminiCv extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            roleHistory: [],
            loading: true,
            hasError: false
        };
    }

    async componentDidMount() {
        const res = await retrieveRoleHistory(this.props.userId);

        if (res.hasError) {
            this.setState({
                hasError: true,
                loading: false,
                error: res.error
            })
        } else {
            this.setState({
                roleHistory: res.roleList,
                loading: false
            })
        }

    }

    render() {
        return (
            <Grid container>
                <TitleContainer title={"My Capgemini CV"}/>
                <Grid item xs={12}>
                    <div style={{marginBottom: '20px'}}>
                        <Grid container>
                            <Grid item xs={12}>
                                <div style={
                                    {
                                        width: '90%',
                                        margin: 'auto',
                                        marginTop: '20px',
                                        marginBottom: '20px'
                                    }}>
                                    <Typography variant={"h5"}>
                                        Welcome to your Capgemini CV
                                    </Typography>
                                </div>
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <div style={{
                                    width: '90%',
                                    margin: 'auto',

                                }}>
                                    <Typography variant={"subtitle1"}>
                                        Here you can search through your journey at Capgemini.
                                        Each stage has a link to the role you were on at that timee.
                                    </Typography>
                                </div>
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <div style={{width: '90%', margin: 'auto'}}>

                                    <Typography variant={"body1"}>
                                        If you think that your history is incomplete click on the below button to
                                        add a
                                        new role.
                                    </Typography>
                                    <div style={{marginTop: '30px'}}>
                                        <Link to={'/SubmitRole'} style={{textDecoration: 'none'}}>
                                            <AddNewItemButton label={"Add new role here"}/>
                                        </Link>
                                    </div>
                                    <StyledPaper>
                                        <Typography variant={"subtitle1"}>
                                            Before you add your role make sure you have the account number for the
                                            account that you were on.
                                        </Typography>
                                        <div style={{marginTop: '10px'}}>
                                            <Typography variant={"subtitle2"}>
                                                <Link to={"/SearchAccounts"}>
                                                    Account details can be found here
                                                </Link>
                                            </Typography>
                                        </div>
                                    </StyledPaper>
                                </div>
                            </Grid>
                        </Grid>
                    </div>
                </Grid>
                <Grid item xs={12}>
                    {
                        renderRoleHistory(this.state.loading, this.state.hasError, this.state.roleHistory)
                    }
                </Grid>
            </Grid>
        );
    }
}

function renderRoleHistory(loading, hasError, roleHistory) {
    if (loading) {
        return (
            <CircularProgress style={{marginTop: '20px'}}/>
        )
    }

    if (hasError) {
        return (
            <Error/>
        )
    }

    if (roleHistory !== undefined && roleHistory.length !== 0) {
        return (
            <Paper style={{
                width: '100%',
                minHeight: '350px',
                maxHeight: 'fitContent',
                overflow: 'auto'
            }}>
                <CustomizedTimeline roleHistory={roleHistory}/>
            </Paper>
        );
    } else {
        return (
            <NoneFound title={"Looks like you do not have any past roles"}/>
        )
    }
}


const mapStateToProps = (state) => {
    return {
        userId: state.user.user.id,
    };
}

export default connect(mapStateToProps)(MyCapgeminiCv);