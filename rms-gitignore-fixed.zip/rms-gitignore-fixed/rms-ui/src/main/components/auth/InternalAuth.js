import React from "react";
import {connect} from "react-redux";
import {Redirect} from "react-router-dom";

import {updateUserCreds, updateUserExists, userAuthFailed} from "../../actions/user";
import {retrieveUserInfo, userExists} from "../../services/api/userService";

import Grid from "@material-ui/core/Grid";

class InternalAuth extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            hasError: false
        }

    }

    async componentDidMount() {
        await this.load();
    }

    shouldComponentUpdate(nextProps, nextState, nextContext) {
        return nextProps.isSignedIn !== this.props.isSignedIn ||
            nextProps.userExists !== this.props.userExists ||
            this.state.hasError !== nextState.hasError;
    }


    async componentDidUpdate(prevProps, prevState, snapshot) {
        await this.load();
    }

    async load() {
        if (this.props.userExists !== null) {
            return;
        }

        if (this.props.isSignedIn) {

            const res = await userExists(this.props.ssoId);

            if (res.userExist) {
                let userInfo = await retrieveUserInfo(this.props.ssoId);
                if (userInfo.hasError) {
                    return;
                }
                console.log('User exists')
                this.onInternalAuthChangeExists(true, userInfo);
            } else {
                console.log('Registering as user not existing: ' + res)
                this.onInternalAuthChange(false);
            }
        }
    }

    onInternalAuthChangeExists(userExists, userInfo) {
        this.props.updateUserCreds(userInfo.user,
            userInfo.currentRole,
            userInfo.currentProject,
            userInfo.currentAccount)
        this.props.updateUserExists(userExists);
    }

    onInternalAuthChange(userExists) {
        this.props.updateUserExists(userExists);
    }

    render() {

        if (this.state.hasError) {
            return (
                <Redirect to={"/ServiceUnavailable"}/>
            )
        }
        return (
            <Grid container>

            </Grid>
        )
    }

}

const mapStateToProps = (state) => {
    return {
        isSignedIn: state.auth.isSignedIn,
        userExists: state.user.userExists,
        ssoId: state.auth.ssoId
    };
}

export default connect(mapStateToProps, {
    updateUserExists,
    updateUserCreds,
    userAuthFailed
})(InternalAuth);