import React, {Component} from "react";
import {Link} from "react-router-dom";
import {connect} from "react-redux";

import Button from "@material-ui/core/Button";
import {signIn, signOut} from "../../actions/sso";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import {Typography, withStyles} from "@material-ui/core";
import StandardButton from "../shared/custom-items/StandardButton";

class SsoAuth extends Component {

    componentDidMount() {
        this.load();
    }

    load() {
        window.gapi.load("auth2", () => {
            window.gapi.auth2
                .init({
                    client_id: process.env.REACT_APP_GOOGLE_OAUTH2_CLIENT_ID,
                    scope: "email",
                })
                .then(() => {
                    this.auth = window.gapi.auth2.getAuthInstance();
                    this.onAuthChange(this.auth, this.auth.isSignedIn.get());
                    this.auth.isSignedIn.listen(this.onAuthChange);
                });
        });
    }

    onAuthChange = (auth, isSignedIn) => {
        if (isSignedIn) {
            const ssoId = auth.currentUser.get()
                .getBasicProfile()
                .getId();

            this.props.signIn(ssoId);
        } else {
            this.props.signOut();
        }
    };

    onSignInClick = async () => {
        await this.auth.signIn();
        this.onAuthChange(this.auth, true)
    }

    onSignOutClick = () => {
        this.auth.signOut();
        this.props.signOut();
    };

    renderAuthButton() {
        if (this.props.isSignedIn === null) {
            return null;
        } else if( !this.props.isSignedIn) {
            return (
                <Grid container>
                    <Grid item xs={12}>
                        <Paper style={{margin: 'auto'}}>
                            <Typography variant={'h6'}>
                                Log in using SSO
                            </Typography>
                            <StandardButton style={{backgroundColor: '#0070AD'}}
                                    onClick={this.onSignInClick}>
                                Sign In
                            </StandardButton>
                        </Paper>
                    </Grid>
                </Grid>
            );
        } else if (this.props.isSignedIn) {
            return (
                <StyledButton onClick={this.onSignOutClick}
                              style={{margin: 'auto'}}>
                    <Typography variant={'subtitle2'}>
                        Sign Out
                    </Typography>
                </StyledButton>
            );
        }
    }

    render() {
        return (
            <Link to="/" style={{textDecoration: 'none'}}>
                <div>{this.renderAuthButton()}</div>
            </Link>
        );
    }
}

const StyledButton = withStyles((theme) => ({
    root: {
        width: '15%',
        float: 'left',
        marginLeft: '30px',
        backgroundColor: '#15626b',
        "&:hover": {
            backgroundColor: theme.palette.success.light,
            color: theme.palette.success.dark
        }
    }
}))(Button)

const mapStateToProps = (state) => {
    return {
        isSignedIn: state.auth.isSignedIn
    };
}

export default connect(mapStateToProps, {signIn, signOut})(SsoAuth);