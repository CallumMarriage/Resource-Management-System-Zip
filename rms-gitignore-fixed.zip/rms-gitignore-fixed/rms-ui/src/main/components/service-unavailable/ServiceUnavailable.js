import Paper from "@material-ui/core/Paper";
import {Typography} from "@material-ui/core";
import React from "react";

export default function ServiceUnavailable(){
    return (
        <Paper>
            <Typography variant={"h6"}>
                Oops, it looks like the service is currently down. Please try again later.
            </Typography>
        </Paper>
    )
}