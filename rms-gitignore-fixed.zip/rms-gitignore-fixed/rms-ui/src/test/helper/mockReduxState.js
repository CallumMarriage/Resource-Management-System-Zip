export const mockUser = {
    user: {
        user: {
            baseLocation: "WOKING",
            baseLocationX: 51.319125999480754,
            baseLocationY: -0.5632602646266073,
            businessUnitId: 1,
            currentRoleId: 1,
            fullName: "Test user",
            id: 3,
            resourceManagerName: "Test rm",
            userSpecialism: "OTHER",
            userType: "RESOURCE_MANAGER"
        },
        currentAccount: {
            accountCode: "1234567890",
            accountManagerId: 1,
            accountName: "Olympic",
            description: "Test",
            endDate: "2024-03-11",
            startDate: "2021-03-11"
        },
        currentProject: {
            accountName: "Olympic",
            accountNumber: "1234567890",
            baseLocation: null,
            description: "Test project",
            endDate: "2024-03-11",
            projectCode: "2190381032",
            projectName: "Agile",
            startDate: "2021-03-11"
        },
        currentRole: {
            accountName: "Olympic",
            accountNumber: "1234567890",
            assignee: null,
            baseLocation: "GLASGOW",
            baseLocationX: 55.85782304234286,
            baseLocationY: -4.260820309650051,
            businessUnit: 1,
            certainty: 61,
            description: "Test role",
            endDate: "2024-03-11",
            id: 1,
            isRoleOpen: false,
            projectCode: "2190381032",
            projectName: "Agile",
            roleName: "Pro Business Analyst",
            roleType: "BUSINESS_ANALYST",
            startDate: "2021-03-11"
        }
    },
}