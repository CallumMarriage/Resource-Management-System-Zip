export const retrieveElementById  = (title_, element) =>
    element.findAll((el) => {
        return el.props.title === title_
})[0].props.value;