import React from 'react';
import {cleanup} from '@testing-library/react';
import configureStore from 'redux-mock-store';

import {Provider} from 'react-redux';
import Renderer from 'react-test-renderer';
import { BrowserRouter as Router } from 'react-router-dom';
import {mockUser} from "../../helper/mockReduxState";
import MyCapgeminiCv from "../../../main/components/my-cap-cv/MyCapgeminiCv";

const mockStore = configureStore([]);

afterEach(cleanup);

describe('Render Capgemini CV Page', () => {
    let store;
    let component;

    beforeEach(() => {
        store = mockStore(
            mockUser
        );
        component = Renderer.create(
            <Provider store={store}>
                <Router>
                    <MyCapgeminiCv/>
                </Router>
            </Provider>
        );
    });

    it('My CV Should load the correct component', () => {
        const element = component.root;
        expect(element.findByType('h4').props.children).toBe('My Capgemini CV')
    })
});