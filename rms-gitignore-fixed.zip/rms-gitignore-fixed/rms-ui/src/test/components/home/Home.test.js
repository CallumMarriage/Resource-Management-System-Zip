import React from 'react';
import {cleanup} from '@testing-library/react';
import Home from "../../../main/components/home/Home";
import configureStore from 'redux-mock-store';

import {Provider} from 'react-redux';
import Renderer from 'react-test-renderer';
import { BrowserRouter as Router } from 'react-router-dom';
import {mockUser} from "../../helper/mockReduxState";
import {retrieveElementById} from "../../helper/findElementHelpers";
import moment from "moment";

const mockStore = configureStore([]);

afterEach(cleanup);

describe('Render Home Page', () => {
    let store;
    let component;

    beforeEach(() => {
        store = mockStore(
            mockUser
        );
        component = Renderer.create(
            <Provider store={store}>
                <Router>
                    <Home/>
                </Router>
            </Provider>
        );
    });

    it('Home page should have correct content', () => {
        const element = component.root;

        const value = moment('1')
        if(value.isValid()){
            console.log(value)
        }



        expect(element.findByType('h4').props.children).toBe('My Home Screen')

        const fullName = retrieveElementById('Full name', element)
        expect(fullName).toBe('Test user')

        const specialism = retrieveElementById('Specialism', element)
        expect(specialism).toBe('OTHER');

        const baseLocation = retrieveElementById('Base Location', element)
        expect(baseLocation).toBe('WOKING');

        const rm = retrieveElementById('Resource Manager', element)
        expect(rm).toBe('Test rm');

        const links = retrieveLinkElementById(element);

        expect(links[0].props.href).toBe('/SearchAccounts/Account/1234567890/Project/2190381032/ViewRole/1');
        expect(links[1].props.href).toBe('/SearchAccounts/Account/1234567890/Project/2190381032')
        expect(links[2].props.href).toBe('/SearchAccounts/Account/1234567890')

    });

    const retrieveLinkElementById = (element) => element.findAllByType('a');
});