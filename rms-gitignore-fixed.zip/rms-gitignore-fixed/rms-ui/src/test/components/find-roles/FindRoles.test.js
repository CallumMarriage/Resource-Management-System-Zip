import React from 'react';
import {cleanup} from '@testing-library/react';
import configureStore from 'redux-mock-store';

import {Provider} from 'react-redux';
import Renderer from 'react-test-renderer';
import {mockUser} from "../../helper/mockReduxState";
import FindRoles from "../../../main/components/find-roles/FindRoles";
import { BrowserRouter as Router } from 'react-router-dom';

const mockStore = configureStore([]);

afterEach(cleanup);

describe('Render Role Finder Page', () => {
    let store;
    let component;

    beforeEach(() => {
        store = mockStore(
            mockUser
        );
        component = Renderer.create(
            <Provider store={store}>
                <Router>
                    <FindRoles/>
                </Router>
            </Provider>
        );
    });

    it('Role Finder Should load the correct component', () => {
        const element = component.root;
        expect(element.findByType('h4').props.children).toBe('Find new roles')
    })
});