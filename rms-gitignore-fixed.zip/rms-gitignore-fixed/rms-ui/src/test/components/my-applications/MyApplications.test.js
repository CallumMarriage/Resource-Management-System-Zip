import React from 'react';
import {cleanup} from '@testing-library/react';
import configureStore from 'redux-mock-store';

import {Provider} from 'react-redux';
import Renderer from 'react-test-renderer';
import {mockUser} from "../../helper/mockReduxState";
import MyApplications from "../../../main/components/my-applications/MyApplications";
import { BrowserRouter as Router } from 'react-router-dom';

const mockStore = configureStore([]);

afterEach(cleanup);

describe('Render My Applications Page', () => {
    let store;
    let component;

    beforeEach(() => {
        store = mockStore(
            mockUser
        );
        component = Renderer.create(
            <Provider store={store}>
                <Router>
                    <MyApplications/>
                </Router>
            </Provider>
        );
    });

    it('My Applications Should load the correct component', () => {
        const element = component.root;
        expect(element.findByType('h4').props.children).toBe('My Applications')
    })
});