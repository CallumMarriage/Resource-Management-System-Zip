import React from 'react';
import {cleanup, render, screen} from '@testing-library/react';
import configureStore from 'redux-mock-store';

import {Provider} from 'react-redux';
import {mockUser} from "../../helper/mockReduxState";
import {BrowserRouter as Router} from 'react-router-dom';
import MyShortlisted from "../../../main/components/my-applications/MyShortlisted";
import {queryByAttribute} from "@testing-library/dom";

const mockStore = configureStore([]);

afterEach(cleanup);

describe('Render My Shortlisted Page', () => {
    let store;
    let dom;
    beforeEach(() => {
        store = mockStore(
            mockUser
        );
    })


    const getById = queryByAttribute.bind(null, 'id');

    it('My Shortlisted Should load the correct component', async () => {

        const mockService = jest.fn(() => Promise.resolve([
                {
                    userId: 1,
                    roleId: 2
                }
            ]
        ))

        const retrieveRole = jest.fn(() => Promise.resolve(
            {
                id: 2,
                roleName: 'Role',
                description: 'Description',
                startDate: new Date(),
                endDate: new Date()
            }
        ))


        dom = render(
            <Provider store={store}>
                <Router>
                    <MyShortlisted retrieveShortlistForUser={mockService}
                                   retrieveRole={retrieveRole}/>
                </Router>
            </Provider>
        )


        expect(getById(dom.container, 'TitleContainer')).toHaveTextContent('Shortlisted');
        console.log(await screen.findAllByText("Shortlist item"));
    });
});