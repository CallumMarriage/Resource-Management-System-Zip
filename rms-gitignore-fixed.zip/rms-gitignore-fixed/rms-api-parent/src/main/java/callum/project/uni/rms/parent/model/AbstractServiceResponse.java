package callum.project.uni.rms.parent.model;

public abstract class AbstractServiceResponse {

}
