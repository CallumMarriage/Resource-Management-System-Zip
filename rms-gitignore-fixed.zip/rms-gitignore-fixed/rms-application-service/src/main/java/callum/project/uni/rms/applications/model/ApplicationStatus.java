package callum.project.uni.rms.applications.model;

public enum ApplicationStatus {
    SUBMITTED,
    IN_REVIEW,
    REJECTED,
    SHORTLISTED,
    ACCEPTED

}
